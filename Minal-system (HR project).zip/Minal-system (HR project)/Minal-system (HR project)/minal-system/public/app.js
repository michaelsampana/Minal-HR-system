const SSIE_CANONICAL_SKILLS = [
  'communication', 'adaptability', 'leadership', 'critical_thinking',
  'conflict_resolution', 'initiative', 'collaboration', 'emotional_regulation',
  'learning_agility', 'attention_to_detail',
];

const PRIMITIVES = ['sense', 'interpret', 'decide', 'act', 'adjust'];
const PRIMITIVE_LABELS = { sense: 'S', interpret: 'I', decide: 'D', act: 'A', adjust: 'Aj' };

const state = { currentUser: null, logCount: 0 };

// ---------------------------------------------------------------------------
// Fetch helpers
// ---------------------------------------------------------------------------

async function api(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  log(method + ' ' + url, json, !res.ok);
  if (!res.ok) throw new Error(json.error || `${method} ${url} failed`);
  return json;
}

function log(tag, payload, isError) {
  const panel = document.getElementById('logPanel');
  const entry = document.createElement('div');
  entry.className = 'log-entry';
  entry.innerHTML = `<span class="${isError ? 'log-err' : 'log-tag'}">${tag}</span><pre>${escapeHtml(JSON.stringify(payload, null, 2)).slice(0, 1200)}</pre>`;
  panel.prepend(entry);
  state.logCount++;
  document.getElementById('logCount').textContent = state.logCount;
}

function escapeHtml(s) {
  return s.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
}

// ---------------------------------------------------------------------------
// Self-rated skill rows (baseline form)
// ---------------------------------------------------------------------------

function buildSkillOptionsInto(selectEl) {
  selectEl.innerHTML = SSIE_CANONICAL_SKILLS.map((s) => `<option value="${s}">${s}</option>`).join('');
}

function addSelfRatedRow() {
  const tpl = document.getElementById('selfRatedRowTemplate');
  const node = tpl.content.cloneNode(true);
  buildSkillOptionsInto(node.querySelector('.sr-skill'));
  node.querySelector('.sr-remove').addEventListener('click', (e) => e.target.closest('.self-rated-row').remove());
  document.getElementById('selfRatedRows').appendChild(node);
}

// ---------------------------------------------------------------------------
// User list / selection
// ---------------------------------------------------------------------------

async function refreshUserList(selectAfter) {
  const users = await api('GET', '/api/users');
  const sel = document.getElementById('userSelect');
  const prev = sel.value;
  sel.innerHTML = users.map((u) => `<option value="${u}">${u}</option>`).join('') || '<option value="">(no users yet)</option>';
  const target = selectAfter || prev || users[0] || '';
  sel.value = target;
  state.currentUser = sel.value || null;
}

async function loadCurrentUser() {
  if (!state.currentUser) {
    renderTrust(null);
    renderSkills({}, {});
    return;
  }
  const data = await api('GET', `/api/users/${encodeURIComponent(state.currentUser)}`);
  renderTrust(data.trustRecord);
  renderSkills(data.softSkillProfile, data.skillClaims);
  document.querySelector('[name="dispute"]').checked = !!data.consent?.dispute;
}

// ---------------------------------------------------------------------------
// Rendering — trust record
// ---------------------------------------------------------------------------

function renderTrust(record) {
  const empty = document.getElementById('trustEmpty');
  const grid = document.getElementById('trustGrid');
  if (!record) {
    empty.hidden = false;
    grid.hidden = true;
    return;
  }
  empty.hidden = true;
  grid.hidden = false;
  set('stat-reputation', record.reputationScore?.toFixed(1) ?? '—');
  set('stat-credibility', record.credibilityScoreAvg?.toFixed(1) ?? '—');
  set('stat-reliability', record.reliabilityScore?.toFixed(1) ?? '—');
  set('stat-accountability', record.accountabilityScore?.toFixed(1) ?? '—');
  set('stat-calibration', record.scoreBreakdown?.calibrationModifier != null ? record.scoreBreakdown.calibrationModifier.toFixed(3) : '—');
  set('stat-negative', record.scoreBreakdown?.ssieNegativeCount ?? '—');
}

function set(id, value) {
  document.getElementById(id).textContent = value;
}

// ---------------------------------------------------------------------------
// Rendering — skill cards + gauge cluster (signature element)
// ---------------------------------------------------------------------------

function renderSkills(profiles, claims) {
  const grid = document.getElementById('skillGrid');
  const tpl = document.getElementById('skillCardTemplate');
  grid.innerHTML = '';

  const skillIds = Object.keys(profiles || {});
  document.getElementById('skillCount').textContent = skillIds.length;

  for (const skillId of skillIds) {
    const output = profiles[skillId];
    const claim = (claims || {})[skillId] || {};
    const node = tpl.content.cloneNode(true);

    node.querySelector('.skill-name').textContent = skillId.replace(/_/g, ' ');
    const badge = node.querySelector('.badge');
    const vState = claim.verificationState || 'unverified';
    badge.dataset.state = vState;
    badge.textContent = vState;

    node.querySelector('.score-number').textContent = Math.round(output.score);
    const confFill = node.querySelector('.confidence-fill');
    confFill.style.width = `${Math.round(output.confidence)}%`;
    node.querySelector('.confidence-caption').textContent = `confidence ${Math.round(output.confidence)}`;

    const cluster = node.querySelector('.gauge-cluster');
    for (const p of PRIMITIVES) {
      const val = output.primitiveVector ? output.primitiveVector[p] : null;
      const gauge = document.createElement('div');
      gauge.className = 'gauge';
      const track = document.createElement('div');
      track.className = 'gauge-track';
      const fill = document.createElement('div');
      if (val == null) {
        fill.className = 'gauge-fill null-value';
        fill.title = 'no evidence yet';
      } else {
        fill.className = 'gauge-fill';
        fill.style.height = `${Math.round(Math.max(0, Math.min(1, val)) * 100)}%`;
        fill.title = val.toFixed(2);
      }
      track.appendChild(fill);
      const label = document.createElement('span');
      label.className = 'gauge-label';
      label.textContent = PRIMITIVE_LABELS[p];
      gauge.appendChild(track);
      gauge.appendChild(label);
      cluster.appendChild(gauge);
    }

    node.querySelector('.evidence-count').textContent = `${output.evidenceTrail?.length ?? 0} observations`;
    const gap = output.selfReportGap;
    node.querySelector('.gap-note').textContent = gap != null ? `gap ${gap > 0 ? '+' : ''}${gap.toFixed(0)}` : '';

    grid.appendChild(node);
  }

  renderUnreportable(claims);
}

function renderUnreportable(claims) {
  const list = document.getElementById('unreportableList');
  list.innerHTML = '';
  const entries = Object.values(claims || {}).filter((c) => c._unreportableReason);
  if (entries.length === 0) {
    list.innerHTML = '<div class="empty-note">nothing waiting on more evidence right now.</div>';
    return;
  }
  for (const c of entries) {
    const div = document.createElement('div');
    div.className = 'unreportable-item';
    div.innerHTML = `<span><strong>${c.skillId.replace(/_/g, ' ')}</strong></span><span>${c._unreportableReason}</span>`;
    list.appendChild(div);
  }
}

// ---------------------------------------------------------------------------
// Conditional form sections (event composer)
// ---------------------------------------------------------------------------

function updateConditionalFields() {
  const channel = document.getElementById('sourceChannel').value;
  document.querySelectorAll('.conditional').forEach((el) => {
    const applies = el.dataset.for.split(' ').includes(channel);
    el.hidden = !applies;
  });
}

// ---------------------------------------------------------------------------
// Form handlers
// ---------------------------------------------------------------------------

function buildKeystrokes(wpm, durationSec = 60) {
  const totalChars = Math.max(20, Math.round(wpm * 5 * (durationSec / 60)));
  const interval = (durationSec * 1000) / totalChars;
  return Array.from({ length: totalChars }, (_, i) => ({ ts_ms: Math.round(i * interval), char: 'x' }));
}

function buildTextEdits(fluency) {
  const insertions = 500;
  const deletions = Math.round((1 - fluency) * 500);
  return [{ insertions, deletions }];
}

async function handleBaselineSubmit(e) {
  e.preventDefault();
  const fd = new FormData(e.target);
  const userId = fd.get('userId').trim();
  if (!userId) return;

  const selfRatedSkills = [...document.querySelectorAll('#selfRatedRows .self-rated-row')].map((row) => ({
    skillId: row.querySelector('.sr-skill').value,
    rating: Number(row.querySelector('.sr-rating').value),
    skillType: 'soft',
  }));

  await api('POST', `/api/users/${encodeURIComponent(userId)}/baseline`, {
    keystrokes: buildKeystrokes(Number(fd.get('wpm'))),
    textEdits: buildTextEdits(Number(fd.get('fluency'))),
    responseTimes: [Number(fd.get('medianLatency')), Number(fd.get('medianLatency')) * 1.1, Number(fd.get('medianLatency')) * 0.9],
    selfRatedSkills,
  });

  await refreshUserList(userId);
  await loadCurrentUser();
}

async function handleConsentSubmit(e) {
  e.preventDefault();
  if (!state.currentUser) return alert('Select or create a user first.');
  const fd = new FormData(e.target);
  await api('POST', `/api/users/${encodeURIComponent(state.currentUser)}/consent`, {
    dispute: fd.get('dispute') === 'on',
  });
  await loadCurrentUser();
}

async function handleEventSubmit(e) {
  e.preventDefault();
  if (!state.currentUser) return alert('Select or create a user first.');
  const fd = new FormData(e.target);
  const sourceChannel = fd.get('sourceChannel');

  const event = {
    userId: state.currentUser,
    sourceChannel,
    skillIds: [fd.get('skillId')],
    engagementId: fd.get('engagementId') || `eng_${Date.now()}`,
    observedAt: new Date().toISOString(),
  };

  if (['workLog', 'dispute', 'quest'].includes(sourceChannel)) event.text = fd.get('text');
  if (sourceChannel === 'deliverableCycle') {
    event.verdict = fd.get('verdict');
    event.deliverableId = fd.get('deliverableId') || 'del_default';
    event.observedAtMs = Date.now();
    if (event.verdict === 'resubmitted') event.resubmissionNotes = fd.get('resubmissionNotes');
  }
  if (sourceChannel === 'endorsement') event.endorserTrustWeight = Number(fd.get('endorserTrustWeight'));
  if (sourceChannel === 'peerReview') {
    event.reviewerRatings = { sense: Number(fd.get('reviewerSense')), act: Number(fd.get('reviewerAct')) };
  }

  await api('POST', '/api/events', event);
  await loadCurrentUser();
}

async function handleQuestSelector() {
  await api('POST', '/api/admin/quest-selector', {});
}

async function handleDecay() {
  await api('POST', '/api/admin/decay', {});
  await loadCurrentUser();
}

async function handleReset() {
  if (!confirm('Reset ALL demo data? This clears every user, observation, and score.')) return;
  await api('POST', '/api/debug/reset', {});
  await refreshUserList();
  await loadCurrentUser();
}

async function handleSeed() {
  await api('POST', '/api/demo/seed', {});
  await refreshUserList('demo_alice');
  await loadCurrentUser();
}

// ---------------------------------------------------------------------------
// Tab switching
// ---------------------------------------------------------------------------

function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
  document.getElementById('ssieView').hidden = tab !== 'ssie';
  document.getElementById('employerView').hidden = tab !== 'employer';
  document.getElementById('configView').hidden = tab !== 'config';
  document.getElementById('ssieActions').hidden = tab !== 'ssie';
  document.getElementById('employerActions').hidden = tab !== 'employer';
  document.getElementById('configActions').hidden = tab !== 'config';
  if (tab === 'employer') refreshEmployerList().then(loadCurrentEmployer);
  if (tab === 'config') loadConfig();
}

// ---------------------------------------------------------------------------
// Employer state + fetch helper (reuses api() and log(), writing to the
// employer log panel instead when the employer tab is active)
// ---------------------------------------------------------------------------

const employerState = { currentEmployer: null, logCount: 0 };

async function employerApi(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  employerLog(method + ' ' + url, json, !res.ok);
  if (!res.ok) throw new Error(json.error || `${method} ${url} failed`);
  return json;
}

function employerLog(tag, payload, isError) {
  const panel = document.getElementById('employerLogPanel');
  const entry = document.createElement('div');
  entry.className = 'log-entry';
  entry.innerHTML = `<span class="${isError ? 'log-err' : 'log-tag'}">${tag}</span><pre>${escapeHtml(JSON.stringify(payload, null, 2)).slice(0, 1200)}</pre>`;
  panel.prepend(entry);
  employerState.logCount++;
  document.getElementById('employerLogCount').textContent = employerState.logCount;
}

async function refreshEmployerList(selectAfter) {
  const employers = await employerApi('GET', '/api/employers');
  const sel = document.getElementById('employerSelect');
  const prev = sel.value;
  sel.innerHTML = employers.map((e) => `<option value="${e}">${e}</option>`).join('') || '<option value="">(no employers yet)</option>';
  const target = selectAfter || prev || employers[0] || '';
  sel.value = target;
  employerState.currentEmployer = sel.value || null;
}

async function loadCurrentEmployer() {
  if (!employerState.currentEmployer) {
    renderEmployerProfile(null);
    renderRanking([]);
    return;
  }
  const data = await employerApi('GET', `/api/employers/${encodeURIComponent(employerState.currentEmployer)}`);
  renderEmployerProfile(data.futureNeedProfile, data.scoring);
  updateChangeReadinessQuestionLabel(data.pendingInterview);
}

// The backend (selectMicroInterviewSet) actually picks between two different
// phrasings of the change-readiness question depending on whether this
// employer's job postings mention new tools — but the form used to always
// show a hardcoded static prompt regardless, silently ignoring that choice.
// This reflects whichever question the backend actually selected for THIS
// employer, fetched from /api/employers/:id's pendingInterview field.
function updateChangeReadinessQuestionLabel(pendingInterview) {
  const el = document.getElementById('changeReadinessQuestionText');
  if (!el) return;
  const entry = (pendingInterview || []).find((q) => q.key === 'ADOPTION_SPEED_Q' || q.key === 'CHANGE_HISTORY_Q');
  el.textContent = entry ? `"${entry.text}"` : '"last new tool/process you adopted, and how did that go?"';
}

function renderEmployerProfile(profile, scoring) {
  const empty = document.getElementById('employerProfileEmpty');
  const body = document.getElementById('employerProfileBody');
  if (!profile) {
    empty.hidden = false;
    body.hidden = true;
    return;
  }
  empty.hidden = true;
  body.hidden = false;
  set('stat-readiness', scoring?.changeReadinessScore ?? '—');
  set('stat-readiness-conf', scoring?.changeReadinessConfidence ?? '—');
  set('stat-overall-conf', profile.overallConfidence ?? '—');

  renderNeedsList('emergingNeedsList', profile.emergingNeeds, 'UP');
  renderNeedsList('decliningNeedsList', profile.decliningNeeds, 'DOWN');
}

function renderNeedsList(containerId, needs, direction) {
  const container = document.getElementById(containerId);
  const tpl = document.getElementById('needItemTemplate');
  container.innerHTML = '';
  if (!needs || needs.length === 0) {
    container.innerHTML = '<div class="empty-note">none</div>';
    return;
  }
  const sorted = [...needs].sort((a, b) => b.weight - a.weight);
  for (const need of sorted) {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.need-skill').textContent = need.skillId.replace(/_/g, ' ');
    node.querySelector('.need-crossdomain').textContent = need.crossDomainBoosted ? ' ' : '';
    node.querySelector('.need-weight').textContent = `weight ${need.weight.toFixed(0)}`;
    node.querySelector('.need-horizon').textContent = need.horizon;
    node.querySelector('.need-outcome-btn').addEventListener('click', () => handleRecordSkillShiftOutcome(need, direction));
    container.appendChild(node);
  }
}

async function handleRecordSkillShiftOutcome(need, direction) {
  if (!employerState.currentEmployer) return;
  const outcome = prompt(
    `Did the predicted ${direction === 'UP' ? 'rise' : 'decline'} for "${need.skillId.replace(/_/g, ' ')}" actually happen?\n\nType one of: occurred / did_not_occur / partially / too_early_to_tell`,
    'too_early_to_tell'
  );
  if (!outcome) return;
  const notes = prompt('Any notes? (optional)') || '';
  try {
    await employerApi('POST', `/api/employers/${encodeURIComponent(employerState.currentEmployer)}/feedback/skill-shift`, {
      skillId: need.skillId,
      direction,
      outcome: outcome.trim(),
      notes,
    });
    alert('Outcome recorded.');
  } catch (err) {
    alert(`Could not record outcome: ${err.message}`);
  }
}

function renderRanking(ranked) {
  const table = document.getElementById('rankingTable');
  const tpl = document.getElementById('rankRowTemplate');
  table.innerHTML = `
    <div class="rank-row header-row">
      <span>#</span><span>candidate</span><span>composite</span><span>current</span><span>emerging</span><span>advantage</span><span>confidence</span><span></span>
    </div>`;
  document.getElementById('rankCount').textContent = ranked.length;

  ranked.forEach((m, i) => {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.rank-position').textContent = i + 1;
    node.querySelector('.rank-candidate').textContent = m.candidateId;
    node.querySelector('.rank-composite').textContent = m.compositeFit.toFixed(1);
    node.querySelector('.rank-current').textContent = m.currentFit != null ? m.currentFit.toFixed(1) : '—';
    node.querySelector('.rank-emerging').textContent = m.emergingFit != null ? m.emergingFit.toFixed(1) : '—';
    const advEl = node.querySelector('.rank-advantage');
    if (m.futureAdvantage != null) {
      advEl.textContent = (m.futureAdvantage > 0 ? '+' : '') + m.futureAdvantage.toFixed(1);
      advEl.classList.add(m.futureAdvantage > 0 ? 'positive' : 'negative');
    } else {
      advEl.textContent = '—';
    }
    const confEl = node.querySelector('.rank-confidence');
    confEl.textContent = m.confidence;
    confEl.dataset.state = m.confidence === 'HIGH' ? 'verified' : m.confidence === 'LOW' ? 'unverified' : 'gapFlagged';
    node.querySelector('.rank-outcome-btn').addEventListener('click', () => handleRecordMatchOutcome(m));
    table.appendChild(node);
  });
}

async function handleRecordMatchOutcome(match) {
  if (!employerState.currentEmployer) return;
  const hired = confirm(`Was ${match.candidateId} hired for this role?\n\nOK = yes, Cancel = no`);
  let workedOut = null;
  if (hired) {
    workedOut = prompt('How did it work out? Type one of: yes / no / mixed / too_early_to_tell', 'too_early_to_tell');
    if (!workedOut) return;
  }
  const notes = prompt('Any notes? (optional)') || '';
  try {
    await employerApi(
      'POST',
      `/api/employers/${encodeURIComponent(employerState.currentEmployer)}/candidates/${encodeURIComponent(match.candidateId)}/feedback/match`,
      { hired, workedOut: workedOut ? workedOut.trim() : undefined, notes }
    );
    alert('Outcome recorded.');
  } catch (err) {
    alert(`Could not record outcome: ${err.message}`);
  }
}

async function handleEmployerIntakeSubmit(e) {
  e.preventDefault();
  const fd = new FormData(e.target);
  const employerId = fd.get('employerId').trim();
  if (!employerId) return;

  const roleTasks = fd.get('roleTasks').split(',').map((s) => s.trim()).filter(Boolean);
  const autoProfile = {
    sector: fd.get('sector') || 'unspecified',
    growthStage: fd.get('growthStage'),
    postingLanguageDrift: { hasNewToolMentions: fd.get('hasNewToolMentions') === 'on', addedTerms: [], droppedTerms: [] },
  };

  await employerApi('POST', `/api/employers/${encodeURIComponent(employerId)}/intake`, { autoProfile, roleTasks });
  await refreshEmployerList(employerId);
  await loadCurrentEmployer();
}

async function handleEmployerInterviewSubmit(e) {
  e.preventDefault();
  if (!employerState.currentEmployer) return alert('Save intake for an employer first.');
  const fd = new FormData(e.target);
  const responses = {
    bottleneck: fd.get('bottleneck'),
    friction: fd.get('friction'),
    changeReadinessRaw: fd.get('changeReadinessRaw'),
    futureProjection: fd.get('futureProjection'),
  };
  await employerApi('POST', `/api/employers/${encodeURIComponent(employerState.currentEmployer)}/interview`, responses);
  await employerApi('POST', `/api/employers/${encodeURIComponent(employerState.currentEmployer)}/score`, {});
  await loadCurrentEmployer();
}

async function handleRankCandidates() {
  if (!employerState.currentEmployer) return alert('Select an employer with a future-need profile first.');
  const result = await employerApi('POST', `/api/employers/${encodeURIComponent(employerState.currentEmployer)}/rank`, {});
  renderRanking(result.ranked);
}

async function handleEmployerSeed() {
  const result = await employerApi('POST', '/api/employers/demo/load-fixtures', {});
  await refreshEmployerList(result.loadedEmployerIds[0]);
  await loadCurrentEmployer();
}

// ---------------------------------------------------------------------------
// Config tab
// ---------------------------------------------------------------------------

async function loadConfig() {
  const data = await api('GET', '/api/config');
  renderConfigGroups(data.tunables);
  renderConfigChangeLog(data.changeLog);
}

function renderConfigGroups(tunables) {
  const container = document.getElementById('configGroups');
  container.innerHTML = '';
  const tpl = document.getElementById('configRowTemplate');

  const groups = [...new Set(tunables.map((t) => t.group))];
  for (const group of groups) {
    const label = document.createElement('div');
    label.className = 'config-group-label';
    label.textContent = group;
    container.appendChild(label);

    for (const t of tunables.filter((x) => x.group === group)) {
      const node = tpl.content.cloneNode(true);
      node.querySelector('.config-label').textContent = t.label;
      node.querySelector('.config-default').textContent = `default ${t.default}`;
      const input = node.querySelector('.config-value-input');
      input.value = t.value;
      input.min = t.min;
      input.max = t.max;
      node.querySelector('.config-overridden-badge').textContent = t.isOverridden ? ' ' : '';
      node.querySelector('.config-save-btn').addEventListener('click', () => handleConfigSave(t.key, input.value));
      node.querySelector('.config-reset-btn').addEventListener('click', () => handleConfigReset(t.key));
      container.appendChild(node);
    }
  }
}

function renderConfigChangeLog(entries) {
  const panel = document.getElementById('configChangeLog');
  panel.innerHTML = '';
  document.getElementById('configLogCount').textContent = entries.length;
  for (const e of [...entries].reverse()) {
    const div = document.createElement('div');
    div.className = 'log-entry';
    const action = e.reset ? 'reset' : 'changed';
    div.innerHTML = `<span class="log-tag">${e.key}</span> ${action} ${e.previousValue} \u2192 ${e.newValue} <span style="color:#8a97a3">(${new Date(e.changedAt).toLocaleString()})</span>`;
    panel.appendChild(div);
  }
}

async function handleConfigSave(key, rawValue) {
  const value = Number(rawValue);
  if (Number.isNaN(value)) return alert('Enter a valid number.');
  try {
    await api('POST', `/api/config/${encodeURIComponent(key)}`, { value });
    await loadConfig();
  } catch (err) {
    alert(`Could not save: ${err.message}`);
  }
}

async function handleConfigReset(key) {
  try {
    await api('POST', `/api/config/${encodeURIComponent(key)}/reset`, {});
    await loadConfig();
  } catch (err) {
    alert(`Could not reset: ${err.message}`);
  }
}

async function handleLoadBacklog() {
  const data = await api('GET', '/api/employers/debug/coverage-backlog');
  const panel = document.getElementById('coverageBacklogPanel');
  if (data.unmappedTasks.length === 0 && data.unmappedSkills.length === 0) {
    panel.innerHTML = '<div class="empty-note">nothing unmapped yet — every task/skill seen so far has coverage.</div>';
    return;
  }
  let html = '';
  if (data.unmappedTasks.length) {
    html += '<div class="field-note"><strong>Unmapped task categories:</strong></div>';
    html += data.unmappedTasks.map((t) => `<div class="unreportable-item"><strong>${t.roleTaskId}</strong><span>seen ${t.timesSeen}\u00d7, last ${new Date(t.lastSeenAt).toLocaleString()}</span></div>`).join('');
  }
  if (data.unmappedSkills.length) {
    html += '<div class="field-note" style="margin-top:8px;"><strong>Unmapped employer-skill IDs:</strong></div>';
    html += data.unmappedSkills.map((s) => `<div class="unreportable-item"><strong>${s.needSkillId}</strong><span>seen ${s.timesSeen}\u00d7, last ${new Date(s.lastSeenAt).toLocaleString()}</span></div>`).join('');
  }
  panel.innerHTML = html;
}

async function handleRunDiagnostic() {
  const data = await api('GET', '/api/admin/weight-fitting-report');
  const panel = document.getElementById('weightFittingPanel');
  const renderOne = (label, d) => {
    if (d.status === 'insufficient_data') {
      return `<div class="unreportable-item"><strong>${label}</strong><span>${d.message}</span></div>`;
    }
    return `<div class="field-note"><strong>${label}</strong> (n=${d.sampleSize}): ${JSON.stringify(d, null, 0).replace(/[{}"]/g, '').replace(/,/g, ', ')}</div>`;
  };
  panel.innerHTML = renderOne('Match outcomes', data.matchDiagnostic) + renderOne('Skill-shift outcomes', data.skillShiftDiagnostic);
}

function init() {
  buildSkillOptionsInto(document.getElementById('skillIdSelect'));
  addSelfRatedRow();

  document.getElementById('addSelfRatedRow').addEventListener('click', addSelfRatedRow);
  document.getElementById('baselineForm').addEventListener('submit', handleBaselineSubmit);
  document.getElementById('consentForm').addEventListener('submit', handleConsentSubmit);
  document.getElementById('eventForm').addEventListener('submit', handleEventSubmit);
  document.getElementById('sourceChannel').addEventListener('change', updateConditionalFields);
  document.getElementById('questSelectorBtn').addEventListener('click', handleQuestSelector);
  document.getElementById('decayBtn').addEventListener('click', handleDecay);
  document.getElementById('resetBtn').addEventListener('click', handleReset);
  document.getElementById('seedBtn').addEventListener('click', handleSeed);
  document.getElementById('refreshBtn').addEventListener('click', () => { state.currentUser = document.getElementById('userSelect').value; loadCurrentUser(); });
  document.getElementById('userSelect').addEventListener('change', (e) => { state.currentUser = e.target.value; loadCurrentUser(); });

  document.querySelectorAll('.tab-btn').forEach((btn) => btn.addEventListener('click', () => switchTab(btn.dataset.tab)));
  document.getElementById('employerIntakeForm').addEventListener('submit', handleEmployerIntakeSubmit);
  document.getElementById('employerInterviewForm').addEventListener('submit', handleEmployerInterviewSubmit);
  document.getElementById('rankCandidatesBtn').addEventListener('click', handleRankCandidates);
  document.getElementById('employerSeedBtn').addEventListener('click', handleEmployerSeed);
  document.getElementById('employerRefreshBtn').addEventListener('click', () => { employerState.currentEmployer = document.getElementById('employerSelect').value; loadCurrentEmployer(); });
  document.getElementById('employerSelect').addEventListener('change', (e) => { employerState.currentEmployer = e.target.value; loadCurrentEmployer(); });
  document.getElementById('configRefreshBtn').addEventListener('click', loadConfig);
  document.getElementById('loadBacklogBtn').addEventListener('click', handleLoadBacklog);
  document.getElementById('runDiagnosticBtn').addEventListener('click', handleRunDiagnostic);

  updateConditionalFields();
  refreshUserList().then(loadCurrentUser);
}

init();
