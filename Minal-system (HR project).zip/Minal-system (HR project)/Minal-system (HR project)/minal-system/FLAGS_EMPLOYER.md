# Flags for the Product Owner — Employer-Side Build (Stages 1-4)

Same spirit as `FLAGS.md` on the SSIE side: things the spec left ambiguous,
things this build had to stub because a required external dependency wasn't
in the handoff package, and — most importantly — one real distortion the
demo run caught that a spec read alone wouldn't have surfaced.

---

## 1. Compliance blocker carried forward, not resolved: no scraping implemented

`employer_algorithm_spec.md` §1.1 flags the auto-profile data sources
(LinkedIn, job boards, BuiltWith, etc.) as needing legal/ToS review before
implementation — "a build blocker, not a nice-to-have." This build does not
implement any scraping. `buildAutoProfile` accepts these fields as direct
input instead (e.g. typed into a form or passed via API), with reasonable
defaults for anything not supplied. **This still needs a real decision** on
data-sourcing method (official APIs vs. licensed data vs. manual employer
input) before Stage 1 can run on real, non-manually-entered company data.

---

## 2. O\*NET task ratings are a placeholder table, not the real dataset

`lookupTaskAutomationRating` and `lookupTaskRepetitiveness` (§2.3) are
supposed to map `roleTaskId` to real O\*NET Task Ratings — a real, free,
external dataset this build package didn't include. `src/employer/onetLookup.js`
uses a small hand-written table with plausible relative orderings (data
entry rated highly automatable, legal document review rated more
judgment-heavy) so the pipeline runs end-to-end, but these numbers are
**not sourced from the actual O\*NET database.** Needs a real data-engineering
pass: download O\*NET, map each `roleTaskId` to O\*NET task codes.

---

## 3. `calcAdoptionVelocity` and `estimateSwitchingFriction` — reasoned heuristics, not specified

The spec names these functions and their inputs but doesn't specify their
internal logic. Implemented as simple, transparent heuristics (more newly-
added job-posting terms → higher adoption velocity; regulated sectors and
sparse tech stacks → higher switching friction). Flagging so nobody mistakes
these for validated formulas — they're structurally reasonable placeholders,
same tier as every other unweighted constant in this system.

---

## 4. `extractCurrentSkillsFromJobPosting` stub — and a real distortion it causes, caught by running the demo

This function is *named* in the spec (§3.2) but never actually specified —
real implementation needs NLP over an actual job posting, which isn't part
of this build package. As a placeholder, "current need" skills are
approximated as each role task's DOWN-direction skillId from
`SKILL_SHIFT_MAP` (the thing the role primarily demands today, before any
automation shift).

**Running the demo against `emp_001` (roleTasks spanning coding, content
writing, and design) surfaced a real problem with this placeholder:** all
three tasks' DOWN-direction skills — `boilerplate_coding`,
`draft_generation_speed`, `manual_asset_production` — happen to reconcile to
the exact same single SSIE skill, `adaptability` (each at weight 1.0). That
collapses `currentFit` into effectively being a pure adaptability score for
any employer whose roleTasks span these particular domains, which then
distorts `futureAdvantage` (`emergingFit - currentFit`) in ways that don't
reflect the intended "looks ordinary today, well-positioned for tomorrow"
signal. In the demo run, `future_adapted` candidates ended up with a
**lower** average `futureAdvantage` than `current_specialist` candidates —
backwards from what Definition-of-Done item 3 expects.

**This is a placeholder-stub artifact, not a Stage 4 matching bug** — Stage
4's math correctly computes whatever `currentNeeds` it's handed; the problem
is entirely in what this stub hands it. Confirmed by testing Stage 4 in
isolation with a synthetic profile where `currentNeeds` and `emergingNeeds`
resolve to different SSIE skills (see `test/employer_pipeline.test.js`,
"Stage 4 math is correct in isolation") — `futureAdvantage` behaves exactly
as expected once the confound is removed.

**Needs:** real job-posting NLP for `extractCurrentSkillsFromJobPosting`
before `futureAdvantage` numbers should be treated as meaningful. Until
then, treat `futureAdvantage` from this build as a Stage-4-math
demonstration, not a real signal.

---

## 5. Carried forward verbatim from the source spec's own "Known Limitations"

These were already flagged in `employer_algorithm_spec.md` as product
decisions, not silently resolved by this build:

- **`CW_current` / `CW_emerging` (0.4 / 0.6)** — a product decision about
  whether to hide the current-vs-future tradeoff in one composite number or
  show both fits directly. Implemented at the spec's suggested starting
  point, not decided on the product's behalf.
- **`decliningFitInfo` is informational only, never penalized.** Whether
  heavy concentration in a declining skill (with little else) should count
  as a risk signal is an open product question, same as the SSIE-side
  equivalent (`CW_current`/`CW_emerging` weighting note in `FLAGS.md`).
- **Assumes SSIE and this system share a skillId namespace** — resolved
  *structurally* by the reconciliation map, but the specific mappings and
  the `SSIE_CANONICAL_SKILLS` list itself are still reasoned estimates
  pending domain review (see `skill_taxonomy_reconciliation.md` §6, carried
  forward unchanged).

---

## 6. `T_CONF` is now actually shared, not duplicated — resolves a prior flag

`FLAGS.md` (SSIE side, item #6) flagged that `T_CONF` should be one shared
config value across both systems rather than two independently-set
constants. This build resolves that: `src/employer/constants.js` imports
`T_CONF` directly from the SSIE config module rather than redefining it.

**Update:** with the admin config panel now built (item #11 below), this is
no longer just "the same hardcoded JS constant imported twice" — `T_CONF` is
a single entry (`ssie.T_CONF`) in the shared tunable registry, read by both
`resolveSSIEConfig` and `resolveEmployerConfig`. Editing it once, from
either side's perspective, changes verification thresholds AND match
confidence discounting together, immediately — which is exactly the
"one value, live-editable in one place" outcome the reconciliation doc
recommended. Confirmed by test (`config_and_feedback.test.js`, "T_CONF is
genuinely shared").

---

## 7. `CROSS_DOMAIN_SKILLS` — now implemented as a live-tunable boost (previously flagged as not built)

`employer_algorithm_spec.md` §3.1 recommends a separate lookup giving
judgment/oversight/verification-type skills (`ai_output_judgment`,
`exception_spotting`, etc.) a baseline weight boost, since they generalize
across nearly every mapped task. This was previously flagged as "named but
not built" because the spec doesn't specify a boost magnitude, and inventing
one silently would have violated the "don't fabricate calibration" rule.

**What changed:** the boost is now implemented in Stage 3
(`buildFutureNeedProfile`), applied to any emerging-need skill in
`CROSS_DOMAIN_SKILLS` as `urgency * (1 + CROSS_DOMAIN_BOOST)` before
clamping. The magnitude itself (`employer.CROSS_DOMAIN_BOOST`, default 0.15)
is exposed as a live-editable tunable in the config tab rather than a
hardcoded constant — so instead of silently picking a number, the number is
visible, adjustable, and logged whenever it's changed. Each boosted skill is
also tagged `crossDomainBoosted: true` on the profile (an allowed schema
extension, same pattern as `primitiveVector` on the SSIE side) so it's
visible in the UI, not just applied invisibly.

**Still open:** whether 0.15 is remotely the right order of magnitude is
exactly as unvalidated as every other default in this system — it's now at
least a named, visible, adjustable knob instead of an unbuilt feature.

---

## 8. `SKILL_SHIFT_MAP` coverage — 10 task categories, unmapped tasks silently skip

Exactly as the spec describes (§3.1, Known Limitations #2): real coverage
needed is much larger. This build tracks `profile._unmappedTaskCount` as an
extension field on the future-need profile (not part of the frozen output
schema, added the same way the SSIE side added `primitiveVector` — an
allowed extension, not a break) so unmapped-task coverage gaps are at least
visible per employer, per the spec's recommendation to track this as an ops
metric.

---

## 9. Literal unicode escape sequences in the UI files — caught while writing this guide

`public/index.html` and `public/app.js` had literal `\u2014`-style text
(backslash, u, 2, 0, 1, 4, etc.) sitting in visible UI copy instead of the
actual characters (em dashes, curly quotes). This is a real difference from
the SSIE-side `.js` source files, where the same-looking escapes are valid
and correctly interpreted at runtime — HTML and browser-rendered JS string
literals in a static file do not get that same interpretation, so these were
rendering as literal backslash-u text in the employer tab. Found by checking
the raw file bytes while writing the employer field guide, not by looking at
the rendered page casually. Fixed in both files; verified against a live
server response afterward, not just re-reading the source.

---

## 10. Outcome feedback-loop scaffold — logging only, not calibration

Per `llm_handoff_brief.md` Tier 2: "A feedback-loop mechanism recording real
outcomes (did the predicted skill shift happen, did the matched candidate
work out) on both the employer and candidate sides." Built in
`src/employer/feedback.js` as two logging functions:

- `recordSkillShiftOutcome` — did a specific predicted emerging/declining
  skill need actually materialize, tied to the specific `futureNeedProfile`
  snapshot (`generatedAt`) that predicted it.
- `recordMatchOutcome` — did a specific match turn into a hire, and how did
  it go, with the match's `compositeFit`/`futureAdvantage` snapshotted at
  the time of feedback so later analysis isn't cross-referencing a match
  record that may have since been recomputed with different config values.

**Deliberately not built:** any computed accuracy or calibration score from
this data. `summarizeFeedback` returns raw counts only (`skillShiftOutcomeCount`,
`matchHiredCount`, etc.) and explicitly does not compute something like a
"prediction accuracy rate" — turning a handful of early outcomes into a
percentage would misrepresent noise as signal, exactly the premature-
calibration failure mode this whole build has avoided elsewhere. Confirmed
by test that recording an outcome does not change any subsequent match's
score.

**Needs:** real volume (the spec's own recommended milestone — 20-30 real
employer interviews, run through Stage 4, checked against real hiring
outcomes over time) before this data should inform anything. Until then,
it's a place for real outcomes to land, not a working feedback loop yet.

---

## 11. Admin config panel — the "admin config collection" from Integration Contract §5/§6, now built

Integration Contract §5 describes trust parameters as reading "from the
admin config collection so UC-A03 (Configure Trust Parameters) governs SSIE
weights with zero console changes." This was previously true only in spirit
— every tunable was a hardcoded JS constant. `src/config/adminConfig.js`
now implements the real thing: a registry of every value explicitly called
out as TUNABLE or a product decision (23 total, spanning both SSIE and
employer sides), each editable live via the config tab, with every change
logged and reversible (`getChangeLog`), matching §6's "all parameter changes
logged and reversible" requirement.

**Scope decision:** only values explicitly flagged TUNABLE/product-decision
in the specs and FLAGS docs are exposed — structural constants (e.g.
`TOTAL_CHANNELS`, `MAX_OBSERVATIONS_PER_USER`) are left as plain code, since
surfacing every internal constant as "tunable" would invite edits that break
invariants rather than calibrate a genuine judgment call. If a value isn't
in the config tab, that's why.

**Still not resolved:** there's no per-user or per-employer override, no
role-based access control on who can edit these (anyone with access to the
UI can change global scoring behavior for everyone), and no A/B or shadow-
mode testing of a config change before it goes live — all real product
decisions for whoever takes this further.

---

## 12. Coverage backlog — unmapped tasks/skills now actually persisted, not just counted

`SKILL_SHIFT_MAP` and `RECONCILIATION_MAP` were always documented as failing
gracefully on unmapped entries ("skip + log"), but the "log" half was never
real — `_unmappedTaskCount` was an in-memory number recomputed (and thrown
away) on every call, and Stage 4's `unmapped: true` flag was returned per
lookup and never stored anywhere. Caught during a full audit pass, not by
running the demo — the demo data happens to only use covered task
categories, so this gap was invisible until specifically checked for.

**What changed:** `src/employer/coverageBacklog.js` persists every unmapped
task category and unmapped employer-skill ID to `/reconciliationBacklog`,
with a hit count and last-seen timestamp, deduplicated (seeing the same
unmapped task twice increments a counter, doesn't create a second entry).
Exposed via `GET /api/employers/debug/coverage-backlog` and a "check
coverage backlog" button in the config tab.

---

## 13. Weight-fitting pipeline scaffold — the one Tier 2 item from the original brief that hadn't been built

`llm_handoff_brief.md`'s Tier 2 list named this explicitly: "Employer-side
weight-fitting pipeline ... structure it to accept real labeled outcomes
later." Everything else in Tier 2 had been built across earlier passes; this
one was missing, found during a full audit against the original brief
rather than by anyone hitting a missing feature in normal use.

**What was built:** `src/employer/weightFitting.js`. Below a volume gate
(`employer.MIN_MATCH_OUTCOMES_FOR_DIAGNOSTIC` / `..._SKILLSHIFT_...`, both
live-tunable, default 10), it returns `insufficient_data` and nothing else.
Above the gate, it returns a **descriptive diagnostic** — e.g. "of hires
that worked out, what was their average compositeFit at match time, versus
hires that didn't" — explicitly labeled as not a weight recommendation.
Tested that running it never writes back to `adminConfig`: recording
outcomes and running the diagnostic as many times as you like cannot
silently change what any candidate or employer actually sees.

**Needs:** real volume, same as everything outcome-related in this system.
10 is a low bar chosen so the mechanism is exercisable, not a claim that 10
outcomes means anything. Whoever eventually acts on this diagnostic should
be looking at hundreds of outcomes, not tens, before touching a real weight.

---

## 14. Micro-interview question label was static, ignoring the backend's actual adaptive choice

`selectMicroInterviewSet` (Stage 1) genuinely picks between two different
change-readiness questions depending on `hasNewToolMentions` — "how long
did it take your team to actually use [tool] daily" vs. "what's the last
new tool/process you adopted" — and the API already exposed this via
`pendingInterview`. The UI form never used it: it always showed the second
phrasing as a hardcoded label, regardless of what the backend actually
selected. Found while writing user documentation and double-checking a
claim about "the checkbox changes which question gets asked" against the
live UI, rather than the backend spec.

**Fixed:** the change-readiness label now reads `pendingInterview` from
`GET /api/employers/:id` and displays whichever question the backend
actually selected for this specific employer. Both employer field guides
updated to describe this correctly.
