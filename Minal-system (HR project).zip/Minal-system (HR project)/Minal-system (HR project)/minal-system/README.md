# MINAL
### Hiring, decided by what you can do — not who you know.

MINAL verifies people's real ability from how they actually work, and
matches them to opportunity based on where a role is *heading* — not just
where it is today.

---

## The problem

Hiring — especially across Africa's job market — runs on referrals, not
proof. Employers don't have time to vet strangers, so trust defaults to
proximity: who you know, not what you can do. That locks out capable
people no matter their ability, and leaves employers hiring for a job
that's already changing underneath them. The cost isn't just individual —
untapped talent means untapped growth, for people, companies, and the
wider economy.

## Our solution

MINAL verifies real skill from real behavior — no long tests, no
exhaustive self-reported forms — and matches people to work based on both
what a role needs **today** and what it will need **next**.

- **For workers:** your actual work becomes your proof — not your network.
- **For employers:** see who's genuinely ready now, *and* what skills your
  business will need to hire for 2–3 years out.
- **Built API-first**, so platforms like LinkedIn or job boards like
  Jobberman could integrate with it directly.

![System architecture](assets/architecture_diagram.png)

## How AI is used

- Reads real evidence — a work log, how someone handled a mistake — and
  extracts genuine behavioral signal from it. Not keyword-matching.
- Runs on **Gemini 2.5 Flash → Groq (Llama 3.3) → OpenRouter (DeepSeek
  R1)**, with automatic fallback between them.
- Used *only* where it's actually needed: every score, threshold, and
  match decision downstream stays fully rule-based and auditable.

## See it in action

![MINAL console, live](assets/screenshot_candidates_tab.png)

## Try it yourself — 3 steps, about 2 minutes

**Step 0 — install Node.js** (skip this if you already have it): go to
[nodejs.org](https://nodejs.org), download the **LTS** version for your
computer, and run the installer like any normal program — no extra setup.

**Then, from inside the project folder:**
```bash
npm install
npm start
```

**Open `http://localhost:3000` in your browser.** That's it — no API
keys, no database setup, nothing else to configure.

If you don't have `git` and this was given to you as a `.zip`: just unzip
it and open a terminal inside that folder, then run the two commands above.

---

📄 **Want the full technical breakdown** — architecture, algorithms, every
API route, what's real vs. placeholder? → [`TECHNICAL_DETAILS.md`](TECHNICAL_DETAILS.md)

🚩 **Want the complete, honest list of limitations?** → [`FLAGS.md`](FLAGS.md) / [`FLAGS_EMPLOYER.md`](FLAGS_EMPLOYER.md)
