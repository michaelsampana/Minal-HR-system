# Demo Data — What It Is and Isn't

- `employers_demo.json` — 40 synthetic employer records (Stage 1 output shape: autoProfile + interviewResponses)
- `candidates_demo.json` — 60 synthetic candidates, matching SSIE's real `SSIESkillOutput` schema exactly (numeric confidence 0-100, stability metrics, evidence trail, self-report gap), keyed by SSIE's canonical skill taxonomy

## What this data is for

- Testing the full pipeline (SSIE scoring + Employer Stages 1-4 + reconciliation lookup) runs end-to-end without schema/logic errors
- Checking output shapes and ranges look sane
- `_debug_injected_label` (employers) lets you check the Stage 2 text coder recovers the label the interview text was generated from
- `_debug_profile_type` (candidates) lets you check Stage 4 matching produces sensible rankings — `future_adapted` candidates should generally score higher on `emergingFit`/`futureAdvantage` than `current_specialist` candidates

**Remove or ignore all `_debug_*` fields before treating this as real production data.**

## What this data is NOT for

- It cannot validate or calibrate the actual weights/magnitudes in either spec. Text and scores were generated using the same logic the pipeline scores against — this proves the pipeline runs, not that the underlying model is accurate.
- Real calibration requires real employer interviews and real candidate engagement data, checked against real outcomes over time.

## Regenerating

Run `python3 generate_demo_data.py` — fixed random seed (42) for reproducibility.
