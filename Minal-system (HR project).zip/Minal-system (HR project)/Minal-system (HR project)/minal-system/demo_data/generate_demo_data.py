"""
Synthetic demo data generator — v2, SSIE-schema-accurate.

Changes from v1:
- Candidates now use SSIE's actual canonical skill taxonomy (SSIE_CANONICAL_SKILLS)
  instead of employer-side task-specific skillIds.
- Candidate skill records match the real SSIESkillOutput shape from the
  Integration Contract (score, confidence as NUMERIC 0-100, contextTags,
  evidenceTrail, selfReportGap, stability{}, negativeEvidenceCount).
- Employer demo data unchanged in structure, still keyed to SKILL_SHIFT_MAP
  task categories.

STILL NOT VALIDATION DATA. See README.md. This generator produces data shaped
correctly for pipeline testing; it does not produce data that can calibrate
weights, since scores are assigned by the same logic the pipeline will score
against.
"""

import json
import random
from datetime import datetime, timezone, timedelta

random.seed(42)

# ---------------------------------------------------------------------------
# SSIE canonical taxonomy (see skill_taxonomy_reconciliation.md §1)
# ---------------------------------------------------------------------------

SSIE_CANONICAL_SKILLS = [
    "communication",
    "adaptability",
    "leadership",
    "critical_thinking",
    "conflict_resolution",
    "initiative",
    "collaboration",
    "emotional_regulation",
    "learning_agility",
    "attention_to_detail",
]

CONTEXT_TAGS_POOL = ["written", "dispute", "quest", "workLog", "deliverableCycle", "peerReview"]

# ---------------------------------------------------------------------------
# Employer-side reference data (unchanged from v1)
# ---------------------------------------------------------------------------

TASK_CATEGORIES = [
    "customer_care_ticket_response", "basic_data_entry", "bookkeeping_transaction_entry",
    "junior_content_writing", "entry_level_coding_implementation", "recruitment_resume_screening",
    "warehouse_inventory_tracking", "sales_lead_qualification", "basic_graphic_design",
    "legal_document_review_junior",
]

SECTORS = ["retail", "fintech", "healthcare_admin", "logistics", "saas", "legal_services", "manufacturing", "marketing_agency"]
GROWTH_STAGES = ["seed", "growth", "mature"]

TIME_PHRASES = {
    "FAST": ["within a day", "within a week", "picked it up fast", "took no time at all"],
    "MODERATE": ["within a month", "took some time but eventually got there", "a couple weeks"],
    "SLOW": ["took forever", "took a couple months", "dragged on longer than expected"],
    "STALLED": ["still hasn't really stuck", "we gave up on it", "haven't gotten around to using it properly"],
}
SENTIMENT_PHRASES = {
    "POSITIVE": ["the team loved it", "it made things a lot easier", "honestly no complaints"],
    "NEGATIVE": ["it was pretty painful honestly", "there was a lot of pushback from the team", "people found it confusing"],
}
OUTCOME_PHRASES = {
    "ADOPTED": ["it's still part of how we work now", "everyone uses it daily at this point"],
    "ABANDONED": ["we ended up going back to the old way", "we stopped using it after a while"],
}
BOTTLENECK_TEMPLATES = [
    "If that role sat empty for a month, {task_desc} would just pile up and customers/clients would notice fast.",
    "Honestly the whole team would feel it within days — {task_desc} is the thing that keeps everything else moving.",
    "We'd probably survive a couple weeks before {task_desc} became a real problem.",
]
FRICTION_TEMPLATES = [
    "The most repetitive part is definitely {task_desc}, we do it constantly and it rarely changes.",
    "Honestly {task_desc} eats most of the day and it's the same steps every time.",
]
FUTURE_PROJECTION_TEMPLATES = [
    "If a competitor solved this, I'd guess it looks like less manual {task_desc} and more people just double-checking the output.",
    "Probably fewer people doing the repetitive part and more people catching mistakes or handling the weird edge cases.",
]
TASK_DESCRIPTIONS = {
    "customer_care_ticket_response": "responding to support tickets",
    "basic_data_entry": "entering data into the system",
    "bookkeeping_transaction_entry": "reconciling transactions",
    "junior_content_writing": "drafting written content",
    "entry_level_coding_implementation": "writing routine implementation code",
    "recruitment_resume_screening": "screening resumes",
    "warehouse_inventory_tracking": "tracking inventory counts",
    "sales_lead_qualification": "qualifying inbound leads",
    "basic_graphic_design": "producing basic design assets",
    "legal_document_review_junior": "reviewing standard contract clauses",
}


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def rand_date_within(days_back):
    return (datetime.now(timezone.utc) - timedelta(days=random.randint(0, days_back))).isoformat()


def build_change_readiness_text(profile_bucket):
    if profile_bucket == "high":
        time_b, sent_b, out_b = "FAST", "POSITIVE", "ADOPTED"
    elif profile_bucket == "medium":
        time_b = random.choice(["MODERATE", "SLOW"])
        sent_b = random.choice(["POSITIVE", "NEGATIVE"])
        out_b = random.choice(["ADOPTED", "ABANDONED"])
    else:
        time_b, sent_b, out_b = "STALLED", "NEGATIVE", "ABANDONED"

    parts = [
        f"When we rolled out our last new tool, {random.choice(TIME_PHRASES[time_b])}.",
        random.choice(SENTIMENT_PHRASES[sent_b]).capitalize() + ".",
        random.choice(OUTCOME_PHRASES[out_b]).capitalize() + ".",
    ]
    random.shuffle(parts)
    return " ".join(parts), {"time_bucket": time_b, "sentiment_bucket": sent_b, "outcome_bucket": out_b}


def build_employer(idx):
    employer_id = f"emp_{idx:03d}"
    sector = random.choice(SECTORS)
    growth_stage = random.choice(GROWTH_STAGES)
    tasks = random.sample(TASK_CATEGORIES, random.randint(1, 3))
    readiness_bucket = random.choices(["high", "medium", "low"], weights=[0.3, 0.4, 0.3])[0]
    change_readiness_text, injected_label = build_change_readiness_text(readiness_bucket)
    task_desc = TASK_DESCRIPTIONS[tasks[0]]

    auto_profile = {
        "sector": sector,
        "headcountTrend": {
            "last12mo": random.choice(["growing", "flat", "shrinking"]),
            "byDept": {"ops": random.choice([-2, -1, 0, 1, 2]), "engineering": random.choice([0, 1, 2, 3])},
        },
        "growthStage": growth_stage,
        "postingLanguageDrift": {
            "hasNewToolMentions": random.random() < 0.4,
            "addedTerms": random.sample(["AI", "automation", "copilot", "self-serve", "workflow tool"], k=random.randint(0, 2)),
            "droppedTerms": random.sample(["manual entry", "phone support", "paper filing"], k=random.randint(0, 1)),
        },
        "techStackSignals": random.sample(["Zendesk", "Salesforce", "QuickBooks", "Notion", "Slack", "Jira", "HubSpot"], k=random.randint(1, 3)),
        "leadershipChanges": [] if random.random() < 0.7 else [{"role": "Head of Ops", "hiredMonthsAgo": random.randint(1, 11)}],
        "capturedAt": rand_date_within(3),
    }

    interview_responses = {
        "bottleneck": random.choice(BOTTLENECK_TEMPLATES).format(task_desc=task_desc),
        "friction": random.choice(FRICTION_TEMPLATES).format(task_desc=task_desc),
        "changeReadinessRaw": change_readiness_text,
        "futureProjection": random.choice(FUTURE_PROJECTION_TEMPLATES).format(task_desc=task_desc),
    }

    return {
        "employerId": employer_id,
        "autoProfile": auto_profile,
        "interviewResponses": interview_responses,
        "roleTasks": tasks,
        "intakeComplete": True,
        "intakeCompletedAt": rand_date_within(1),
        "_debug_injected_label": injected_label,
        "_debug_readiness_bucket": readiness_bucket,
    }


def build_ssie_skill_output(skill_name, profile_type):
    """
    Builds one SSIESkillOutput record (Integration Contract §1.2), with score
    and confidence driven by profile_type so Stage 4 matching behavior can be
    sanity-checked against a known expectation.
    """
    judgment_skills = {"critical_thinking", "learning_agility", "adaptability"}

    if profile_type == "future_adapted" and skill_name in judgment_skills:
        score = random.randint(65, 95)
    elif profile_type == "current_specialist" and skill_name in {"attention_to_detail", "collaboration"}:
        score = random.randint(60, 85)
    elif profile_type == "low_data":
        score = random.randint(20, 60)
    else:
        score = random.randint(30, 90)

    confidence = random.randint(20, 95) if profile_type != "low_data" else random.randint(10, 40)
    self_assessed = min(100, max(0, score + random.randint(-15, 15)))

    return {
        "skillName": skill_name,
        "score": score,
        "confidence": confidence,  # NUMERIC 0-100, per Integration Contract §1.2 — not a label
        "contextTags": random.sample(CONTEXT_TAGS_POOL, k=random.randint(1, 3)),
        "evidenceTrail": [f"obs_{random.randint(1000,9999)}" for _ in range(random.randint(1, 5))],
        "selfReportGap": self_assessed - score,
        "stability": {
            "consistency": round(random.uniform(0.3, 0.95), 2),
            "degradationSlope": round(random.uniform(-0.3, 0.1), 2),
            "recoveryTime": round(random.uniform(0.1, 0.9), 2),
            "transferCount": random.randint(1, 4),
            "initiativeRatio": round(random.uniform(0.1, 0.9), 2),
        },
        "negativeEvidenceCount": random.randint(0, 3),
        "lastComputedAt": now_iso(),
    }


def build_candidate(idx):
    candidate_id = f"cand_{idx:03d}"
    profile_type = random.choices(
        ["current_specialist", "future_adapted", "mixed", "low_data"],
        weights=[0.3, 0.25, 0.3, 0.15],
    )[0]

    n_skills = {"current_specialist": 4, "future_adapted": 6, "mixed": 7, "low_data": 2}[profile_type]
    chosen_skills = random.sample(SSIE_CANONICAL_SKILLS, min(n_skills, len(SSIE_CANONICAL_SKILLS)))

    skill_profile = {skill: build_ssie_skill_output(skill, profile_type) for skill in chosen_skills}

    return {
        "candidateId": candidate_id,
        "skillProfile": skill_profile,   # keyed by SSIE_CANONICAL_SKILLS, matching real SSIE output
        "_debug_profile_type": profile_type,
    }


def main():
    employers = [build_employer(i + 1) for i in range(40)]
    candidates = [build_candidate(i + 1) for i in range(60)]

    with open("employers_demo.json", "w") as f:
        json.dump(employers, f, indent=2)
    with open("candidates_demo.json", "w") as f:
        json.dump(candidates, f, indent=2)

    print(f"Generated {len(employers)} employers -> employers_demo.json")
    print(f"Generated {len(candidates)} candidates -> candidates_demo.json (SSIE-schema-accurate)")


if __name__ == "__main__":
    main()
