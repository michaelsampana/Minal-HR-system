// Demo runner for the employer-side pipeline (Stages 1-4 + reconciliation).
//
// Uses the ACTUAL demo fixtures from the build package:
// - candidates_demo.json is loaded directly into the store at the paths the
//   SSIE pipeline itself would have written to, since it already matches the
//   real SSIESkillOutput shape (per demo_data_README.md).
// - employers_demo.json employer records are fed through Stage 1 intake
//   as-is (they already match the Stage 1 output shape).
//
// This directly exercises the handoff brief's Definition of Done item 3:
// "future_adapted candidates should generally show higher emergingFit /
// futureAdvantage than current_specialist candidates."

const fs = require('fs');
const path = require('path');
const { JSONStore } = require('../src/db/store');
const employer = require('../src/employer/index');

const DB_PATH = path.join(__dirname, '..', 'data', 'employer_demo_db.json');
const DEMO_DIR = path.join(__dirname, '..', 'demo_data');

function loadJSON(file) {
  return JSON.parse(fs.readFileSync(path.join(DEMO_DIR, file), 'utf8'));
}

/**
 * Loads a candidates_demo.json record directly into the store paths the SSIE
 * pipeline would itself have written to, deriving a verificationState with
 * the same threshold rule Stage 4 (SSIE) uses, so countVerifiedSkills works.
 */
function loadCandidateIntoStore(store, candidateRecord) {
  const { candidateId, skillProfile } = candidateRecord;
  for (const [skillId, output] of Object.entries(skillProfile)) {
    store.set(`/users/${candidateId}/softSkillProfile/${skillId}`, output);
    const verified = output.score >= 70 && output.confidence >= 60;
    store.set(`/users/${candidateId}/skillClaims/${skillId}`, {
      skillId,
      skillType: 'soft',
      verificationState: verified ? 'verified' : 'unverified',
    });
  }
}

function main() {
  const store = new JSONStore(DB_PATH);
  store.data = {};
  store._save();

  console.log('=== Employer Pipeline Demo — Stages 1-4 ===\n');

  const employersDemo = loadJSON('employers_demo.json');
  const candidatesDemo = loadJSON('candidates_demo.json');

  // Load a candidate pool (first 15) directly into the store.
  const candidatePool = candidatesDemo.slice(0, 15);
  for (const c of candidatePool) loadCandidateIntoStore(store, c);
  console.log(`Loaded ${candidatePool.length} candidates directly from candidates_demo.json.\n`);

  // Pick one employer record to run through the full pipeline.
  const employerRecord = employersDemo[0];
  console.log(`--- Stage 1: intake for ${employerRecord.employerId} (sector: ${employerRecord.autoProfile.sector}) ---`);
  employer.employerIntake(store, employerRecord.employerId, employerRecord.autoProfile, employerRecord.roleTasks);
  employer.submitInterviewResponses(store, employerRecord.employerId, employerRecord.interviewResponses);
  console.log(`roleTasks: ${employerRecord.roleTasks.join(', ')}`);
  console.log(`_debug_injected_label (from fixture, for validation only): ${JSON.stringify(employerRecord._debug_readiness_bucket)}\n`);

  console.log('--- Stage 2-3: scoring + future-need profile ---');
  const { scoring, profile } = employer.scoreAndBuildProfile(store, employerRecord.employerId);
  console.log(`changeReadinessScore: ${scoring.changeReadinessScore} (confidence: ${scoring.changeReadinessConfidence})`);
  console.log(`changeReadinessSignals: ${JSON.stringify(scoring.changeReadinessSignals)}`);
  console.log(`overallConfidence: ${profile.overallConfidence}`);
  console.log(`emergingNeeds: ${JSON.stringify(profile.emergingNeeds, null, 2)}`);
  console.log(`currentNeeds: ${JSON.stringify(profile.currentNeeds)}`);
  console.log(`decliningNeeds count: ${profile.decliningNeeds.length}\n`);

  console.log('--- Stage 4: ranking the candidate pool ---');
  const candidateIds = candidatePool.map((c) => c.candidateId);
  const ranked = employer.rankCandidatesForEmployer(store, employerRecord.employerId, candidateIds);

  const debugLabels = Object.fromEntries(candidatesDemo.map((c) => [c.candidateId, c._debug_profile_type]));

  console.log('\nRank | candidateId | compositeFit | currentFit | emergingFit | futureAdvantage | confidence | (debug label)');
  ranked.forEach((m, i) => {
    console.log(
      `${String(i + 1).padStart(4)} | ${m.candidateId} | ${fmt(m.compositeFit)} | ${fmt(m.currentFit)} | ${fmt(m.emergingFit)} | ${fmt(m.futureAdvantage)} | ${m.confidence.padEnd(6)} | ${debugLabels[m.candidateId]}`
    );
  });

  // --- Definition-of-done check #3: future_adapted should generally beat current_specialist on emergingFit/futureAdvantage ---
  console.log('\n--- Sanity check vs. debug labels (handoff brief Definition of Done #3) ---');
  const byLabel = { future_adapted: [], current_specialist: [] };
  for (const m of ranked) {
    const label = debugLabels[m.candidateId];
    if (byLabel[label]) byLabel[label].push(m);
  }
  const avg = (arr, field) => (arr.length ? arr.reduce((s, m) => s + (m[field] ?? 0), 0) / arr.length : null);
  const avgEmergingFuture = avg(byLabel.future_adapted, 'emergingFit');
  const avgEmergingCurrent = avg(byLabel.current_specialist, 'emergingFit');
  const avgAdvFuture = avg(byLabel.future_adapted, 'futureAdvantage');
  const avgAdvCurrent = avg(byLabel.current_specialist, 'futureAdvantage');

  console.log(`future_adapted (n=${byLabel.future_adapted.length}): avg emergingFit=${fmt(avgEmergingFuture)}, avg futureAdvantage=${fmt(avgAdvFuture)}`);
  console.log(`current_specialist (n=${byLabel.current_specialist.length}): avg emergingFit=${fmt(avgEmergingCurrent)}, avg futureAdvantage=${fmt(avgAdvCurrent)}`);

  const emergingFitOk = avgEmergingFuture != null && avgEmergingCurrent != null && avgEmergingFuture > avgEmergingCurrent;
  const futureAdvOk = avgAdvFuture != null && avgAdvCurrent != null && avgAdvFuture > avgAdvCurrent;

  console.log(emergingFitOk ? 'PASS on emergingFit — future_adapted candidates score higher, as expected.' : 'FLAG on emergingFit — did not come out as expected on this run/pool.');
  console.log(
    futureAdvOk
      ? 'PASS on futureAdvantage — future_adapted candidates score higher, as expected.'
      : 'FLAG on futureAdvantage — future_adapted candidates did NOT score higher than current_specialist here (see FLAGS_EMPLOYER.md item #4: this run\u2019s currentNeeds stub happens to collapse onto a single SSIE skill for this employer\u2019s multi-domain roleTasks, distorting currentFit and therefore futureAdvantage \u2014 this is a placeholder-stub artifact, not validated Stage 4 matching behavior).'
  );

  console.log(`\nFull run state persisted to ${DB_PATH}`);
}

function fmt(n) {
  return n == null ? 'null  ' : n.toFixed(1).padStart(6);
}

main();
