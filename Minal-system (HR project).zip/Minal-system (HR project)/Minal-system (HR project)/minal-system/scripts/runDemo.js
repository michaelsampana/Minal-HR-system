// Demo runner for the SSIE candidate-side pipeline (Stages 0-7).
//
// This is NOT the employers_demo.json / candidates_demo.json data from the
// build package — those already contain post-Stage-3 SSIESkillOutput
// records (Stage 4 matching test fixtures) and don't include raw evidence
// (work logs, dispute messages, etc.) to run through Stages 0-2. This script
// generates synthetic RAW EVIDENCE and runs it through the full pipeline
// from scratch, which is what actually exercises Stages 0-7 end-to-end.
//
// Run: node scripts/runDemo.js

const path = require('path');
const { JSONStore } = require('../src/db/store');
const ssie = require('../src/ssie/index');

const DB_PATH = path.join(__dirname, '..', 'data', 'demo_db.json');

function ts(daysAgo = 0) {
  return new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000).toISOString();
}

async function main() {
  const store = new JSONStore(DB_PATH);
  store.data = {}; // fresh run each time for a clean demo
  store._save();

  console.log('=== SSIE Pipeline Demo — Stages 0-7 ===\n');

  // ---- Stage 0: onboard two users ----
  console.log('--- Stage 0: Baseline calibration ---');
  ssie.captureBaseline(store, 'user_alice', {
    keystrokes: Array.from({ length: 200 }, (_, i) => ({ ts_ms: i * 300, char: 'x' })),
    textEdits: [{ insertions: 400, deletions: 40 }],
    responseTimes: [4000, 5200, 4800, 6000, 5100],
    selfRatedSkills: [
      { skillId: 'communication', rating: 80 },
      { skillId: 'critical_thinking', rating: 60 },
    ],
  });
  ssie.captureBaseline(store, 'user_bob', {
    keystrokes: Array.from({ length: 120 }, (_, i) => ({ ts_ms: i * 500, char: 'x' })),
    textEdits: [{ insertions: 300, deletions: 150 }],
    responseTimes: [9000, 11000, 8500],
    selfRatedSkills: [{ skillId: 'communication', rating: 85 }],
  });
  console.log('Baselines captured for user_alice, user_bob.\n');

  // grant dispute-channel consent for alice (strictly opt-in per Integration Contract §8)
  store.set('/users/user_alice/consent', { dispute: true });
  store.set('/users/user_bob/consent', { dispute: false });

  // ---- Stage 1-5: feed a realistic evidence sequence for Alice on "communication" ----
  console.log('--- Stages 1-5: evidence intake -> scoring -> routing (user_alice, communication) ---');

  const aliceEvents = [
    {
      sourceChannel: 'workLog',
      userId: 'user_alice',
      skillIds: ['communication'],
      engagementId: 'eng_001',
      text: 'The client seemed confused about the timeline, so I checked in and clarified the deliverable dates before they escalated it.',
      observedAt: ts(30),
    },
    {
      sourceChannel: 'deliverableCycle',
      userId: 'user_alice',
      skillIds: ['communication'],
      engagementId: 'eng_002',
      deliverableId: 'del_001',
      verdict: 'rejected',
      observedAtMs: Date.now() - 25 * 86400000,
      observedAt: ts(25),
    },
    {
      sourceChannel: 'deliverableCycle',
      userId: 'user_alice',
      skillIds: ['communication'],
      engagementId: 'eng_002',
      deliverableId: 'del_001',
      verdict: 'resubmitted',
      resubmissionNotes: 'Reworked the summary based on your feedback and clarified the ambiguous section — retested against the original brief.',
      observedAtMs: Date.now() - 23 * 86400000,
      observedAt: ts(23),
    },
    {
      sourceChannel: 'dispute',
      userId: 'user_alice',
      skillIds: ['communication'],
      engagementId: 'eng_003',
      text: 'I understand the frustration — let me walk through what happened and how we can fix it going forward.',
      observedAt: ts(18),
    },
    {
      sourceChannel: 'endorsement',
      userId: 'user_alice',
      skillIds: ['communication'],
      endorserTrustWeight: 0.78,
      observedAt: ts(10),
    },
    {
      sourceChannel: 'quest',
      userId: 'user_alice',
      skillIds: ['communication'],
      text: 'I noticed the teammate was stuck, asked what they had tried already, and suggested checking the auth logs next — turned out to be a stale token.',
      observedAt: ts(5),
    },
    {
      sourceChannel: 'peerReview',
      userId: 'user_alice',
      skillIds: ['communication'],
      reviewerRatings: { sense: 0.7, act: 0.75 },
      observedAt: ts(2),
    },
  ];

  for (const event of aliceEvents) {
    const result = await ssie.processEngagementEvent(store, event);
    if (result.skipped) {
      console.log(`  [skipped: ${event.sourceChannel}] ${result.reason}`);
    } else {
      console.log(
        `  [${event.sourceChannel}] obs ${result.obs.obsId} -> polarity ${result.obs.polarity}, ` +
          `constraintLevel ${result.obs.modifiers.constraintLevel}, provider=${result.obs.providerUsed || 'n/a'}`
      );
    }
  }

  const aliceProfile = store.get('/users/user_alice/softSkillProfile/communication');
  console.log('\nuser_alice "communication" SSIESkillOutput after 7 observations across 5 channels:');
  console.log(JSON.stringify(aliceProfile, null, 2));

  const aliceClaim = store.get('/users/user_alice/skillClaims/communication');
  console.log(`\nverificationState: ${aliceClaim.verificationState} (score=${aliceProfile.score.toFixed(1)}, confidence=${aliceProfile.confidence.toFixed(1)})`);

  const aliceTrustRecord = store.get('/trustRecords/user_alice');
  console.log('\nuser_alice trustRecord.scoreBreakdown:');
  console.log(JSON.stringify(aliceTrustRecord.scoreBreakdown, null, 2));

  // ---- Bob: too little evidence -> should stay unreportable ----
  console.log('\n--- Stages 1-5: thin evidence case (user_bob, communication) — should stay unreportable ---');
  await ssie.processEngagementEvent(store, {
    sourceChannel: 'workLog',
    userId: 'user_bob',
    skillIds: ['communication'],
    engagementId: 'eng_101',
    text: 'Replied to the client email.',
    observedAt: ts(3),
  });
  const bobClaim = store.get('/users/user_bob/skillClaims/communication');
  console.log(`user_bob "communication" verificationState: ${bobClaim.verificationState || 'unverified'} (reason: ${bobClaim._unreportableReason})`);

  // dispute consent test — bob has NOT opted in, so a dispute event should skip
  console.log('\n--- Consent gate test (user_bob has NOT opted into dispute channel) ---');
  const bobDisputeResult = await ssie.processEngagementEvent(store, {
    sourceChannel: 'dispute',
    userId: 'user_bob',
    skillIds: ['communication'],
    engagementId: 'eng_102',
    text: 'This is not my fault, the client gave bad requirements.',
    observedAt: ts(1),
  });
  console.log('Result:', bobDisputeResult);

  // ---- Idempotency guard test ----
  console.log('\n--- Idempotency guard test (re-firing eng_001) ---');
  const dup = await ssie.processEngagementEvent(store, aliceEvents[0]);
  console.log('Result:', dup);

  // ---- Stage 6: adaptive quest selection ----
  console.log('\n--- Stage 6: adaptive quest selector (heuristic, not the deferred ML bandit) ---');
  const invitations = ssie.ssieAdaptiveQuestSelector(store, ['user_alice', 'user_bob']);
  console.log(JSON.stringify(invitations, null, 2));

  // ---- Stage 7: decay & maintenance ----
  console.log('\n--- Stage 7: decay & recompute ---');
  const decaySummary = await ssie.ssieDecayAndRecompute(store, ssie.recomputeSkillProfile, ['user_alice', 'user_bob']);
  console.log(JSON.stringify(decaySummary, null, 2));

  // ---- Shape check against the real SSIESkillOutput contract (Integration Contract §1.2) ----
  console.log('\n--- Output shape check vs. SSIESkillOutput contract §1.2 ---');
  const requiredKeys = [
    'skillName', 'score', 'confidence', 'contextTags', 'evidenceTrail',
    'selfReportGap', 'stability', 'negativeEvidenceCount', 'lastComputedAt',
  ];
  const missing = requiredKeys.filter((k) => !(k in aliceProfile));
  console.log(missing.length === 0 ? 'PASS — all §1.2 fields present.' : `FAIL — missing: ${missing.join(', ')}`);
  console.log('(Also present: primitiveVector — an intentional, contract-compliant extension; see FLAGS.md #1.)');

  console.log(`\nFull run state persisted to ${DB_PATH}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
