# Demo

No recorded video yet. Until one exists, here are three ways to see the
system run for real, in order of least to most setup:

## 1. Watch a scripted run in your terminal (30 seconds, no setup)
```bash
node scripts/runDemo.js           # SSIE candidate-side pipeline, Stages 0-7
node scripts/runEmployerDemo.js   # Employer-side pipeline, Stages 1-4
```
Prints a full, human-readable trace: evidence going in, scores coming out,
verification states being decided, candidates being ranked.

## 2. Click through the live app (2 minutes)
```bash
npm install && npm start
```
Open `localhost:3000`, click "load sample walkthrough" (candidates tab) and
"load sample employers + candidates" (employers tab), then "run ranking."

## 3. Read the walkthrough guides
`SSIE_Field_Guide.docx` and `Employer_Field_Guide.docx` in the project root
walk through what every number on screen means, with worked examples.

See `assets/screenshot_candidates_tab.png` for a real screenshot of the
scored, ranked output described above, and `assets/architecture_diagram.png`,
`assets/ssie_pipeline_diagram.png`, `assets/employer_pipeline_diagram.png`
for how the system is put together.
