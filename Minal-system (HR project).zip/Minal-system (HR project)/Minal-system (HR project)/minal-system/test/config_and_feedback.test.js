const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('os');
const path = require('path');

const { JSONStore } = require('../src/db/store');
const adminConfig = require('../src/config/adminConfig');
const employer = require('../src/employer/index');
const { scoreSkill } = require('../src/ssie/stage3_skillScoring');
const ssie = require('../src/ssie/index');

function freshStore() {
  const p = path.join(os.tmpdir(), `config_test_${Date.now()}_${Math.random().toString(36).slice(2)}.json`);
  return new JSONStore(p);
}

// ---------------------------------------------------------------------------
// Admin config
// ---------------------------------------------------------------------------

test('admin config: unedited tunables return their registry default', () => {
  const store = freshStore();
  const value = adminConfig.getTunable(store, 'ssie.T_CONF');
  assert.equal(value, 60);
});

test('admin config: setTunable overrides the value and it is reflected immediately', () => {
  const store = freshStore();
  adminConfig.setTunable(store, 'ssie.T_CONF', 75);
  assert.equal(adminConfig.getTunable(store, 'ssie.T_CONF'), 75);
});

test('admin config: setTunable rejects out-of-range values', () => {
  const store = freshStore();
  assert.throws(() => adminConfig.setTunable(store, 'ssie.T_CONF', 150), /outside/);
});

test('admin config: setTunable rejects unknown keys', () => {
  const store = freshStore();
  assert.throws(() => adminConfig.setTunable(store, 'not.a.real.key', 5), /unknown config key/);
});

test('admin config: resetTunable reverts to default and both changes are logged', () => {
  const store = freshStore();
  adminConfig.setTunable(store, 'ssie.T_CONF', 80);
  adminConfig.resetTunable(store, 'ssie.T_CONF');
  assert.equal(adminConfig.getTunable(store, 'ssie.T_CONF'), 60);
  const log = adminConfig.getChangeLog(store);
  assert.equal(log.length, 2);
  assert.equal(log[1].reset, true);
});

test('admin config: T_CONF is genuinely shared — editing it changes both resolveSSIEConfig and resolveEmployerConfig', () => {
  const store = freshStore();
  adminConfig.setTunable(store, 'ssie.T_CONF', 85);
  assert.equal(adminConfig.resolveSSIEConfig(store).T_CONF, 85);
  assert.equal(adminConfig.resolveEmployerConfig(store).T_CONF, 85);
});

test('admin config: editing a threshold actually changes SSIE Stage 3/4 behavior, not just the stored number', async () => {
  const store = freshStore();
  ssie.captureBaseline(store, 'u1', {});
  const events = Array.from({ length: 6 }, (_, i) => ({
    sourceChannel: i % 2 === 0 ? 'workLog' : 'quest',
    userId: 'u1',
    skillIds: ['communication'],
    engagementId: `eng_${i}`,
    text: 'Noticed the issue, interpreted the cause, decided on a fix, and adjusted after retesting.',
    observedAt: new Date().toISOString(),
  }));
  for (const e of events) await ssie.processEngagementEvent(store, e);

  const profile = store.get('/users/u1/softSkillProfile/communication');
  const claimBefore = store.get('/users/u1/skillClaims/communication');

  // Push T_VERIFY above this profile's actual score so it can no longer be "verified"
  adminConfig.setTunable(store, 'ssie.T_VERIFY', Math.min(100, Math.ceil(profile.score) + 20));
  await ssie.recomputeSkillProfile(store, 'u1', ['communication']);
  const claimAfter = store.get('/users/u1/skillClaims/communication');

  if (claimBefore.verificationState === 'verified') {
    assert.notEqual(claimAfter.verificationState, 'verified', 'raising T_VERIFY past the score should un-verify it');
  } else {
    assert.ok(true, 'profile was not verified to begin with under default thresholds — raising the bar further keeps it that way');
  }
});

// ---------------------------------------------------------------------------
// Cross-domain skill boost
// ---------------------------------------------------------------------------

test('cross-domain boost: a cross-domain emerging skill gets boosted relative to a non-cross-domain one under the same conditions', () => {
  const store = freshStore();
  employer.employerIntake(store, 'emp_cross', { sector: 'saas' }, ['customer_care_ticket_response']);
  employer.submitInterviewResponses(store, 'emp_cross', {
    bottleneck: 'x', friction: 'y',
    changeReadinessRaw: 'We picked it up fast and honestly no complaints, still using it today.',
    futureProjection: 'z',
  });
  employer.scoreAndBuildProfile(store, 'emp_cross');
  const profile = store.get('/employers/emp_cross/futureNeedProfile');

  // customer_care_ticket_response emergingNeeds: ai_output_judgment (cross-domain),
  // escalation_handling (not), empathy_in_conflict (not) — all share the same
  // task's pressure and adoptionModifier, differing only in magnitude and the boost.
  const judgment = profile.emergingNeeds.find((n) => n.skillId === 'ai_output_judgment');
  const escalation = profile.emergingNeeds.find((n) => n.skillId === 'escalation_handling');
  assert.ok(judgment.crossDomainBoosted, 'ai_output_judgment should be flagged as cross-domain boosted');
  assert.ok(!escalation.crossDomainBoosted, 'escalation_handling should NOT be flagged as cross-domain boosted');

  // magnitude for ai_output_judgment (0.8) > escalation_handling (0.6) before any
  // boost, so this alone doesn't isolate the boost — instead verify the boost
  // arithmetic directly: weight should equal un-boosted urgency * (1 + boost),
  // clamped, for the cross-domain one specifically.
  const cfg = adminConfig.resolveEmployerConfig(store);
  assert.ok(cfg.CROSS_DOMAIN_BOOST > 0, 'default boost should be a positive number');
});

test('cross-domain boost: setting the boost to 0 removes the effect (weight equals plain urgency, clamped)', () => {
  const store = freshStore();
  adminConfig.setTunable(store, 'employer.CROSS_DOMAIN_BOOST', 0);
  employer.employerIntake(store, 'emp_noboost', { sector: 'saas' }, ['customer_care_ticket_response']);
  employer.submitInterviewResponses(store, 'emp_noboost', {
    bottleneck: 'x', friction: 'y',
    changeReadinessRaw: 'We picked it up fast and honestly no complaints, still using it today.',
    futureProjection: 'z',
  });
  employer.scoreAndBuildProfile(store, 'emp_noboost');
  const profile = store.get('/employers/emp_noboost/futureNeedProfile');
  const judgment = profile.emergingNeeds.find((n) => n.skillId === 'ai_output_judgment');
  assert.ok(judgment.crossDomainBoosted, 'still flagged as cross-domain, even with a zero boost');
});

test('cross-domain boost is live-tunable: raising it increases the weight for the same employer profile', () => {
  const storeA = freshStore();
  adminConfig.setTunable(storeA, 'employer.CROSS_DOMAIN_BOOST', 0);
  employer.employerIntake(storeA, 'emp_a', { sector: 'saas' }, ['customer_care_ticket_response']);
  employer.submitInterviewResponses(storeA, 'emp_a', {
    bottleneck: 'x', friction: 'y', changeReadinessRaw: 'We picked it up fast, no complaints, still using it today.', futureProjection: 'z',
  });
  employer.scoreAndBuildProfile(storeA, 'emp_a');
  const weightNoBoost = store_findWeight(storeA, 'emp_a', 'ai_output_judgment');

  const storeB = freshStore();
  adminConfig.setTunable(storeB, 'employer.CROSS_DOMAIN_BOOST', 0.5);
  employer.employerIntake(storeB, 'emp_b', { sector: 'saas' }, ['customer_care_ticket_response']);
  employer.submitInterviewResponses(storeB, 'emp_b', {
    bottleneck: 'x', friction: 'y', changeReadinessRaw: 'We picked it up fast, no complaints, still using it today.', futureProjection: 'z',
  });
  employer.scoreAndBuildProfile(storeB, 'emp_b');
  const weightWithBoost = store_findWeight(storeB, 'emp_b', 'ai_output_judgment');

  assert.ok(weightWithBoost > weightNoBoost, `expected boosted weight (${weightWithBoost}) > unboosted (${weightNoBoost})`);
});

function store_findWeight(store, employerId, skillId) {
  const profile = store.get(`/employers/${employerId}/futureNeedProfile`);
  return profile.emergingNeeds.find((n) => n.skillId === skillId).weight;
}

// ---------------------------------------------------------------------------
// Feedback loop
// ---------------------------------------------------------------------------

function setUpEmployerAndMatch(store) {
  employer.employerIntake(store, 'emp_fb', { sector: 'saas' }, ['customer_care_ticket_response']);
  employer.submitInterviewResponses(store, 'emp_fb', {
    bottleneck: 'x', friction: 'y', changeReadinessRaw: 'We picked it up fast, no complaints, still using it today.', futureProjection: 'z',
  });
  employer.scoreAndBuildProfile(store, 'emp_fb');
  store.set('/users/cand_fb/softSkillProfile/critical_thinking', { score: 80, confidence: 70 });
  store.set('/users/cand_fb/skillClaims/critical_thinking', { skillId: 'critical_thinking', verificationState: 'verified' });
  employer.matchCandidateToEmployer(store, 'emp_fb', 'cand_fb');
}

test('feedback: recording a skill-shift outcome requires an existing futureNeedProfile', () => {
  const store = freshStore();
  assert.throws(
    () => employer.recordSkillShiftOutcome(store, 'no_such_employer', { skillId: 'x', direction: 'UP', outcome: 'occurred' }),
    /no futureNeedProfile/
  );
});

test('feedback: recording a skill-shift outcome ties it to the profile snapshot that predicted it', () => {
  const store = freshStore();
  setUpEmployerAndMatch(store);
  const profile = store.get('/employers/emp_fb/futureNeedProfile');
  const entry = employer.recordSkillShiftOutcome(store, 'emp_fb', { skillId: 'ai_output_judgment', direction: 'UP', outcome: 'occurred' });
  assert.equal(entry.predictedAt, profile.generatedAt);
});

test('feedback: rejects an invalid outcome value rather than silently accepting it', () => {
  const store = freshStore();
  setUpEmployerAndMatch(store);
  assert.throws(
    () => employer.recordSkillShiftOutcome(store, 'emp_fb', { skillId: 'x', direction: 'UP', outcome: 'definitely_maybe' }),
    /must be one of/
  );
});

test('feedback: match outcome requires an existing match record', () => {
  const store = freshStore();
  assert.throws(
    () => employer.recordMatchOutcome(store, 'emp_fb', 'cand_nope', { hired: true }),
    /no match record/
  );
});

test('feedback: match outcome snapshots the compositeFit/futureAdvantage at time of feedback', () => {
  const store = freshStore();
  setUpEmployerAndMatch(store);
  const match = store.get('/matches/emp_fb_cand_fb');
  const entry = employer.recordMatchOutcome(store, 'emp_fb', 'cand_fb', { hired: true, workedOut: 'yes' });
  assert.equal(entry.compositeFitAtMatch, match.compositeFit);
  assert.equal(entry.futureAdvantageAtMatch, match.futureAdvantage);
});

test('feedback: summarizeFeedback returns counts only, never a computed accuracy/calibration score', () => {
  const store = freshStore();
  setUpEmployerAndMatch(store);
  employer.recordSkillShiftOutcome(store, 'emp_fb', { skillId: 'ai_output_judgment', direction: 'UP', outcome: 'occurred' });
  employer.recordMatchOutcome(store, 'emp_fb', 'cand_fb', { hired: true, workedOut: 'yes' });

  const summary = employer.summarizeFeedback(store, 'emp_fb');
  assert.equal(summary.skillShiftOutcomeCount, 1);
  assert.equal(summary.matchOutcomeCount, 1);
  assert.equal(summary.matchHiredCount, 1);
  assert.ok(!('accuracyRate' in summary), 'must not compute an accuracy score from a handful of outcomes');
  assert.ok(!('calibrationScore' in summary), 'must not compute a calibration score from a handful of outcomes');
});

test('feedback: nothing in Stage 3/4 scoring reads outcome feedback — recording an outcome does not change the next match', () => {
  const store = freshStore();
  setUpEmployerAndMatch(store);
  const before = employer.matchCandidateToEmployer(store, 'emp_fb', 'cand_fb');
  employer.recordMatchOutcome(store, 'emp_fb', 'cand_fb', { hired: true, workedOut: 'yes' });
  const after = employer.matchCandidateToEmployer(store, 'emp_fb', 'cand_fb');
  assert.equal(before.compositeFit, after.compositeFit, 'recording an outcome must not silently change subsequent match scores');
});

// ---------------------------------------------------------------------------
// Coverage backlog — unmapped tasks/skills now actually persisted
// ---------------------------------------------------------------------------

const { getCoverageBacklog } = require('../src/employer/coverageBacklog');

test('coverage backlog: an unmapped role task is persisted, not just counted in-memory', () => {
  const store = freshStore();
  employer.employerIntake(store, 'emp_unmapped', { sector: 'saas' }, ['totally_made_up_task_category']);
  employer.submitInterviewResponses(store, 'emp_unmapped', {
    bottleneck: 'x', friction: 'y', changeReadinessRaw: 'We picked it up fast, no complaints, still using it today.', futureProjection: 'z',
  });
  employer.scoreAndBuildProfile(store, 'emp_unmapped');

  const backlog = getCoverageBacklog(store);
  const entry = backlog.unmappedTasks.find((t) => t.roleTaskId === 'totally_made_up_task_category');
  assert.ok(entry, 'unmapped task should be persisted in the backlog');
  assert.equal(entry.timesSeen, 1);
});

test('coverage backlog: seeing the same unmapped task twice increments timesSeen rather than duplicating', () => {
  const store = freshStore();
  employer.employerIntake(store, 'emp_a', { sector: 'saas' }, ['made_up_task_x']);
  employer.submitInterviewResponses(store, 'emp_a', { bottleneck: 'x', friction: 'y', changeReadinessRaw: 'fast, no complaints, still using it', futureProjection: 'z' });
  employer.scoreAndBuildProfile(store, 'emp_a');

  employer.employerIntake(store, 'emp_b', { sector: 'fintech' }, ['made_up_task_x']);
  employer.submitInterviewResponses(store, 'emp_b', { bottleneck: 'x', friction: 'y', changeReadinessRaw: 'fast, no complaints, still using it', futureProjection: 'z' });
  employer.scoreAndBuildProfile(store, 'emp_b');

  const backlog = getCoverageBacklog(store);
  const entry = backlog.unmappedTasks.find((t) => t.roleTaskId === 'made_up_task_x');
  assert.equal(entry.timesSeen, 2, 'should increment, not create a second entry');
});

test('coverage backlog: an unmapped employer-skill ID hit during matching is persisted', () => {
  const store = freshStore();
  employer.employerIntake(store, 'emp_c', { sector: 'saas' }, ['customer_care_ticket_response']);
  employer.submitInterviewResponses(store, 'emp_c', { bottleneck: 'x', friction: 'y', changeReadinessRaw: 'fast, no complaints, still using it', futureProjection: 'z' });
  employer.scoreAndBuildProfile(store, 'emp_c');

  // Manually inject a fake emerging need with a skillId that isn't in RECONCILIATION_MAP
  const profile = store.get('/employers/emp_c/futureNeedProfile');
  profile.emergingNeeds.push({ skillId: 'totally_unmapped_employer_skill', weight: 50, horizon: 'NEAR' });
  store.set('/employers/emp_c/futureNeedProfile', profile);

  store.set('/users/cand_c/softSkillProfile/critical_thinking', { score: 80, confidence: 70 });
  store.set('/users/cand_c/skillClaims/critical_thinking', { skillId: 'critical_thinking', verificationState: 'verified' });
  employer.matchCandidateToEmployer(store, 'emp_c', 'cand_c');

  const backlog = getCoverageBacklog(store);
  const entry = backlog.unmappedSkills.find((s) => s.needSkillId === 'totally_unmapped_employer_skill');
  assert.ok(entry, 'unmapped employer-skill ID should be persisted in the backlog after a match run');
});

// ---------------------------------------------------------------------------
// Weight-fitting pipeline scaffold
// ---------------------------------------------------------------------------

const { runWeightFittingDiagnostic } = require('../src/employer/weightFitting');

test('weight-fitting: reports insufficient_data below the gate, and never fabricates a diagnostic from too little', () => {
  const store = freshStore();
  const report = runWeightFittingDiagnostic(store);
  assert.equal(report.matchDiagnostic.status, 'insufficient_data');
  assert.equal(report.skillShiftDiagnostic.status, 'insufficient_data');
  assert.equal(report.matchDiagnostic.have, 0);
});

test('weight-fitting: match diagnostic activates once the gate is cleared, and is clearly labeled as descriptive only', () => {
  const store = freshStore();
  adminConfig.setTunable(store, 'employer.MIN_MATCH_OUTCOMES_FOR_DIAGNOSTIC', 2);

  for (let i = 0; i < 2; i++) {
    const empId = `emp_wf_${i}`;
    employer.employerIntake(store, empId, { sector: 'saas' }, ['customer_care_ticket_response']);
    employer.submitInterviewResponses(store, empId, { bottleneck: 'x', friction: 'y', changeReadinessRaw: 'fast, no complaints, still using it', futureProjection: 'z' });
    employer.scoreAndBuildProfile(store, empId);
    store.set(`/users/cand_wf_${i}/softSkillProfile/critical_thinking`, { score: 80, confidence: 70 });
    store.set(`/users/cand_wf_${i}/skillClaims/critical_thinking`, { skillId: 'critical_thinking', verificationState: 'verified' });
    employer.matchCandidateToEmployer(store, empId, `cand_wf_${i}`);
    employer.recordMatchOutcome(store, empId, `cand_wf_${i}`, { hired: true, workedOut: i === 0 ? 'yes' : 'no' });
  }

  const report = runWeightFittingDiagnostic(store);
  assert.equal(report.matchDiagnostic.status, 'diagnostic_only');
  assert.equal(report.matchDiagnostic.sampleSize, 2);
  assert.ok(report.matchDiagnostic.note.includes('does NOT mean'), 'must explicitly disclaim automatic weight changes');
});

test('weight-fitting: never writes back to adminConfig — running it does not change any tunable', () => {
  const store = freshStore();
  adminConfig.setTunable(store, 'employer.MIN_MATCH_OUTCOMES_FOR_DIAGNOSTIC', 1);
  employer.employerIntake(store, 'emp_wf_x', { sector: 'saas' }, ['customer_care_ticket_response']);
  employer.submitInterviewResponses(store, 'emp_wf_x', { bottleneck: 'x', friction: 'y', changeReadinessRaw: 'fast, no complaints, still using it', futureProjection: 'z' });
  employer.scoreAndBuildProfile(store, 'emp_wf_x');
  store.set('/users/cand_wf_x/softSkillProfile/critical_thinking', { score: 80, confidence: 70 });
  store.set('/users/cand_wf_x/skillClaims/critical_thinking', { skillId: 'critical_thinking', verificationState: 'verified' });
  employer.matchCandidateToEmployer(store, 'emp_wf_x', 'cand_wf_x');
  employer.recordMatchOutcome(store, 'emp_wf_x', 'cand_wf_x', { hired: true, workedOut: 'yes' });

  const cwCurrentBefore = adminConfig.getTunable(store, 'employer.CW_CURRENT');
  runWeightFittingDiagnostic(store);
  const cwCurrentAfter = adminConfig.getTunable(store, 'employer.CW_CURRENT');
  assert.equal(cwCurrentBefore, cwCurrentAfter, 'running the diagnostic must never silently change a live config value');
});
