const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('os');
const path = require('path');

const { JSONStore } = require('../src/db/store');
const { codeChangeReadiness, scoreChangeReadiness, matchTimeBucket } = require('../src/employer/stage2_scoring');
const { getCandidateScoreForEmployerSkill } = require('../src/employer/reconciliation');
const { scoreSkillSet, matchCandidateToEmployer } = require('../src/employer/stage4_matching');
const employer = require('../src/employer/index');
const adminConfig = require('../src/config/adminConfig');

function freshStore() {
  const p = path.join(os.tmpdir(), `emp_test_${Date.now()}_${Math.random().toString(36).slice(2)}.json`);
  return new JSONStore(p);
}

// ---------------------------------------------------------------------------
// Stage 2 — text coding
// ---------------------------------------------------------------------------

test('matchTimeBucket checks STALLED before FAST to avoid false positives on negation', () => {
  // "wasn't immediate, took forever" contains no FAST phrase literally, but
  // this is exactly the kind of case the spec calls out — verify STALLED/SLOW
  // patterns are checked and a genuine SLOW phrase wins over no match.
  assert.equal(matchTimeBucket('Honestly it took forever for the team to get on board.'), 'SLOW');
  assert.equal(matchTimeBucket('The team still hasn\u2019t really adopted it.'), 'STALLED');
});

test('ambiguous or absent text-coding signals return null, not a forced guess', () => {
  const signals = codeChangeReadiness('The weather was nice today.');
  assert.equal(signals.speedMentioned, null);
  assert.equal(signals.sentimentMarkers, null);
  assert.equal(signals.outcomeMarker, null);
});

test('a category with both positive and negative matches returns null rather than picking one', () => {
  const text = 'Honestly the team loved it at first but it was pretty painful by the end.';
  const signals = codeChangeReadiness(text);
  assert.equal(signals.sentimentMarkers, null);
});

test('changeReadinessScore confidence is HIGH with 2+ matched signals, LOW with none', () => {
  const allNull = scoreChangeReadiness({ speedMentioned: null, sentimentMarkers: null, outcomeMarker: null });
  assert.equal(allNull.confidence, 'LOW');
  assert.equal(allNull.changeReadinessScore, 50); // base, untouched

  const twoMatched = scoreChangeReadiness({ speedMentioned: 'FAST', sentimentMarkers: 'POSITIVE', outcomeMarker: null });
  assert.equal(twoMatched.confidence, 'HIGH');
  assert.equal(twoMatched.changeReadinessScore, 80); // 50 + 20 + 10
});

// ---------------------------------------------------------------------------
// Reconciliation lookup — the actual bug fix
// ---------------------------------------------------------------------------

test('reconciliation lookup resolves an employer skillId to a weighted blend of SSIE skills, not a direct key match', () => {
  const candidateSkills = {
    critical_thinking: { score: 80, confidence: 70 },
    attention_to_detail: { score: 60, confidence: 90 },
  };
  // ai_output_judgment -> critical_thinking (0.7) + attention_to_detail (0.3)
  const resolved = getCandidateScoreForEmployerSkill('ai_output_judgment', candidateSkills);
  assert.equal(resolved.score, 80 * 0.7 + 60 * 0.3);
  assert.equal(resolved.confidence, 70); // conservative: lowest contributing confidence
});

test('a direct-key lookup on candidateSkills would have failed silently — confirming the bug the reconciliation doc describes', () => {
  const candidateSkills = { critical_thinking: { score: 80, confidence: 70 } };
  // This is what the ORIGINAL buggy Stage 4 spec did — direct key lookup:
  const buggyDirectLookup = candidateSkills['ai_output_judgment'];
  assert.equal(buggyDirectLookup, undefined, 'direct lookup returns undefined because the vocabularies differ');
  // The reconciled lookup succeeds where the direct one silently would not:
  const fixed = getCandidateScoreForEmployerSkill('ai_output_judgment', candidateSkills);
  assert.ok(fixed.score > 0);
});

test('an unmapped employer skillId returns a flagged zero, not a crash', () => {
  const resolved = getCandidateScoreForEmployerSkill('totally_made_up_skill', { critical_thinking: { score: 90, confidence: 90 } });
  assert.equal(resolved.score, 0);
  assert.equal(resolved.unmapped, true);
});

test('scoreSkillSet returns null for an empty skill list, not zero', () => {
  const store = freshStore();
  assert.equal(scoreSkillSet(store, [], {}, 'WEIGHTED', adminConfig.resolveEmployerConfig(store)), null);
});

// ---------------------------------------------------------------------------
// Stage 4 math in isolation — proves the distortion documented in
// FLAGS_EMPLOYER.md #4 is a Stage-3-stub artifact, not a Stage 4 bug
// ---------------------------------------------------------------------------

test('Stage 4 math is correct in isolation: a candidate strong on emerging-but-not-current skills gets positive futureAdvantage', () => {
  const store = freshStore();
  const employerId = 'emp_test';
  const candidateId = 'cand_test';

  // Deliberately choose currentNeeds and emergingNeeds that reconcile to
  // DIFFERENT SSIE skills, unlike the emp_001 demo case in FLAGS_EMPLOYER.md
  // #4 where they collapsed onto the same skill (adaptability).
  store.set(`/employers/${employerId}/futureNeedProfile`, {
    currentNeeds: ['manual_reconciliation'], // -> attention_to_detail only
    emergingNeeds: [{ skillId: 'system_design_thinking', weight: 80, horizon: 'NEAR' }], // -> critical_thinking + learning_agility
    decliningNeeds: [],
    overallConfidence: 'HIGH',
  });

  // Candidate is weak on attention_to_detail (current) but strong on
  // critical_thinking and learning_agility (emerging) — the exact
  // "looks ordinary today, well-positioned for tomorrow" profile.
  store.set(`/users/${candidateId}/softSkillProfile/attention_to_detail`, { score: 40, confidence: 80 });
  store.set(`/users/${candidateId}/softSkillProfile/critical_thinking`, { score: 90, confidence: 80 });
  store.set(`/users/${candidateId}/softSkillProfile/learning_agility`, { score: 85, confidence: 80 });
  // 3 verified skills so match confidence isn't gated LOW by thin data
  for (const s of ['attention_to_detail', 'critical_thinking', 'learning_agility']) {
    store.set(`/users/${candidateId}/skillClaims/${s}`, { skillId: s, verificationState: 'verified' });
  }

  const match = matchCandidateToEmployer(store, employerId, candidateId);
  assert.ok(match.currentFit < match.emergingFit, `expected currentFit (${match.currentFit}) < emergingFit (${match.emergingFit})`);
  assert.ok(match.futureAdvantage > 0, `expected positive futureAdvantage, got ${match.futureAdvantage}`);
});

test('a candidate with thin verified-skill data gets LOW match confidence even against a HIGH-confidence employer profile', () => {
  const store = freshStore();
  store.set('/employers/emp_thin/futureNeedProfile', {
    currentNeeds: [],
    emergingNeeds: [{ skillId: 'data_accuracy', weight: 50, horizon: 'NEAR' }],
    decliningNeeds: [],
    overallConfidence: 'HIGH',
  });
  store.set('/users/cand_thin/softSkillProfile/attention_to_detail', { score: 70, confidence: 70 });
  // no verified skillClaims at all
  const match = matchCandidateToEmployer(store, 'emp_thin', 'cand_thin');
  assert.equal(match.confidence, 'LOW');
});

// ---------------------------------------------------------------------------
// Full Stage 1-3 orchestration smoke test
// ---------------------------------------------------------------------------

test('Stages 1-3 run end to end and produce a schema-complete futureNeedProfile', () => {
  const store = freshStore();
  const employerId = 'emp_smoke';
  employer.employerIntake(
    store,
    employerId,
    { sector: 'saas', postingLanguageDrift: { hasNewToolMentions: true, addedTerms: ['AI'], droppedTerms: [] } },
    ['basic_data_entry']
  );
  employer.submitInterviewResponses(store, employerId, {
    bottleneck: 'Data entry would pile up fast.',
    friction: 'Entering data into the system all day.',
    changeReadinessRaw: 'We picked it up fast and honestly no complaints, still using it today.',
    futureProjection: 'Probably less manual entry, more exception review.',
  });
  const { scoring, profile } = employer.scoreAndBuildProfile(store, employerId);

  assert.ok(scoring.changeReadinessScore > 50); // FAST + POSITIVE + ADOPTED should push it up
  assert.equal(scoring.changeReadinessConfidence, 'HIGH');
  assert.ok(Array.isArray(profile.emergingNeeds) && profile.emergingNeeds.length > 0);
  assert.ok(['LOW', 'MEDIUM', 'HIGH'].includes(profile.overallConfidence));
});
