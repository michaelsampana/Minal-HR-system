const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('os');
const path = require('path');
const fs = require('fs');

const { JSONStore } = require('../src/db/store');
const ssie = require('../src/ssie/index');
const { markUserAsExistingBackfill } = require('../src/ssie/stage5_routing');

function freshStore() {
  const p = path.join(os.tmpdir(), `ssie_test_${Date.now()}_${Math.random().toString(36).slice(2)}.json`);
  return new JSONStore(p);
}

function baseEvent(overrides) {
  return {
    sourceChannel: 'workLog',
    userId: 'u1',
    skillIds: ['communication'],
    engagementId: 'eng_1',
    text: 'Checked the logs first, realized it was a config issue, and fixed it before the deadline.',
    observedAt: new Date().toISOString(),
    ...overrides,
  };
}

test('idempotency guard: re-firing the exact same sub-event is skipped', async () => {
  const store = freshStore();
  const event = baseEvent({ eventId: 'fixed_key_1' });
  const first = await ssie.processEngagementEvent(store, event);
  assert.equal(first.skipped, undefined);
  const second = await ssie.processEngagementEvent(store, event);
  assert.equal(second.skipped, true);
});

test('idempotency guard does NOT conflate a reject and its resubmit on the same engagement', async () => {
  const store = freshStore();
  const rejected = await ssie.processEngagementEvent(store, {
    sourceChannel: 'deliverableCycle',
    userId: 'u1',
    skillIds: ['communication'],
    engagementId: 'eng_2',
    deliverableId: 'del_1',
    verdict: 'rejected',
    observedAtMs: Date.now(),
    observedAt: new Date().toISOString(),
  });
  const resubmitted = await ssie.processEngagementEvent(store, {
    sourceChannel: 'deliverableCycle',
    userId: 'u1',
    skillIds: ['communication'],
    engagementId: 'eng_2',
    deliverableId: 'del_1',
    verdict: 'resubmitted',
    resubmissionNotes: 'Fixed the issue and retested.',
    observedAtMs: Date.now() + 1000,
    observedAt: new Date().toISOString(),
  });
  assert.equal(rejected.skipped, undefined, 'reject event should process');
  assert.equal(resubmitted.skipped, undefined, 'resubmit event on same engagement should ALSO process');
});

test('dispute channel is consent-gated and defaults to opted-out', async () => {
  const store = freshStore();
  const result = await ssie.processEngagementEvent(store, baseEvent({ sourceChannel: 'dispute', engagementId: 'eng_3' }));
  assert.equal(result.skipped, true);
  assert.match(result.reason, /consent/);
});

test('dispute channel proceeds once consent is granted', async () => {
  const store = freshStore();
  store.set('/users/u1/consent', { dispute: true });
  const result = await ssie.processEngagementEvent(store, baseEvent({ sourceChannel: 'dispute', engagementId: 'eng_4' }));
  assert.equal(result.skipped, undefined);
  assert.equal(result.obs.modifiers.constraintLevel, 3, 'dispute is automatically constraintLevel 3');
});

test('a skill with too little evidence stays unreportable, not zero-scored', async () => {
  const store = freshStore();
  await ssie.processEngagementEvent(store, baseEvent({ engagementId: 'eng_5' }));
  const profile = store.get('/users/u1/softSkillProfile/communication');
  assert.equal(profile, null, 'should not have written a softSkillProfile at all below MIN_OBSERVATIONS');
  const claim = store.get('/users/u1/skillClaims/communication');
  assert.match(claim._unreportableReason, /need >=5 observations/);
});

test('cold-start unfairness: unreportable skill defaults to unverified, not a penalized state', async () => {
  const store = freshStore();
  await ssie.processEngagementEvent(store, baseEvent({ engagementId: 'eng_6' }));
  const claim = store.get('/users/u1/skillClaims/communication');
  assert.equal(claim.verificationState, 'unverified');
});

test('fresh onboard is NOT blend-ramped — gets full computed credibility immediately', async () => {
  const store = freshStore();
  const events = Array.from({ length: 6 }, (_, i) =>
    baseEvent({
      engagementId: `eng_fresh_${i}`,
      sourceChannel: i % 2 === 0 ? 'workLog' : 'quest',
      text: `Noticed the issue, interpreted the cause, decided on a fix, and adjusted after retesting. (${i})`,
    })
  );
  for (const e of events) await ssie.processEngagementEvent(store, e);
  const claim = store.get('/users/u1/skillClaims/communication');
  assert.ok(claim.credibilityScore > 1, `expected a real credibility value, got ${claim.credibilityScore}`);
});

test('backfilled existing user IS blend-ramped near day 0 (should be close to legacy baseline)', async () => {
  const store = freshStore();
  markUserAsExistingBackfill(store, 'u1', 10); // legacy value 10
  const events = Array.from({ length: 6 }, (_, i) =>
    baseEvent({
      engagementId: `eng_backfill_${i}`,
      sourceChannel: i % 2 === 0 ? 'workLog' : 'quest',
      text: `Noticed the issue, interpreted the cause, decided on a fix, and adjusted after retesting. (${i})`,
    })
  );
  for (const e of events) await ssie.processEngagementEvent(store, e);
  const claim = store.get('/users/u1/skillClaims/communication');
  // at day ~0, beta ~0, so credibility should be close to the legacy baseline (10), not the raw computed value
  assert.ok(Math.abs(claim.credibilityScore - 10) < 3, `expected near legacy baseline 10, got ${claim.credibilityScore}`);
});

test('negative evidence (blame-shifting language) flips observation polarity to -1', async () => {
  const store = freshStore();
  const result = await ssie.processEngagementEvent(
    store,
    baseEvent({
      sourceChannel: 'deliverableCycle',
      engagementId: 'eng_7',
      deliverableId: 'del_neg',
      verdict: 'resubmitted',
      resubmissionNotes: "This wouldn't have broken if the client had given clearer requirements. Not my fault the spec was garbage.",
      observedAtMs: Date.now(),
    })
  );
  assert.equal(result.obs.polarity, -1);
  assert.ok(result.obs.tags.includes('negativeEvidence'));
});

test('verified badge requires BOTH score >= T_VERIFY and confidence >= T_CONF', async () => {
  const store = freshStore();
  // Feed strong, consistent, high-primitive evidence across many channels to
  // push score and confidence both high.
  const strongText = 'Noticed the anomaly immediately, interpreted the root cause correctly, decided on the right fix under time pressure, executed cleanly, and adjusted after verifying under load three times.';
  const channels = ['workLog', 'quest', 'peerReview', 'endorsement', 'workLog', 'quest', 'peerReview'];
  for (let i = 0; i < channels.length; i++) {
    await ssie.processEngagementEvent(store, {
      sourceChannel: channels[i],
      userId: 'u1',
      skillIds: ['critical_thinking'],
      engagementId: `eng_strong_${i}`,
      text: strongText,
      endorserTrustWeight: 0.9,
      reviewerRatings: { sense: 0.9, act: 0.9 },
      observedAt: new Date().toISOString(),
    });
  }
  const profile = store.get('/users/u1/softSkillProfile/critical_thinking');
  const claim = store.get('/users/u1/skillClaims/critical_thinking');
  assert.ok(profile, 'skill should be reportable with 7 observations across multiple channels');
  if (profile.score >= 70 && profile.confidence >= 60) {
    assert.equal(claim.verificationState, 'verified');
  } else {
    // Document actual behavior either way so a threshold miss doesn't silently pass
    assert.notEqual(claim.verificationState, 'verified');
  }
});

test('stale _unreportableReason clears once a skill later becomes reportable', async () => {
  const store = freshStore();
  await ssie.processEngagementEvent(store, baseEvent({ engagementId: 'eng_stale_1' }));
  let claim = store.get('/users/u1/skillClaims/communication');
  assert.ok(claim._unreportableReason, 'should be flagged unreportable after only 1 observation');

  const more = [
    baseEvent({ engagementId: 'eng_stale_2', sourceChannel: 'quest' }),
    baseEvent({ engagementId: 'eng_stale_3', sourceChannel: 'peerReview', reviewerRatings: { sense: 0.6, act: 0.6 } }),
    baseEvent({ engagementId: 'eng_stale_4', sourceChannel: 'workLog' }),
    baseEvent({ engagementId: 'eng_stale_5', sourceChannel: 'quest' }),
  ];
  for (const e of more) await ssie.processEngagementEvent(store, e);

  claim = store.get('/users/u1/skillClaims/communication');
  const profile = store.get('/users/u1/softSkillProfile/communication');
  assert.ok(profile, 'should now be reportable');
  assert.ok(!claim._unreportableReason, `stale reason should be cleared, got: ${claim._unreportableReason}`);
});
