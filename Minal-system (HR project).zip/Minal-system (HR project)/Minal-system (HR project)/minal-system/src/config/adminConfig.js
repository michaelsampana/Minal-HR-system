// Admin config registry — the "admin config collection" the Integration
// Contract §5 describes: "Trust parameter reads come from the admin config
// collection so UC-A03 (Configure Trust Parameters) governs SSIE weights
// with zero console changes." Extended here to cover the employer-side
// tunables too, since skill_taxonomy_reconciliation.md §5 recommends the
// same "one shared, live value" treatment for T_CONF specifically.
//
// Design: every tunable has a REGISTRY entry (default value + metadata).
// getTunable reads an override from the store if one was ever set, and
// falls back to the registry default otherwise. Nothing here changes
// default behavior unless a person actually edits a value — every existing
// test keeps passing against defaults untouched.

const SSIE_CONSTANTS = require('./constants');
const crypto = require('crypto');

// ---------------------------------------------------------------------------
// Registry — key, default value, and product-facing metadata. Only the
// values explicitly called out as TUNABLE / a product decision (in the specs
// and in FLAGS.md / FLAGS_EMPLOYER.md) are exposed here. Structural constants
// (e.g. TOTAL_CHANNELS, MAX_OBSERVATIONS_PER_USER) are left as plain JS
// constants — they describe the shape of the system, not a product judgment
// call, so surfacing them as "tunable" would invite edits that break
// invariants rather than calibrate a weight.
// ---------------------------------------------------------------------------

const REGISTRY = [
  // --- SSIE side ---
  { key: 'ssie.T_VERIFY', group: 'SSIE — verification thresholds', label: 'Verified badge: score threshold', default: SSIE_CONSTANTS.T_VERIFY, min: 0, max: 100 },
  { key: 'ssie.T_CONF', group: 'SSIE — verification thresholds', label: 'Confidence threshold (shared with employer side)', default: SSIE_CONSTANTS.T_CONF, min: 0, max: 100 },
  { key: 'ssie.T_GAP', group: 'SSIE — verification thresholds', label: 'gapFlagged: score ceiling', default: SSIE_CONSTANTS.T_GAP, min: 0, max: 100 },
  { key: 'ssie.HIGH_CLAIM', group: 'SSIE — verification thresholds', label: 'gapFlagged: self-claim floor', default: SSIE_CONSTANTS.HIGH_CLAIM, min: 0, max: 100 },
  { key: 'ssie.MIN_OBSERVATIONS', group: 'SSIE — evidence gating', label: 'Minimum observations to report a score', default: SSIE_CONSTANTS.MIN_OBSERVATIONS, min: 1, max: 50 },
  { key: 'ssie.MIN_CHANNEL_DIVERSITY', group: 'SSIE — evidence gating', label: 'Minimum distinct channels to report a score', default: SSIE_CONSTANTS.MIN_CHANNEL_DIVERSITY, min: 1, max: 7 },
  { key: 'ssie.CREDIBILITY_W_Q', group: 'SSIE — soft-skill credibility weights', label: 'Quest score weight (w_q)', default: SSIE_CONSTANTS.CREDIBILITY_WEIGHTS_SOFT.w_q, min: 0, max: 1 },
  { key: 'ssie.CREDIBILITY_W_P', group: 'SSIE — soft-skill credibility weights', label: 'Portfolio score weight (w_p)', default: SSIE_CONSTANTS.CREDIBILITY_WEIGHTS_SOFT.w_p, min: 0, max: 1 },
  { key: 'ssie.CREDIBILITY_W_S', group: 'SSIE — soft-skill credibility weights', label: 'SSIE score weight (w_s)', default: SSIE_CONSTANTS.CREDIBILITY_WEIGHTS_SOFT.w_s, min: 0, max: 1 },
  { key: 'ssie.RELIABILITY_R1', group: 'SSIE — reliability/accountability deltas', label: 'Consistency delta (r_1)', default: SSIE_CONSTANTS.RELIABILITY_DELTAS.r_1, min: 0, max: 1 },
  { key: 'ssie.RELIABILITY_R2', group: 'SSIE — reliability/accountability deltas', label: 'Recovery-time delta (r_2)', default: SSIE_CONSTANTS.RELIABILITY_DELTAS.r_2, min: 0, max: 1 },
  { key: 'ssie.ACCOUNTABILITY_A1', group: 'SSIE — reliability/accountability deltas', label: 'Initiative delta (a_1)', default: SSIE_CONSTANTS.ACCOUNTABILITY_DELTAS.a_1, min: 0, max: 1 },
  { key: 'ssie.ACCOUNTABILITY_A2', group: 'SSIE — reliability/accountability deltas', label: 'Negative-evidence delta (a_2)', default: SSIE_CONSTANTS.ACCOUNTABILITY_DELTAS.a_2, min: 0, max: 1 },
  { key: 'ssie.CALIBRATION_BOUND', group: 'SSIE — reputation calibration', label: 'Calibration modifier bound (±)', default: SSIE_CONSTANTS.CALIBRATION_BOUND, min: 0, max: 0.5 },
  { key: 'ssie.BLEND_RAMP_DAYS', group: 'SSIE — rollout', label: 'Blend ramp duration (days, existing-user backfill only)', default: SSIE_CONSTANTS.BLEND_RAMP_DAYS, min: 1, max: 365 },

  // --- Employer side ---
  { key: 'employer.CW_CURRENT', group: 'Employer — Stage 4 composite weights', label: 'Composite weight: currentFit', default: 0.4, min: 0, max: 1 },
  { key: 'employer.CW_EMERGING', group: 'Employer — Stage 4 composite weights', label: 'Composite weight: emergingFit', default: 0.6, min: 0, max: 1 },
  { key: 'employer.CONFIDENCE_DISCOUNT', group: 'Employer — Stage 4 matching', label: 'Score discount below T_CONF', default: 0.6, min: 0, max: 1 },
  { key: 'employer.HORIZON_NEAR', group: 'Employer — Stage 4 horizon multipliers', label: 'Horizon multiplier: NEAR', default: 1.0, min: 0, max: 1 },
  { key: 'employer.HORIZON_MID', group: 'Employer — Stage 4 horizon multipliers', label: 'Horizon multiplier: MID', default: 0.7, min: 0, max: 1 },
  { key: 'employer.HORIZON_FAR', group: 'Employer — Stage 4 horizon multipliers', label: 'Horizon multiplier: FAR', default: 0.4, min: 0, max: 1 },
  { key: 'employer.MIN_VERIFIED_SKILLS', group: 'Employer — Stage 4 matching', label: 'Min verified skills for HIGH match confidence', default: 3, min: 0, max: 20 },
  { key: 'employer.CROSS_DOMAIN_BOOST', group: 'Employer — Stage 3 cross-domain skills', label: 'Weight boost for judgment/oversight-type skills (§3.1)', default: 0.15, min: 0, max: 1 },
  { key: 'employer.MIN_MATCH_OUTCOMES_FOR_DIAGNOSTIC', group: 'Employer — weight-fitting gate', label: 'Min match outcomes before a diagnostic report runs', default: 10, min: 1, max: 1000 },
  { key: 'employer.MIN_SKILLSHIFT_OUTCOMES_FOR_DIAGNOSTIC', group: 'Employer — weight-fitting gate', label: 'Min skill-shift outcomes before a diagnostic report runs', default: 10, min: 1, max: 1000 },
];

const REGISTRY_BY_KEY = Object.fromEntries(REGISTRY.map((r) => [r.key, r]));

function getTunable(store, key) {
  const entry = REGISTRY_BY_KEY[key];
  if (!entry) throw new Error(`getTunable: unknown config key "${key}"`);
  const override = store.get(`/adminConfig/${key}`);
  return override && typeof override === 'object' && 'value' in override ? override.value : entry.default;
}

function setTunable(store, key, value) {
  const entry = REGISTRY_BY_KEY[key];
  if (!entry) throw new Error(`setTunable: unknown config key "${key}"`);
  if (typeof value !== 'number' || Number.isNaN(value)) throw new Error(`setTunable: value for "${key}" must be a number`);
  if (value < entry.min || value > entry.max) {
    throw new Error(`setTunable: value ${value} for "${key}" is outside [${entry.min}, ${entry.max}]`);
  }

  const previous = getTunable(store, key);
  store.set(`/adminConfig/${key}`, { value, updatedAt: new Date().toISOString() });

  // "All parameter changes logged and reversible" — Integration Contract §6.
  store.appendToArrayField('/adminConfig/_changeLog', 'entries', {
    changeId: crypto.randomUUID(),
    key,
    previousValue: previous,
    newValue: value,
    changedAt: new Date().toISOString(),
  }, 100);

  return { key, value, previousValue: previous };
}

function resetTunable(store, key) {
  if (!REGISTRY_BY_KEY[key]) throw new Error(`resetTunable: unknown config key "${key}"`);
  const previous = getTunable(store, key);
  store.delete(`/adminConfig/${key}`);
  store.appendToArrayField('/adminConfig/_changeLog', 'entries', {
    changeId: crypto.randomUUID(),
    key,
    previousValue: previous,
    newValue: REGISTRY_BY_KEY[key].default,
    changedAt: new Date().toISOString(),
    reset: true,
  }, 100);
  return { key, value: REGISTRY_BY_KEY[key].default };
}

function listTunables(store) {
  return REGISTRY.map((entry) => {
    const override = store.get(`/adminConfig/${entry.key}`);
    const isOverridden = !!(override && typeof override === 'object' && 'value' in override);
    return {
      ...entry,
      value: isOverridden ? override.value : entry.default,
      isOverridden,
      updatedAt: isOverridden ? override.updatedAt : null,
    };
  });
}

function getChangeLog(store) {
  return (store.get('/adminConfig/_changeLog') || {}).entries || [];
}

/** Convenience bundle for SSIE call sites: resolve every SSIE tunable once per call. */
function resolveSSIEConfig(store) {
  return {
    T_VERIFY: getTunable(store, 'ssie.T_VERIFY'),
    T_CONF: getTunable(store, 'ssie.T_CONF'),
    T_GAP: getTunable(store, 'ssie.T_GAP'),
    HIGH_CLAIM: getTunable(store, 'ssie.HIGH_CLAIM'),
    MIN_OBSERVATIONS: getTunable(store, 'ssie.MIN_OBSERVATIONS'),
    MIN_CHANNEL_DIVERSITY: getTunable(store, 'ssie.MIN_CHANNEL_DIVERSITY'),
    CREDIBILITY_WEIGHTS_SOFT: {
      w_q: getTunable(store, 'ssie.CREDIBILITY_W_Q'),
      w_p: getTunable(store, 'ssie.CREDIBILITY_W_P'),
      w_s: getTunable(store, 'ssie.CREDIBILITY_W_S'),
    },
    RELIABILITY_DELTAS: { r_1: getTunable(store, 'ssie.RELIABILITY_R1'), r_2: getTunable(store, 'ssie.RELIABILITY_R2') },
    ACCOUNTABILITY_DELTAS: { a_1: getTunable(store, 'ssie.ACCOUNTABILITY_A1'), a_2: getTunable(store, 'ssie.ACCOUNTABILITY_A2') },
    CALIBRATION_BOUND: getTunable(store, 'ssie.CALIBRATION_BOUND'),
    BLEND_RAMP_DAYS: getTunable(store, 'ssie.BLEND_RAMP_DAYS'),
  };
}

/** Convenience bundle for employer call sites: resolve every employer tunable once per call. */
function resolveEmployerConfig(store) {
  return {
    CW_CURRENT: getTunable(store, 'employer.CW_CURRENT'),
    CW_EMERGING: getTunable(store, 'employer.CW_EMERGING'),
    CONFIDENCE_DISCOUNT: getTunable(store, 'employer.CONFIDENCE_DISCOUNT'),
    HORIZON_MULTIPLIER: {
      NEAR: getTunable(store, 'employer.HORIZON_NEAR'),
      MID: getTunable(store, 'employer.HORIZON_MID'),
      FAR: getTunable(store, 'employer.HORIZON_FAR'),
    },
    MIN_VERIFIED_SKILLS: getTunable(store, 'employer.MIN_VERIFIED_SKILLS'),
    T_CONF: getTunable(store, 'ssie.T_CONF'), // shared, not duplicated — see module header
    CROSS_DOMAIN_BOOST: getTunable(store, 'employer.CROSS_DOMAIN_BOOST'),
    MIN_MATCH_OUTCOMES_FOR_DIAGNOSTIC: getTunable(store, 'employer.MIN_MATCH_OUTCOMES_FOR_DIAGNOSTIC'),
    MIN_SKILLSHIFT_OUTCOMES_FOR_DIAGNOSTIC: getTunable(store, 'employer.MIN_SKILLSHIFT_OUTCOMES_FOR_DIAGNOSTIC'),
  };
}

module.exports = {
  REGISTRY,
  getTunable,
  setTunable,
  resetTunable,
  listTunables,
  getChangeLog,
  resolveSSIEConfig,
  resolveEmployerConfig,
};
