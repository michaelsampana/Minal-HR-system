// Constants reference — SSIE_MINAL_Merged_Algorithm_v1.md "Constants reference" section
// and Integration Contract §6 initial parameters.
//
// TUNABLE FLAG: every numeric value here is a reasoned starting guess from the
// spec docs, not calibrated against real outcomes. See /FLAGS.md at the repo
// root — do not treat these as validated.
//
// In production these should be admin-tunable via the config collection
// (Integration Contract §5: "Trust parameter reads come from the admin
// config collection so UC-A03 governs SSIE weights with zero console
// changes"). Here they're read from this module, with a getSharedConfig()
// escape hatch so callers don't hardcode a second copy (see T_CONF note
// in skill_taxonomy_reconciliation.md §5 — this constant in particular is
// meant to be shared across the SSIE and Employer systems, not duplicated).

const CONSTANTS = {
  // primitive scoring
  CONSTRAINT_MULT: [1.0, 1.2, 1.4, 1.6], // index = constraintLevel 0-3
  SKILL_WEIGHTS_DEFAULT: { sense: 0.2, interpret: 0.2, decide: 0.2, act: 0.2, adjust: 0.2 },

  // thresholds
  T_VERIFY: 70, // score threshold for verified badge
  T_CONF: 60,   // confidence threshold to report/act on any score — SHARED with employer side
  T_GAP: 50,    // score ceiling that triggers gapFlagged when self-claim is high
  HIGH_CLAIM: 70, // self-assessed level considered a strong claim

  // evidence gating
  MIN_OBSERVATIONS: 5,       // minimum evidence count to report a score
  MIN_CHANNEL_DIVERSITY: 2,  // minimum distinct sourceChannels to report a score
  TOTAL_CHANNELS: 7,         // workLog, deliverableCycle, dispute, endorsement, quest, profileBuilder, peerReview
  TOTAL_CONTEXTS: 6,         // written, dispute, quest, workLog, deliverableCycle, peerReview

  // decay
  RECENCY_HALF_LIFE_DAYS: 180,
  MAX_OBSERVATION_AGE_DAYS: 540, // 3 half-lives — Stage 7 prune

  // credibility weights (soft-skill formula, Integration Contract §4.1 / §6)
  CREDIBILITY_WEIGHTS_SOFT: { w_q: 0.30, w_p: 0.20, w_s: 0.50 },

  // reliability / accountability deltas
  RELIABILITY_DELTAS: { r_1: 0.10, r_2: 0.05 },
  ACCOUNTABILITY_DELTAS: { a_1: 0.10, a_2: 0.15 },

  // calibration
  CALIBRATION_C: 1.0,
  CALIBRATION_BOUND: 0.05, // modifier clamped to [-0.05, +0.05]

  // rollout / score-shock control
  BLEND_RAMP_DAYS: 60,

  // observation storage cap (Integration Contract §8: "cap ssieObservations
  // like the existing 50-event eventLog[] pattern, with monthly archival")
  MAX_OBSERVATIONS_PER_USER: 500,
  MAX_EVENT_LOG_ENTRIES: 50,

  // ---------------------------------------------------------------------
  // Employer-side (employer_algorithm_spec.md + skill_taxonomy_reconciliation.md)
  // T_CONF above is deliberately reused here, not duplicated — this resolves
  // the Tier 3 flag from skill_taxonomy_reconciliation.md §5 ("should be one
  // shared config value, not two independently-set constants that happen to
  // match today"). Both sides now read the same constant from this module.
  // ---------------------------------------------------------------------
  CW_CURRENT: 0.4,   // Stage 4 composite weight — currentFit
  CW_EMERGING: 0.6,  // Stage 4 composite weight — emergingFit (future-fit weighted higher, per spec's stated thesis)
  CONFIDENCE_DISCOUNT: 0.6, // applied to candidate score when SSIE confidence < T_CONF
  HORIZON_MULTIPLIER: { NEAR: 1.0, MID: 0.7, FAR: 0.4 },
  MIN_VERIFIED_SKILLS: 3, // Stage 4.3 — below this, match confidence can't be HIGH
  AUTOMATION_PRESSURE_WEIGHTS: { w1: 0.25, w2: 0.25, w3: 0.25, w4: 0.25 }, // equal-weighted per spec §2.3 suggested starting point
};

module.exports = CONSTANTS;
