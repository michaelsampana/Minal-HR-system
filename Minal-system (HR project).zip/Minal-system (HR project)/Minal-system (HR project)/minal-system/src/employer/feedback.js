// Outcome feedback-loop scaffold.
//
// Per llm_handoff_brief.md Tier 2: "A feedback-loop mechanism recording real
// outcomes (did the predicted skill shift happen, did the matched candidate
// work out) on both the employer and candidate sides."
//
// THIS IS LOGGING ONLY. No score, weight, or threshold anywhere in the
// system reads from this data yet — that would mean calibrating against
// outcomes before enough of them exist, which is exactly the "don't
// fabricate calibration" rule this whole build has followed throughout. The
// only thing built here is the plumbing to capture outcomes as they happen,
// so a real calibration pass has real data to work from later, instead of
// having to start collecting from zero the day someone asks for it.
//
// Two outcome types, matching the brief's own wording exactly:
//   1. Skill-shift outcome — did a predicted emerging/declining skill need
//      actually materialize for this employer, checked back later?
//   2. Match outcome — did a specific employer-candidate match actually get
//      hired, and did it work out?

const crypto = require('crypto');

// ---------------------------------------------------------------------------
// 1. Skill-shift outcome (employer side)
// ---------------------------------------------------------------------------

/**
 * Records whether a specific predicted skill shift (from a specific
 * futureNeedProfile snapshot) actually happened, in reality, later.
 *
 * @param {import('../db/store').JSONStore} store
 * @param {string} employerId
 * @param {{skillId: string, direction: 'UP'|'DOWN', outcome: 'occurred'|'did_not_occur'|'partially'|'too_early_to_tell', notes?: string}} feedback
 */
function recordSkillShiftOutcome(store, employerId, feedback) {
  const profile = store.get(`/employers/${employerId}/futureNeedProfile`);
  if (!profile) {
    throw new Error(`recordSkillShiftOutcome: employer ${employerId} has no futureNeedProfile to record an outcome against.`);
  }
  if (!['occurred', 'did_not_occur', 'partially', 'too_early_to_tell'].includes(feedback.outcome)) {
    throw new Error(`recordSkillShiftOutcome: outcome must be one of occurred/did_not_occur/partially/too_early_to_tell, got "${feedback.outcome}"`);
  }

  const entry = {
    feedbackId: `fb_${crypto.randomUUID()}`,
    skillId: feedback.skillId,
    direction: feedback.direction,
    outcome: feedback.outcome,
    notes: feedback.notes || null,
    predictedAt: profile.generatedAt, // ties the outcome to the specific forecast snapshot it's judging
    recordedAt: new Date().toISOString(),
  };

  store.appendToArrayField(`/employers/${employerId}/outcomeFeedback`, 'skillShiftEntries', entry, 200);
  return entry;
}

function getSkillShiftOutcomes(store, employerId) {
  return (store.get(`/employers/${employerId}/outcomeFeedback`) || {}).skillShiftEntries || [];
}

// ---------------------------------------------------------------------------
// 2. Match outcome (spans employer + candidate)
// ---------------------------------------------------------------------------

/**
 * Records whether a specific employer-candidate match actually turned into a
 * hire, and if so, how it went. Written under the match record itself, since
 * an outcome is meaningless without the match it's judging.
 *
 * @param {import('../db/store').JSONStore} store
 * @param {string} employerId
 * @param {string} candidateId
 * @param {{hired: boolean, workedOut?: 'yes'|'no'|'mixed'|'too_early_to_tell', notes?: string}} feedback
 */
function recordMatchOutcome(store, employerId, candidateId, feedback) {
  const matchPath = `/matches/${employerId}_${candidateId}`;
  const match = store.get(matchPath);
  if (!match) {
    throw new Error(`recordMatchOutcome: no match record at ${matchPath} — run matchCandidateToEmployer first.`);
  }
  if (typeof feedback.hired !== 'boolean') {
    throw new Error('recordMatchOutcome: feedback.hired must be true or false');
  }
  if (feedback.hired && feedback.workedOut && !['yes', 'no', 'mixed', 'too_early_to_tell'].includes(feedback.workedOut)) {
    throw new Error(`recordMatchOutcome: workedOut must be one of yes/no/mixed/too_early_to_tell, got "${feedback.workedOut}"`);
  }

  const entry = {
    feedbackId: `fb_${crypto.randomUUID()}`,
    hired: feedback.hired,
    workedOut: feedback.hired ? (feedback.workedOut || 'too_early_to_tell') : null,
    notes: feedback.notes || null,
    predictedAt: match.matchedAt, // ties the outcome to the specific match it's judging
    // snapshot the prediction itself, so later analysis doesn't need to
    // cross-reference a match record that may have since been recomputed
    compositeFitAtMatch: match.compositeFit,
    futureAdvantageAtMatch: match.futureAdvantage,
    recordedAt: new Date().toISOString(),
  };

  store.appendToArrayField(matchPath, 'outcomeFeedback', entry, 50);
  return entry;
}

function getMatchOutcomes(store, employerId, candidateId) {
  const match = store.get(`/matches/${employerId}_${candidateId}`);
  return match?.outcomeFeedback || [];
}

// ---------------------------------------------------------------------------
// Descriptive summary only — counts, not calibration. Deliberately does NOT
// compute anything like "prediction accuracy rate" as a score, since a
// handful of early outcomes turned into a confident-looking percentage is
// exactly the kind of premature calibration this scaffold exists to avoid.
// ---------------------------------------------------------------------------

function summarizeFeedback(store, employerId) {
  const skillShifts = getSkillShiftOutcomes(store, employerId);
  const matches = store.get('/matches') || {};

  const matchOutcomesForEmployer = Object.entries(matches)
    .filter(([key]) => key.startsWith(`${employerId}_`))
    .flatMap(([, m]) => m.outcomeFeedback || []);

  return {
    skillShiftOutcomeCount: skillShifts.length,
    skillShiftOutcomeBreakdown: countBy(skillShifts, (e) => e.outcome),
    matchOutcomeCount: matchOutcomesForEmployer.length,
    matchHiredCount: matchOutcomesForEmployer.filter((m) => m.hired).length,
    matchWorkedOutBreakdown: countBy(matchOutcomesForEmployer.filter((m) => m.hired), (e) => e.workedOut),
    note: 'Descriptive counts only — nothing in the system reads these to adjust any score or weight yet. See FLAGS_EMPLOYER.md #10.',
  };
}

function countBy(arr, fn) {
  const out = {};
  for (const item of arr) {
    const k = fn(item);
    out[k] = (out[k] || 0) + 1;
  }
  return out;
}

module.exports = {
  recordSkillShiftOutcome,
  getSkillShiftOutcomes,
  recordMatchOutcome,
  getMatchOutcomes,
  summarizeFeedback,
};
