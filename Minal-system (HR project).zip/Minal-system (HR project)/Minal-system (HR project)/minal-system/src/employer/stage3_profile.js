// STAGE 3 — Composite Future-Need Profile
// employer_algorithm_spec.md, Stage 3.

const { EMPLOYER_CONSTANTS, SKILL_SHIFT_MAP, CROSS_DOMAIN_SKILLS } = require('./constants');
const { resolveEmployerConfig } = require('../config/adminConfig');
const { recordUnmappedTask } = require('./coverageBacklog');

function clamp(min, max, v) {
  return Math.max(min, Math.min(max, v));
}

function adoptionModifier(changeReadinessScore) {
  const { HIGH_THRESHOLD, HIGH_VALUE, MID_THRESHOLD, MID_VALUE, LOW_VALUE } = EMPLOYER_CONSTANTS.ADOPTION_MODIFIER;
  if (changeReadinessScore >= HIGH_THRESHOLD) return HIGH_VALUE;
  if (changeReadinessScore >= MID_THRESHOLD) return MID_VALUE;
  return LOW_VALUE;
}

function estimateHorizon(pressure, changeReadinessScore) {
  const { HORIZON_PRESSURE_THRESHOLD, HORIZON_READINESS_THRESHOLD } = EMPLOYER_CONSTANTS;
  if (pressure >= HORIZON_PRESSURE_THRESHOLD && changeReadinessScore >= HORIZON_READINESS_THRESHOLD) return 'NEAR';
  if (pressure >= HORIZON_PRESSURE_THRESHOLD) return 'MID';
  return 'FAR';
}

/**
 * extractCurrentSkillsFromJobPosting is named but not specified beyond its
 * signature in the source spec — real implementation needs NLP over an
 * actual job posting, which this build package doesn't include. As a
 * reasoned stand-in: today's core, currently-required skill for a task is
 * approximated as the task's DOWN-direction (declining-but-still-needed-now)
 * skillId from SKILL_SHIFT_MAP, since that's literally what the role
 * primarily demands day-to-day before any automation shift happens.
 * Flagged in FLAGS_EMPLOYER.md item #4 — replace with real job-posting NLP.
 */
function extractCurrentSkillsFromJobPosting(_employerId, roleTasks) {
  const current = [];
  for (const taskId of roleTasks) {
    const shifts = SKILL_SHIFT_MAP[taskId];
    if (!shifts) continue;
    for (const shift of shifts) {
      if (shift.direction === 'DOWN') current.push(shift.skillId);
    }
  }
  return [...new Set(current)];
}

/**
 * @param {import('../db/store').JSONStore} store
 * @param {string} employerId
 */
function buildFutureNeedProfile(store, employerId) {
  const cfg = resolveEmployerConfig(store);
  const scoring = store.get(`/employers/${employerId}/scoring`);
  const roleTasks = store.get(`/employers/${employerId}/roleTasks`) || [];
  if (!scoring) {
    throw new Error(`buildFutureNeedProfile: employer ${employerId} has no scoring yet — run Stage 2 first.`);
  }

  const profile = { currentNeeds: [], emergingNeeds: [], decliningNeeds: [] };
  let unmappedCount = 0;

  for (const taskScore of scoring.automationPressureByTask) {
    const pressure = taskScore.automationPressure;
    const shifts = SKILL_SHIFT_MAP[taskScore.roleTaskId];
    if (!shifts) {
      unmappedCount++; // unmapped task — now actually persisted, not just counted in-memory
      recordUnmappedTask(store, taskScore.roleTaskId);
      continue;
    }

    for (const shift of shifts) {
      let urgency = pressure * shift.magnitude * adoptionModifier(scoring.changeReadinessScore);

      // §3.1 cross-domain pattern: judgment/oversight/verification-type
      // skills rise across nearly every mapped task. Previously named but
      // not built (FLAGS_EMPLOYER.md #7) because the spec doesn't specify a
      // boost magnitude — now implemented with that magnitude as a live
      // tunable (employer.CROSS_DOMAIN_BOOST) rather than a silently
      // invented constant, so it's visible and adjustable, not buried.
      const isCrossDomain = shift.direction === 'UP' && CROSS_DOMAIN_SKILLS.includes(shift.skillId);
      if (isCrossDomain) {
        urgency = urgency * (1 + cfg.CROSS_DOMAIN_BOOST);
      }

      const weightedSkill = {
        skillId: shift.skillId,
        weight: clamp(0, 100, urgency),
        horizon: estimateHorizon(pressure, scoring.changeReadinessScore),
        crossDomainBoosted: isCrossDomain || undefined, // extension field, omitted (undefined) when not applicable
      };
      if (shift.direction === 'UP') profile.emergingNeeds.push(weightedSkill);
      else profile.decliningNeeds.push(weightedSkill);
    }
  }

  profile.currentNeeds = extractCurrentSkillsFromJobPosting(employerId, roleTasks);
  profile._unmappedTaskCount = unmappedCount; // extension for ops visibility, per §3.1's recommendation to track this metric

  gateProfileConfidence(profile, scoring);
  profile.generatedAt = new Date().toISOString();

  store.set(`/employers/${employerId}/futureNeedProfile`, profile);
  return profile;
}

function gateProfileConfidence(profile, scoring) {
  if (scoring.changeReadinessConfidence === 'LOW' && profile._unmappedTaskCount > 0) {
    profile.overallConfidence = 'LOW';
    profile.flag = 'needs richer employer input or manual skill-map coverage';
  } else if (scoring.changeReadinessConfidence === 'LOW') {
    profile.overallConfidence = 'MEDIUM';
  } else {
    profile.overallConfidence = 'HIGH';
  }
  return profile;
}

module.exports = { buildFutureNeedProfile, adoptionModifier, estimateHorizon, gateProfileConfidence, extractCurrentSkillsFromJobPosting };
