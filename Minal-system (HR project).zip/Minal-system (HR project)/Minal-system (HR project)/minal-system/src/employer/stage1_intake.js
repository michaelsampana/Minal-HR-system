// STAGE 1 — Employer Intake
// employer_algorithm_spec.md, Stage 1.
//
// COMPLIANCE FLAG, CARRIED FORWARD FROM THE SPEC (§1.1, and Known
// Limitations #4): "scraping job boards / LinkedIn / company sites has ToS
// and legal exposure... this is a build blocker, not a nice-to-have."
//
// This build does NOT implement any scraping. buildAutoProfile here accepts
// the autoProfile fields as direct input (e.g. typed into a form, or passed
// via the API) instead of deriving them from lookupSector/getHeadcountHistory/
// diffJobPostings/detectTechStack/getRecentExecHires, which the spec assumes
// come from scraped or licensed third-party data. Wiring those real data
// sources in is explicitly out of scope until legal/ToS review happens —
// see FLAGS_EMPLOYER.md item #1.

const QUESTION_BANK = {
  BOTTLENECK_Q: 'What breaks first if this role sits empty for a month?',
  FRICTION_Q: 'What\u2019s the most repetitive part of this role right now?',
  ADOPTION_SPEED_Q: 'How long did it take your team to actually use [tool] daily after adopting it?',
  CHANGE_HISTORY_Q: 'What\u2019s the last new tool/process your team adopted, and how did that go?',
  FUTURE_PROJECTION_Q: 'If a competitor solved [bottleneck] in 2 years, what would that look like?',
};

/**
 * §1.2 — adaptive micro-interview selection, capped at 4 questions.
 * @param {object} autoProfile
 * @returns {string[]} question keys into QUESTION_BANK
 */
function selectMicroInterviewSet(autoProfile) {
  const questions = ['BOTTLENECK_Q', 'FRICTION_Q'];
  if (autoProfile.postingLanguageDrift?.hasNewToolMentions) {
    questions.push('ADOPTION_SPEED_Q');
  } else {
    questions.push('CHANGE_HISTORY_Q');
  }
  questions.push('FUTURE_PROJECTION_Q');
  return questions;
}

/**
 * §1.1 — accepts already-known profile fields as input (see compliance flag
 * above) rather than deriving them via scraping. Fills reasonable defaults
 * for anything not supplied so the pipeline still runs on partial input.
 */
function buildAutoProfile(input = {}) {
  return {
    sector: input.sector ?? 'unspecified',
    headcountTrend: input.headcountTrend ?? { last12mo: 'flat', byDept: {} },
    growthStage: input.growthStage ?? 'growth',
    postingLanguageDrift: input.postingLanguageDrift ?? { hasNewToolMentions: false, addedTerms: [], droppedTerms: [] },
    techStackSignals: input.techStackSignals ?? [],
    leadershipChanges: input.leadershipChanges ?? [],
    capturedAt: new Date().toISOString(),
  };
}

/**
 * @param {import('../db/store').JSONStore} store
 * @param {string} employerId
 * @param {object} autoProfileInput - see buildAutoProfile
 * @param {string[]} roleTasks - SKILL_SHIFT_MAP task category ids this role covers
 */
function employerIntake(store, employerId, autoProfileInput, roleTasks = []) {
  const autoProfile = buildAutoProfile(autoProfileInput);
  store.set(`/employers/${employerId}/autoProfile`, autoProfile);
  store.set(`/employers/${employerId}/roleTasks`, roleTasks);

  const questionKeys = selectMicroInterviewSet(autoProfile);
  const questions = questionKeys.map((key) => ({ key, text: QUESTION_BANK[key] }));
  store.set(`/employers/${employerId}/pendingInterview`, questions);

  return { autoProfile, questions };
}

/**
 * Records the employer's micro-interview answers (Stage 1 output schema).
 * @param {import('../db/store').JSONStore} store
 * @param {string} employerId
 * @param {{bottleneck: string, friction: string, changeReadinessRaw: string, futureProjection: string}} responses
 */
function submitInterviewResponses(store, employerId, responses) {
  store.set(`/employers/${employerId}/interviewResponses`, responses);
  store.set(`/employers/${employerId}/intakeComplete`, true);
  store.set(`/employers/${employerId}/intakeCompletedAt`, new Date().toISOString());
  return responses;
}

module.exports = { employerIntake, buildAutoProfile, selectMicroInterviewSet, submitInterviewResponses, QUESTION_BANK };
