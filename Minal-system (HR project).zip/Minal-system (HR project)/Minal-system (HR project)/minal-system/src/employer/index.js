// Employer pipeline orchestrator. Mirrors src/ssie/index.js's role: a single
// place an API layer calls into, rather than the API routes touching stage
// internals directly.

const { employerIntake, submitInterviewResponses } = require('./stage1_intake');
const { runScoring } = require('./stage2_scoring');
const { buildFutureNeedProfile } = require('./stage3_profile');
const { matchCandidateToEmployer, rankCandidatesForEmployer } = require('./stage4_matching');
const { recordSkillShiftOutcome, getSkillShiftOutcomes, recordMatchOutcome, getMatchOutcomes, summarizeFeedback } = require('./feedback');
const { getCoverageBacklog } = require('./coverageBacklog');
const { runWeightFittingDiagnostic } = require('./weightFitting');

/** Runs Stages 2-3 in sequence once intake (Stage 1) is complete. */
function scoreAndBuildProfile(store, employerId) {
  const scoring = runScoring(store, employerId);
  const profile = buildFutureNeedProfile(store, employerId);
  return { scoring, profile };
}

module.exports = {
  employerIntake,
  submitInterviewResponses,
  runScoring,
  buildFutureNeedProfile,
  scoreAndBuildProfile,
  matchCandidateToEmployer,
  rankCandidatesForEmployer,
  recordSkillShiftOutcome,
  getSkillShiftOutcomes,
  recordMatchOutcome,
  getMatchOutcomes,
  summarizeFeedback,
  getCoverageBacklog,
  runWeightFittingDiagnostic,
};
