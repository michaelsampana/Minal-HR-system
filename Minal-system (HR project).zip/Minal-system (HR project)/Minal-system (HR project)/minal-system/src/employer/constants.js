// Employer-side constants, per employer_algorithm_spec.md.
//
// TUNABLE FLAG: every numeric value here is a reasoned starting guess, same
// caveat as the SSIE side. See FLAGS_EMPLOYER.md.
//
// T_CONF is intentionally imported from the SSIE config, not redefined here
// — skill_taxonomy_reconciliation.md §5 explicitly recommends this be one
// shared value, not two independently-set constants that could drift apart.
const SSIE_CONSTANTS = require('../config/constants');

const EMPLOYER_CONSTANTS = {
  // Stage 2 — changeReadinessScore deltas (§2.2)
  CHANGE_READINESS_BASE: 50,
  TIME_DELTAS: { FAST: 20, MODERATE: 5, SLOW: -15, STALLED: -25 },
  SENTIMENT_DELTAS: { POSITIVE: 10, NEGATIVE: -10 },
  OUTCOME_DELTAS: { ADOPTED: 15, ABANDONED: -20 },

  // Stage 2 — automationPressure weights (§2.3) — "equal weighting until
  // outcome data supports adjustment"
  AUTOMATION_PRESSURE_WEIGHTS: { w1: 0.25, w2: 0.25, w3: 0.25, w4: 0.25 },

  // Stage 3 — adoption modifier thresholds (§3.2)
  ADOPTION_MODIFIER: { HIGH_THRESHOLD: 70, HIGH_VALUE: 1.2, MID_THRESHOLD: 40, MID_VALUE: 1.0, LOW_VALUE: 0.7 },

  // Stage 3 — horizon thresholds (§3.2)
  HORIZON_PRESSURE_THRESHOLD: 60,
  HORIZON_READINESS_THRESHOLD: 60,

  // Stage 4 — composite weights (§4.1) — "suggested starting point, product
  // decision not just engineering default"
  CW_CURRENT: 0.4,
  CW_EMERGING: 0.6,

  // Stage 4 — confidence discount + horizon multipliers (§4.2)
  CONFIDENCE_DISCOUNT_BELOW_T_CONF: 0.6,
  HORIZON_MULTIPLIERS: { NEAR: 1.0, MID: 0.7, FAR: 0.4 },

  // Stage 4 — match confidence gate (§4.3)
  MIN_VERIFIED_SKILLS: 3,

  // Shared with SSIE — see comment above
  T_CONF: SSIE_CONSTANTS.T_CONF,
};

// ---------------------------------------------------------------------------
// §2.1 Text-coding pattern lists (starter sets — expand from real transcripts,
// per the spec's own instruction not to touch scoring logic when expanding)
// ---------------------------------------------------------------------------

const TIME_PATTERNS = {
  FAST: ['within a day', 'within a week', 'immediately', 'right away', 'picked it up fast', 'took no time', 'a few days'],
  MODERATE: ['within a month', 'a couple weeks', 'took some time', 'eventually got there', 'few weeks'],
  SLOW: ['took forever', 'months to', 'still getting used to', 'a long time', 'dragged on', 'took a while'],
  STALLED: ['still hasn\u2019t', 'still hasn\'t', 'never really', 'gave up on', 'haven\u2019t gotten around to', 'haven\'t gotten around to', 'stalled', 'still not using'],
};

const SENTIMENT_TERMS = {
  POSITIVE: ['loved it', 'worked great', 'made things easier', 'we\u2019re glad', "we're glad", 'big improvement', 'stuck immediately', 'no complaints'],
  NEGATIVE: ['painful', 'frustrating', 'hated it', 'confusing', 'pushback', 'resistance from the team', 'complained', 'gave up'],
};

const OUTCOME_TERMS = {
  ADOPTED: ['still using it', 'stuck', 'part of how we work now', 'everyone uses it', 'became standard'],
  ABANDONED: ['went back to', 'dropped it', 'stopped using', 'reverted to', 'no longer use', 'didn\u2019t stick', "didn't stick"],
};

// ---------------------------------------------------------------------------
// §3.1 SKILL_SHIFT_MAP — starter coverage, 10 task categories
// ---------------------------------------------------------------------------

const SKILL_SHIFT_MAP = {
  customer_care_ticket_response: [
    { skillId: 'response_speed', direction: 'DOWN', magnitude: 0.7 },
    { skillId: 'ai_output_judgment', direction: 'UP', magnitude: 0.8 },
    { skillId: 'escalation_handling', direction: 'UP', magnitude: 0.6 },
    { skillId: 'empathy_in_conflict', direction: 'UP', magnitude: 0.5 },
  ],
  basic_data_entry: [
    { skillId: 'data_accuracy', direction: 'DOWN', magnitude: 0.6 },
    { skillId: 'exception_spotting', direction: 'UP', magnitude: 0.7 },
    { skillId: 'process_improvement', direction: 'UP', magnitude: 0.5 },
  ],
  bookkeeping_transaction_entry: [
    { skillId: 'manual_reconciliation', direction: 'DOWN', magnitude: 0.7 },
    { skillId: 'anomaly_detection', direction: 'UP', magnitude: 0.7 },
    { skillId: 'financial_storytelling', direction: 'UP', magnitude: 0.5 },
    { skillId: 'compliance_judgment', direction: 'UP', magnitude: 0.6 },
  ],
  junior_content_writing: [
    { skillId: 'draft_generation_speed', direction: 'DOWN', magnitude: 0.8 },
    { skillId: 'editorial_judgment', direction: 'UP', magnitude: 0.8 },
    { skillId: 'brand_voice_consistency', direction: 'UP', magnitude: 0.6 },
    { skillId: 'fact_verification', direction: 'UP', magnitude: 0.7 },
  ],
  entry_level_coding_implementation: [
    { skillId: 'boilerplate_coding', direction: 'DOWN', magnitude: 0.7 },
    { skillId: 'code_review_judgment', direction: 'UP', magnitude: 0.8 },
    { skillId: 'system_design_thinking', direction: 'UP', magnitude: 0.7 },
    { skillId: 'ai_prompt_engineering', direction: 'UP', magnitude: 0.6 },
  ],
  recruitment_resume_screening: [
    { skillId: 'manual_screening_speed', direction: 'DOWN', magnitude: 0.7 },
    { skillId: 'candidate_judgment_nuance', direction: 'UP', magnitude: 0.7 },
    { skillId: 'bias_auditing', direction: 'UP', magnitude: 0.6 },
    { skillId: 'relationship_building', direction: 'UP', magnitude: 0.5 },
  ],
  warehouse_inventory_tracking: [
    { skillId: 'manual_stock_counting', direction: 'DOWN', magnitude: 0.8 },
    { skillId: 'exception_handling', direction: 'UP', magnitude: 0.6 },
    { skillId: 'systems_troubleshooting', direction: 'UP', magnitude: 0.6 },
    { skillId: 'process_optimization', direction: 'UP', magnitude: 0.5 },
  ],
  sales_lead_qualification: [
    { skillId: 'manual_lead_scoring', direction: 'DOWN', magnitude: 0.6 },
    { skillId: 'relationship_deepening', direction: 'UP', magnitude: 0.7 },
    { skillId: 'objection_handling', direction: 'UP', magnitude: 0.6 },
    { skillId: 'ai_tool_oversight', direction: 'UP', magnitude: 0.5 },
  ],
  basic_graphic_design: [
    { skillId: 'manual_asset_production', direction: 'DOWN', magnitude: 0.7 },
    { skillId: 'creative_direction', direction: 'UP', magnitude: 0.8 },
    { skillId: 'brand_taste_judgment', direction: 'UP', magnitude: 0.7 },
    { skillId: 'ai_prompt_iteration', direction: 'UP', magnitude: 0.6 },
  ],
  legal_document_review_junior: [
    { skillId: 'manual_clause_review', direction: 'DOWN', magnitude: 0.7 },
    { skillId: 'risk_interpretation', direction: 'UP', magnitude: 0.8 },
    { skillId: 'client_communication', direction: 'UP', magnitude: 0.5 },
    { skillId: 'ai_output_verification', direction: 'UP', magnitude: 0.7 },
  ],
};

// Cross-domain pattern noted in the spec (§3.1): judgment/oversight/
// verification-type skills rise across nearly every mapped task. Not yet
// built as its own weighted lookup — flagged in FLAGS_EMPLOYER.md rather
// than silently added, since the spec recommends it but doesn't specify the
// boost magnitude.
const CROSS_DOMAIN_SKILLS = [
  'ai_output_judgment', 'exception_spotting', 'anomaly_detection', 'fact_verification',
  'code_review_judgment', 'bias_auditing', 'ai_output_verification',
];

module.exports = {
  EMPLOYER_CONSTANTS,
  TIME_PATTERNS,
  SENTIMENT_TERMS,
  OUTCOME_TERMS,
  SKILL_SHIFT_MAP,
  CROSS_DOMAIN_SKILLS,
};
