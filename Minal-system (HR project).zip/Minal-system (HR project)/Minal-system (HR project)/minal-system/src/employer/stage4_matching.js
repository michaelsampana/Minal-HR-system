// STAGE 4 — Matching Candidates Against the Future-Need Profile
// employer_algorithm_spec.md, Stage 4.
//
// Pulls candidate skills from the SAME store the SSIE pipeline writes to
// (/users/{candidateId}/softSkillProfile), and reconciles employer-side
// task-specific skillIds against SSIE's canonical taxonomy via
// getCandidateScoreForEmployerSkill — NOT a direct key lookup. See
// reconciliation.js and skill_taxonomy_reconciliation.md §4.

const { EMPLOYER_CONSTANTS } = require('./constants');
const { resolveEmployerConfig } = require('../config/adminConfig');
const { getCandidateScoreForEmployerSkill } = require('./reconciliation');
const { recordUnmappedSkill } = require('./coverageBacklog');

function clamp(min, max, v) {
  return Math.max(min, Math.min(max, v));
}

/** Candidate skills, shaped for the reconciliation lookup: { skillName: {score, confidence} }. */
function getCandidateSkillsForMatching(store, candidateId) {
  const profiles = store.get(`/users/${candidateId}/softSkillProfile`) || {};
  const out = {};
  for (const [skillName, output] of Object.entries(profiles)) {
    out[skillName] = { score: output.score, confidence: output.confidence };
  }
  return out;
}

function countVerifiedSkills(store, candidateId) {
  const claims = store.get(`/users/${candidateId}/skillClaims`) || {};
  return Object.values(claims).filter((c) => c.verificationState === 'verified').length;
}

function confidenceMultiplier(ssieConfidence, cfg) {
  if (ssieConfidence >= cfg.T_CONF) return 1.0;
  return cfg.CONFIDENCE_DISCOUNT;
}

function horizonMultiplier(horizon, cfg) {
  return cfg.HORIZON_MULTIPLIER[horizon] ?? cfg.HORIZON_MULTIPLIER.FAR;
}

/**
 * §4.2 scoreSkillSet — mode is 'BASELINE' (weight always 1.0) or 'WEIGHTED'
 * (uses each need's own weight). Returns null if skillList is empty or every
 * skill is unmapped/unresolvable, matching the spec's NULL-on-empty behavior.
 * @param {import('../db/store').JSONStore} store - needed only to persist
 *   unmapped-skill lookups to the coverage backlog, not for scoring itself.
 * @param {object} cfg - resolved via resolveEmployerConfig(store), passed in
 *   explicitly rather than read from a module-level constant so every value
 *   here is live-editable via the admin config panel.
 */
function scoreSkillSet(store, skillList, candidateSkills, mode, cfg) {
  if (!skillList || skillList.length === 0) return null;

  let totalWeight = 0;
  let weightedSum = 0;

  for (const need of skillList) {
    const resolved = getCandidateScoreForEmployerSkill(need.skillId, candidateSkills);
    if (resolved.unmapped) recordUnmappedSkill(store, need.skillId);
    const effectiveScore = resolved.score * confidenceMultiplier(resolved.confidence, cfg);

    let weight = mode === 'WEIGHTED' ? need.weight : 1.0;
    weight = weight * horizonMultiplier(need.horizon, cfg);

    weightedSum += effectiveScore * weight;
    totalWeight += weight;
  }

  if (totalWeight === 0) return null;
  return weightedSum / totalWeight;
}

function deriveMatchConfidence(employerProfileConfidence, candidateDataThin) {
  if (employerProfileConfidence === 'LOW' || candidateDataThin) return 'LOW';
  if (employerProfileConfidence === 'MEDIUM') return 'MEDIUM';
  return 'HIGH';
}

/**
 * §4.1 — the core matching function.
 * @param {import('../db/store').JSONStore} store
 * @param {string} employerId
 * @param {string} candidateId
 */
function matchCandidateToEmployer(store, employerId, candidateId) {
  const cfg = resolveEmployerConfig(store);
  const futureProfile = store.get(`/employers/${employerId}/futureNeedProfile`);
  if (!futureProfile) {
    throw new Error(`matchCandidateToEmployer: employer ${employerId} has no futureNeedProfile yet — run Stage 3 first.`);
  }
  const candidateSkills = getCandidateSkillsForMatching(store, candidateId);

  const currentFit = scoreSkillSet(store, futureProfile.currentNeeds.map((s) => ({ skillId: s, weight: 1, horizon: 'NEAR' })), candidateSkills, 'BASELINE', cfg);
  const emergingFit = scoreSkillSet(store, futureProfile.emergingNeeds, candidateSkills, 'WEIGHTED', cfg);
  const decliningFit = scoreSkillSet(store, futureProfile.decliningNeeds, candidateSkills, 'WEIGHTED', cfg);
  // decliningFit is informational, not penalized — see Known Limitations #2 in FLAGS_EMPLOYER.md

  const compositeFit =
    currentFit != null && emergingFit != null
      ? cfg.CW_CURRENT * currentFit + cfg.CW_EMERGING * emergingFit
      : (currentFit ?? emergingFit ?? 0);
  const futureAdvantage = emergingFit != null && currentFit != null ? emergingFit - currentFit : null;

  const candidateDataThin = countVerifiedSkills(store, candidateId) < cfg.MIN_VERIFIED_SKILLS;

  const match = {
    employerId,
    candidateId,
    currentFit,
    emergingFit,
    decliningFitInfo: decliningFit,
    compositeFit: clamp(0, 100, compositeFit),
    futureAdvantage,
    confidence: deriveMatchConfidence(futureProfile.overallConfidence, candidateDataThin),
    matchedAt: new Date().toISOString(),
  };

  store.set(`/matches/${employerId}_${candidateId}`, match);
  return match;
}

const CONFIDENCE_RANK = { HIGH: 3, MEDIUM: 2, LOW: 1 };

function sortByFitThenConfidence(results) {
  return [...results].sort((a, b) => {
    if (b.compositeFit !== a.compositeFit) return b.compositeFit - a.compositeFit;
    return CONFIDENCE_RANK[b.confidence] - CONFIDENCE_RANK[a.confidence];
  });
}

/**
 * §4.4 — rank a pool of candidates for one employer.
 * @param {import('../db/store').JSONStore} store
 * @param {string} employerId
 * @param {string[]} candidatePool
 */
function rankCandidatesForEmployer(store, employerId, candidatePool) {
  const results = [];
  for (const candidateId of candidatePool) {
    const match = matchCandidateToEmployer(store, employerId, candidateId);
    if (match.compositeFit != null) results.push(match);
  }
  return sortByFitThenConfidence(results);
}

module.exports = {
  matchCandidateToEmployer,
  rankCandidatesForEmployer,
  scoreSkillSet,
  confidenceMultiplier,
  horizonMultiplier,
  deriveMatchConfidence,
  getCandidateSkillsForMatching,
  countVerifiedSkills,
};
