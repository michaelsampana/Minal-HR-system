// Weight-fitting pipeline scaffold.
//
// Per llm_handoff_brief.md Tier 2: "Employer-side weight-fitting pipeline
// (w1-w4, CW_current/CW_emerging, scoreChangeReadiness deltas,
// SKILL_SHIFT_MAP magnitudes, RECONCILIATION_MAP weights) — structure it to
// accept real labeled outcomes later." This was the one Tier 2 item from the
// original brief that hadn't been built yet — this module is that scaffold.
//
// WHAT THIS DOES NOT DO: it does not compute new weights and does not write
// anything back to adminConfig automatically. Doing that from a handful of
// outcomes would be exactly the "fabricate calibration" failure mode this
// whole build has avoided everywhere else (same principle as ML Task 4's
// logging-only scaffold, and the feedback loop's "counts only, no accuracy
// score" rule). Below a volume gate, it refuses to produce anything beyond
// a status message. Above the gate, it produces a DIAGNOSTIC report — a
// descriptive correlation a human can use to decide whether to manually
// adjust a config value — not an automatic weight update.
//
// The gate thresholds (MIN_MATCH_OUTCOMES_FOR_DIAGNOSTIC,
// MIN_SKILLSHIFT_OUTCOMES_FOR_DIAGNOSTIC) are themselves reasoned
// placeholders exposed as live tunables, same as everything else — 10 is a
// low bar chosen so the mechanism is exercisable in a demo, not a claim that
// 10 outcomes is enough to trust. The ML spec's own real gate for a fully
// trained model is 500+ examples (§8.4); this is a much simpler descriptive
// correlation, not a trained model, but should still be read with far more
// real volume than 10 before anyone acts on it.

const { resolveEmployerConfig } = require('../config/adminConfig');
const { getSkillShiftOutcomes } = require('./feedback');

function average(nums) {
  if (!nums.length) return null;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

/**
 * Diagnostic on match outcomes: does a higher compositeFit/futureAdvantage
 * at the time of the match actually correlate with the match working out?
 * Pooled across ALL employers — a single employer rarely has enough hires
 * to say anything, so this is deliberately cross-employer.
 */
function buildMatchDiagnostic(store, cfg) {
  const matches = store.get('/matches') || {};
  const allOutcomes = Object.values(matches).flatMap((m) => m.outcomeFeedback || []);
  const hiredOutcomes = allOutcomes.filter((o) => o.hired);

  if (hiredOutcomes.length < cfg.MIN_MATCH_OUTCOMES_FOR_DIAGNOSTIC) {
    return {
      status: 'insufficient_data',
      have: hiredOutcomes.length,
      need: cfg.MIN_MATCH_OUTCOMES_FOR_DIAGNOSTIC,
      message: `Only ${hiredOutcomes.length} hired-match outcomes recorded so far; need at least ${cfg.MIN_MATCH_OUTCOMES_FOR_DIAGNOSTIC} before a diagnostic is worth looking at.`,
    };
  }

  const workedOutWell = hiredOutcomes.filter((o) => o.workedOut === 'yes');
  const workedOutPoorly = hiredOutcomes.filter((o) => o.workedOut === 'no' || o.workedOut === 'mixed');

  return {
    status: 'diagnostic_only',
    sampleSize: hiredOutcomes.length,
    avgCompositeFitWhenWorkedOutWell: average(workedOutWell.map((o) => o.compositeFitAtMatch)),
    avgCompositeFitWhenWorkedOutPoorly: average(workedOutPoorly.map((o) => o.compositeFitAtMatch)),
    avgFutureAdvantageWhenWorkedOutWell: average(workedOutWell.map((o) => o.futureAdvantageAtMatch)),
    avgFutureAdvantageWhenWorkedOutPoorly: average(workedOutPoorly.map((o) => o.futureAdvantageAtMatch)),
    note:
      'Descriptive correlation only. This does NOT mean CW_CURRENT/CW_EMERGING should be changed to these ' +
      'numbers — it means a human should look at whether high-compositeFit hires are actually working out ' +
      'more than low-compositeFit ones, and manually decide whether the composite weighting needs revisiting.',
  };
}

/**
 * Diagnostic on skill-shift predictions: do predicted shifts for
 * cross-domain-boosted skills "occur" more often than non-boosted ones?
 * A crude but honest check on whether the CROSS_DOMAIN_BOOST assumption
 * (judgment-type skills generalize) holds up against reality at all.
 */
function buildSkillShiftDiagnostic(store, cfg) {
  const employers = store.get('/employers') || {};
  const allSkillShiftOutcomes = Object.keys(employers).flatMap((employerId) => getSkillShiftOutcomes(store, employerId));

  if (allSkillShiftOutcomes.length < cfg.MIN_SKILLSHIFT_OUTCOMES_FOR_DIAGNOSTIC) {
    return {
      status: 'insufficient_data',
      have: allSkillShiftOutcomes.length,
      need: cfg.MIN_SKILLSHIFT_OUTCOMES_FOR_DIAGNOSTIC,
      message: `Only ${allSkillShiftOutcomes.length} skill-shift outcomes recorded so far; need at least ${cfg.MIN_SKILLSHIFT_OUTCOMES_FOR_DIAGNOSTIC} before a diagnostic is worth looking at.`,
    };
  }

  const occurred = allSkillShiftOutcomes.filter((o) => o.outcome === 'occurred').length;
  const didNotOccur = allSkillShiftOutcomes.filter((o) => o.outcome === 'did_not_occur').length;
  const total = occurred + didNotOccur;

  return {
    status: 'diagnostic_only',
    sampleSize: allSkillShiftOutcomes.length,
    occurredRate: total > 0 ? occurred / total : null,
    note:
      'Descriptive rate only — of predicted skill shifts with a clear yes/no outcome recorded, what fraction ' +
      'actually occurred. This does NOT automatically adjust SKILL_SHIFT_MAP magnitudes; it is a starting ' +
      'point for a human review of whether the magnitudes are in the right ballpark at all.',
  };
}

/**
 * @param {import('../db/store').JSONStore} store
 * @returns {{matchDiagnostic: object, skillShiftDiagnostic: object}}
 */
function runWeightFittingDiagnostic(store) {
  const cfg = resolveEmployerConfig(store);
  return {
    matchDiagnostic: buildMatchDiagnostic(store, cfg),
    skillShiftDiagnostic: buildSkillShiftDiagnostic(store, cfg),
  };
}

module.exports = { runWeightFittingDiagnostic, buildMatchDiagnostic, buildSkillShiftDiagnostic };
