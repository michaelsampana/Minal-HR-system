// STAGE 2 — Scoring Layer
// employer_algorithm_spec.md, Stage 2.

const { EMPLOYER_CONSTANTS, TIME_PATTERNS, SENTIMENT_TERMS, OUTCOME_TERMS } = require('./constants');
const { lookupTaskAutomationRating, lookupTaskRepetitiveness } = require('./onetLookup');

// ---------------------------------------------------------------------------
// §2.1 Text coding — match order STALLED -> SLOW -> MODERATE -> FAST per spec
// ("check negative buckets first to avoid false positives, e.g. 'wasn't
// immediate, took forever'"). Returns NULL (here: null) if a category has
// both / neither match — "a valid, expected signal, not an error."
// ---------------------------------------------------------------------------

function matchTimeBucket(rawText) {
  const t = rawText.toLowerCase();
  const order = ['STALLED', 'SLOW', 'MODERATE', 'FAST'];
  const hits = order.filter((bucket) => TIME_PATTERNS[bucket].some((p) => t.includes(p)));
  if (hits.length !== 1) return null; // none or multiple/ambiguous -> don't force a guess
  return hits[0];
}

function matchSentiment(rawText) {
  const t = rawText.toLowerCase();
  const pos = SENTIMENT_TERMS.POSITIVE.some((p) => t.includes(p));
  const neg = SENTIMENT_TERMS.NEGATIVE.some((p) => t.includes(p));
  if (pos && neg) return null;
  if (pos) return 'POSITIVE';
  if (neg) return 'NEGATIVE';
  return null;
}

function matchOutcome(rawText) {
  const t = rawText.toLowerCase();
  const adopted = OUTCOME_TERMS.ADOPTED.some((p) => t.includes(p));
  const abandoned = OUTCOME_TERMS.ABANDONED.some((p) => t.includes(p));
  if (adopted && abandoned) return null;
  if (adopted) return 'ADOPTED';
  if (abandoned) return 'ABANDONED';
  return null;
}

function codeChangeReadiness(rawText) {
  return {
    speedMentioned: matchTimeBucket(rawText),
    sentimentMarkers: matchSentiment(rawText),
    outcomeMarker: matchOutcome(rawText),
  };
}

// ---------------------------------------------------------------------------
// §2.2 changeReadinessScore
// ---------------------------------------------------------------------------

function clamp(min, max, v) {
  return Math.max(min, Math.min(max, v));
}

function scoreChangeReadiness(signals) {
  const { TIME_DELTAS, SENTIMENT_DELTAS, OUTCOME_DELTAS, CHANGE_READINESS_BASE } = EMPLOYER_CONSTANTS;
  let score = CHANGE_READINESS_BASE;

  if (signals.speedMentioned && TIME_DELTAS[signals.speedMentioned] != null) {
    score += TIME_DELTAS[signals.speedMentioned];
  }
  if (signals.sentimentMarkers && SENTIMENT_DELTAS[signals.sentimentMarkers] != null) {
    score += SENTIMENT_DELTAS[signals.sentimentMarkers];
  }
  if (signals.outcomeMarker && OUTCOME_DELTAS[signals.outcomeMarker] != null) {
    score += OUTCOME_DELTAS[signals.outcomeMarker];
  }

  const matchedCount = [signals.speedMentioned, signals.sentimentMarkers, signals.outcomeMarker].filter((s) => s != null).length;
  const confidence = matchedCount === 0 ? 'LOW' : matchedCount >= 2 ? 'HIGH' : 'MEDIUM';

  return { changeReadinessScore: clamp(0, 100, score), confidence };
}

// ---------------------------------------------------------------------------
// §2.3 automationPressure per task
// ---------------------------------------------------------------------------

/**
 * calcAdoptionVelocity and estimateSwitchingFriction are NOT specified beyond
 * their signature in the spec — they're reasoned heuristics here, flagged in
 * FLAGS_EMPLOYER.md item #3, not sourced from real adoption-rate data.
 */
function calcAdoptionVelocity(postingLanguageDrift, _roleTaskId) {
  const added = postingLanguageDrift?.addedTerms?.length ?? 0;
  const dropped = postingLanguageDrift?.droppedTerms?.length ?? 0;
  let velocity = 40 + added * 15 - dropped * 5;
  if (postingLanguageDrift?.hasNewToolMentions) velocity += 20;
  return clamp(0, 100, velocity);
}

const HIGH_FRICTION_SECTORS = ['legal_services', 'healthcare_admin'];

function estimateSwitchingFriction(sector, techStackSignals = []) {
  let friction = HIGH_FRICTION_SECTORS.includes(sector) ? 65 : 40;
  friction -= Math.min(20, techStackSignals.length * 5); // more existing modern tooling -> lower friction
  return clamp(0, 100, friction);
}

function scoreAutomationPressure(autoProfile, roleTaskId) {
  const { w1, w2, w3, w4 } = EMPLOYER_CONSTANTS.AUTOMATION_PRESSURE_WEIGHTS;

  const toolMaturity = lookupTaskAutomationRating(roleTaskId);
  const adoptionVelocity = calcAdoptionVelocity(autoProfile.postingLanguageDrift, roleTaskId);
  const taskRepetitiveness = lookupTaskRepetitiveness(roleTaskId);
  const switchingFriction = estimateSwitchingFriction(autoProfile.sector, autoProfile.techStackSignals);

  const pressure = w1 * toolMaturity + w2 * adoptionVelocity + w3 * taskRepetitiveness - w4 * switchingFriction;

  return {
    roleTaskId,
    automationPressure: clamp(0, 100, pressure),
    subScores: { toolMaturity, adoptionVelocity, taskRepetitiveness, switchingFriction },
  };
}

/**
 * Runs Stage 2 end to end for an employer and persists the result.
 * @param {import('../db/store').JSONStore} store
 * @param {string} employerId
 */
function runScoring(store, employerId) {
  const autoProfile = store.get(`/employers/${employerId}/autoProfile`);
  const responses = store.get(`/employers/${employerId}/interviewResponses`);
  const roleTasks = store.get(`/employers/${employerId}/roleTasks`) || [];

  if (!autoProfile || !responses) {
    throw new Error(`runScoring: employer ${employerId} is missing autoProfile or interviewResponses — complete Stage 1 first.`);
  }

  const signals = codeChangeReadiness(responses.changeReadinessRaw || '');
  const { changeReadinessScore, confidence } = scoreChangeReadiness(signals);

  const automationPressureByTask = roleTasks.map((taskId) => scoreAutomationPressure(autoProfile, taskId));

  const scoring = {
    changeReadinessScore,
    changeReadinessConfidence: confidence,
    changeReadinessSignals: signals, // extension beyond the frozen schema, kept for transparency/debugging
    automationPressureByTask,
    scoredAt: new Date().toISOString(),
  };

  store.set(`/employers/${employerId}/scoring`, scoring);
  return scoring;
}

module.exports = {
  codeChangeReadiness,
  scoreChangeReadiness,
  scoreAutomationPressure,
  calcAdoptionVelocity,
  estimateSwitchingFriction,
  runScoring,
  matchTimeBucket,
  matchSentiment,
  matchOutcome,
};
