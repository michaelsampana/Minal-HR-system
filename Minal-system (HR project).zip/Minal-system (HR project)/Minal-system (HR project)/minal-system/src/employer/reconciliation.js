// Skill taxonomy reconciliation, per skill_taxonomy_reconciliation.md.
//
// This is the fix for the real bug the reconciliation doc identifies: the
// employer Stage 4 spec's original scoreSkillSet did a direct
// candidateSkills[need.skillId] lookup, which silently returns zero for
// every candidate because SSIE's candidate-side taxonomy (communication,
// critical_thinking, ...) and the employer's task-specific skillIds
// (ai_output_judgment, escalation_handling, ...) are different vocabularies.
//
// Implement THIS lookup in Stage 4, never a direct key match.

// §1 — reasoned starter taxonomy, NOT extracted from a real production
// skillClaims list. See FLAGS_EMPLOYER.md.
const SSIE_CANONICAL_SKILLS = [
  'communication', 'adaptability', 'leadership', 'critical_thinking',
  'conflict_resolution', 'initiative', 'collaboration', 'emotional_regulation',
  'learning_agility', 'attention_to_detail',
];

// §3 — weighted many-to-many mapping, employer skillId -> SSIE skills.
const RECONCILIATION_MAP = {
  response_speed: [{ skill: 'adaptability', weight: 0.5 }, { skill: 'attention_to_detail', weight: 0.5 }],
  ai_output_judgment: [{ skill: 'critical_thinking', weight: 0.7 }, { skill: 'attention_to_detail', weight: 0.3 }],
  escalation_handling: [{ skill: 'conflict_resolution', weight: 0.6 }, { skill: 'communication', weight: 0.4 }],
  empathy_in_conflict: [{ skill: 'emotional_regulation', weight: 0.6 }, { skill: 'conflict_resolution', weight: 0.4 }],

  data_accuracy: [{ skill: 'attention_to_detail', weight: 1.0 }],
  exception_spotting: [{ skill: 'critical_thinking', weight: 0.7 }, { skill: 'attention_to_detail', weight: 0.3 }],
  process_improvement: [{ skill: 'initiative', weight: 0.6 }, { skill: 'critical_thinking', weight: 0.4 }],

  manual_reconciliation: [{ skill: 'attention_to_detail', weight: 1.0 }],
  anomaly_detection: [{ skill: 'critical_thinking', weight: 0.6 }, { skill: 'attention_to_detail', weight: 0.4 }],
  financial_storytelling: [{ skill: 'communication', weight: 0.8 }, { skill: 'critical_thinking', weight: 0.2 }],
  compliance_judgment: [{ skill: 'critical_thinking', weight: 0.6 }, { skill: 'attention_to_detail', weight: 0.4 }],

  draft_generation_speed: [{ skill: 'adaptability', weight: 1.0 }],
  editorial_judgment: [{ skill: 'critical_thinking', weight: 0.7 }, { skill: 'attention_to_detail', weight: 0.3 }],
  brand_voice_consistency: [{ skill: 'attention_to_detail', weight: 0.6 }, { skill: 'communication', weight: 0.4 }],
  fact_verification: [{ skill: 'attention_to_detail', weight: 0.7 }, { skill: 'critical_thinking', weight: 0.3 }],

  boilerplate_coding: [{ skill: 'adaptability', weight: 1.0 }],
  code_review_judgment: [{ skill: 'critical_thinking', weight: 0.8 }, { skill: 'attention_to_detail', weight: 0.2 }],
  system_design_thinking: [{ skill: 'critical_thinking', weight: 0.7 }, { skill: 'learning_agility', weight: 0.3 }],
  ai_prompt_engineering: [{ skill: 'learning_agility', weight: 0.6 }, { skill: 'critical_thinking', weight: 0.4 }],

  manual_screening_speed: [{ skill: 'adaptability', weight: 1.0 }],
  candidate_judgment_nuance: [{ skill: 'critical_thinking', weight: 0.6 }, { skill: 'communication', weight: 0.4 }],
  bias_auditing: [{ skill: 'critical_thinking', weight: 0.7 }, { skill: 'attention_to_detail', weight: 0.3 }],
  relationship_building: [{ skill: 'communication', weight: 0.6 }, { skill: 'collaboration', weight: 0.4 }],

  manual_stock_counting: [{ skill: 'attention_to_detail', weight: 1.0 }],
  exception_handling: [{ skill: 'critical_thinking', weight: 0.6 }, { skill: 'adaptability', weight: 0.4 }],
  systems_troubleshooting: [{ skill: 'critical_thinking', weight: 0.6 }, { skill: 'learning_agility', weight: 0.4 }],
  process_optimization: [{ skill: 'initiative', weight: 0.6 }, { skill: 'critical_thinking', weight: 0.4 }],

  manual_lead_scoring: [{ skill: 'attention_to_detail', weight: 1.0 }],
  relationship_deepening: [{ skill: 'communication', weight: 0.5 }, { skill: 'collaboration', weight: 0.5 }],
  objection_handling: [{ skill: 'communication', weight: 0.5 }, { skill: 'conflict_resolution', weight: 0.5 }],
  ai_tool_oversight: [{ skill: 'critical_thinking', weight: 0.6 }, { skill: 'learning_agility', weight: 0.4 }],

  manual_asset_production: [{ skill: 'adaptability', weight: 1.0 }],
  creative_direction: [{ skill: 'leadership', weight: 0.5 }, { skill: 'critical_thinking', weight: 0.5 }],
  brand_taste_judgment: [{ skill: 'critical_thinking', weight: 0.6 }, { skill: 'attention_to_detail', weight: 0.4 }],
  ai_prompt_iteration: [{ skill: 'learning_agility', weight: 0.6 }, { skill: 'adaptability', weight: 0.4 }],

  manual_clause_review: [{ skill: 'attention_to_detail', weight: 1.0 }],
  risk_interpretation: [{ skill: 'critical_thinking', weight: 0.8 }, { skill: 'attention_to_detail', weight: 0.2 }],
  client_communication: [{ skill: 'communication', weight: 1.0 }],
  ai_output_verification: [{ skill: 'critical_thinking', weight: 0.6 }, { skill: 'attention_to_detail', weight: 0.4 }],
};

/**
 * §4 corrected lookup — replaces the buggy direct candidateSkills[need.skillId]
 * access. candidateSkills is keyed by SSIE canonical skill name -> { score, confidence }.
 *
 * @param {string} needSkillId - an employer-side task-specific skillId
 * @param {Record<string, {score: number, confidence: number}>} candidateSkills
 * @returns {{score: number, confidence: number, unmapped?: boolean}}
 */
function getCandidateScoreForEmployerSkill(needSkillId, candidateSkills) {
  const mappings = RECONCILIATION_MAP[needSkillId];
  if (!mappings) {
    return { score: 0, confidence: 0, unmapped: true }; // unmapped — log for reconciliation backlog
  }

  let weightedScore = 0;
  let totalWeight = 0;
  let lowestConfidenceSeen = 100;

  for (const m of mappings) {
    const candidateSkill = candidateSkills[m.skill];
    if (candidateSkill == null) continue;
    weightedScore += candidateSkill.score * m.weight;
    totalWeight += m.weight;
    lowestConfidenceSeen = Math.min(lowestConfidenceSeen, candidateSkill.confidence);
  }

  if (totalWeight === 0) return { score: 0, confidence: 0 };

  return {
    score: weightedScore / totalWeight,
    confidence: lowestConfidenceSeen, // conservative: as weak as the weakest contributing SSIE skill
  };
}

module.exports = { SSIE_CANONICAL_SKILLS, RECONCILIATION_MAP, getCandidateScoreForEmployerSkill };
