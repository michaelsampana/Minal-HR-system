// O*NET-style task ratings — REQUIRED EXTERNAL DATASET per
// employer_algorithm_spec.md §2.3: "O*NET Task Ratings (automation/routine-
// task intensity) — publicly available, free. lookupTaskAutomationRating and
// lookupTaskRepetitiveness should map roleTaskId to O*NET task codes."
//
// This build does NOT wire in real O*NET data (that requires downloading and
// mapping the actual O*NET database to each roleTaskId, which is a real data
// -engineering task, not something to fabricate). The table below is a
// reasoned, clearly-labeled placeholder — plausible relative orderings
// (e.g. "basic_data_entry" rated highly automatable, "legal_document_review"
// rated more judgment-heavy) so the pipeline is runnable end-to-end, but
// NOT sourced from the real O*NET database. See FLAGS_EMPLOYER.md item #2.

const PLACEHOLDER_ONET_RATINGS = {
  customer_care_ticket_response: { automationRating: 70, repetitiveness: 75 },
  basic_data_entry: { automationRating: 85, repetitiveness: 90 },
  bookkeeping_transaction_entry: { automationRating: 80, repetitiveness: 80 },
  junior_content_writing: { automationRating: 65, repetitiveness: 60 },
  entry_level_coding_implementation: { automationRating: 60, repetitiveness: 55 },
  recruitment_resume_screening: { automationRating: 70, repetitiveness: 65 },
  warehouse_inventory_tracking: { automationRating: 75, repetitiveness: 80 },
  sales_lead_qualification: { automationRating: 55, repetitiveness: 50 },
  basic_graphic_design: { automationRating: 60, repetitiveness: 45 },
  legal_document_review_junior: { automationRating: 50, repetitiveness: 55 },
};

function lookupTaskAutomationRating(roleTaskId) {
  return PLACEHOLDER_ONET_RATINGS[roleTaskId]?.automationRating ?? 50; // neutral default for unmapped tasks
}

function lookupTaskRepetitiveness(roleTaskId) {
  return PLACEHOLDER_ONET_RATINGS[roleTaskId]?.repetitiveness ?? 50;
}

module.exports = { lookupTaskAutomationRating, lookupTaskRepetitiveness, PLACEHOLDER_ONET_RATINGS };
