// Coverage backlog — persistent tracking of unmapped task categories and
// unmapped employer-skill IDs.
//
// Both SKILL_SHIFT_MAP (Stage 3) and RECONCILIATION_MAP (Stage 4) are
// documented as failing gracefully on unmapped entries: "skip + log."
// Before this module, the "log" half only ever existed as an in-memory
// count (_unmappedTaskCount) that got overwritten on every recompute and
// was never persisted anywhere a person could actually review — so nothing
// was really being tracked "for coverage backlog" the way the comments
// claimed. This module is that missing persistence layer: every unmapped
// task or skill increments a durable counter with a last-seen timestamp,
// so whoever owns SKILL_SHIFT_MAP/RECONCILIATION_MAP has a real backlog to
// work from instead of having to go hunting through logs.

function recordUnmappedTask(store, roleTaskId) {
  const path = `/reconciliationBacklog/tasks/${roleTaskId}`;
  const existing = store.get(path) || { roleTaskId, timesSeen: 0, firstSeenAt: new Date().toISOString() };
  store.set(path, {
    ...existing,
    timesSeen: existing.timesSeen + 1,
    lastSeenAt: new Date().toISOString(),
  });
}

function recordUnmappedSkill(store, needSkillId) {
  const path = `/reconciliationBacklog/skills/${needSkillId}`;
  const existing = store.get(path) || { needSkillId, timesSeen: 0, firstSeenAt: new Date().toISOString() };
  store.set(path, {
    ...existing,
    timesSeen: existing.timesSeen + 1,
    lastSeenAt: new Date().toISOString(),
  });
}

function getCoverageBacklog(store) {
  const tasks = Object.values(store.get('/reconciliationBacklog/tasks') || {});
  const skills = Object.values(store.get('/reconciliationBacklog/skills') || {});
  return {
    unmappedTasks: tasks.sort((a, b) => b.timesSeen - a.timesSeen),
    unmappedSkills: skills.sort((a, b) => b.timesSeen - a.timesSeen),
  };
}

module.exports = { recordUnmappedTask, recordUnmappedSkill, getCoverageBacklog };
