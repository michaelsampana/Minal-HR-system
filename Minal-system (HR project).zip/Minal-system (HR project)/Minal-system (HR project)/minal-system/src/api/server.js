// API layer wrapping the SSIE pipeline (src/ssie/index.js). This is
// infrastructure around the already-built Tier 1 pipeline logic — it does
// not reimplement any stage; every route is a thin wrapper.
//
// Run: node src/api/server.js  (or `npm start`)
// UI served at http://localhost:3000/

const express = require('express');
const path = require('path');
const { JSONStore } = require('../db/store');
const ssie = require('../ssie/index');
const { markUserAsExistingBackfill } = require('../ssie/stage5_routing');
const employer = require('../employer/index');
const adminConfig = require('../config/adminConfig');

const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, '..', '..', 'data', 'app_db.json');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', '..', 'public')));

const store = new JSONStore(DB_PATH);

function asyncRoute(fn) {
  return (req, res) => {
    Promise.resolve(fn(req, res)).catch((err) => {
      console.error(err);
      res.status(500).json({ error: err.message });
    });
  };
}

// ---------------------------------------------------------------------------
// Users / onboarding
// ---------------------------------------------------------------------------

app.get('/api/users', (req, res) => {
  const users = store.get('/users') || {};
  res.json(Object.keys(users));
});

app.post(
  '/api/users/:userId/baseline',
  asyncRoute((req, res) => {
    const { userId } = req.params;
    const baseline = ssie.captureBaseline(store, userId, req.body || {});
    res.json({ userId, baseline });
  })
);

app.get('/api/users/:userId', (req, res) => {
  const { userId } = req.params;
  res.json({
    baseline: ssie.getBaseline(store, userId),
    skillClaims: store.get(`/users/${userId}/skillClaims`) || {},
    softSkillProfile: store.get(`/users/${userId}/softSkillProfile`) || {},
    trustRecord: store.get(`/trustRecords/${userId}`) || null,
    observationCount: ssie.getAllObservationsForUser(store, userId).length,
    consent: store.get(`/users/${userId}/consent`) || {},
  });
});

app.post('/api/users/:userId/consent', (req, res) => {
  const { userId } = req.params;
  const consent = store.update(`/users/${userId}/consent`, req.body || {});
  res.json({ userId, consent });
});

app.post('/api/users/:userId/backfill', (req, res) => {
  const { userId } = req.params;
  const legacyValue = req.body?.legacyValue ?? 0;
  markUserAsExistingBackfill(store, userId, legacyValue);
  res.json({ userId, markedAsExisting: true, legacyValue });
});

// ---------------------------------------------------------------------------
// Evidence intake — the main pipeline entry point (Stages 1-5)
// ---------------------------------------------------------------------------

app.post(
  '/api/events',
  asyncRoute(async (req, res) => {
    const event = req.body;
    if (!event?.userId || !event?.sourceChannel || !event?.skillIds) {
      return res.status(400).json({ error: 'userId, sourceChannel, and skillIds are required' });
    }
    const result = await ssie.processEngagementEvent(store, event);
    res.json(result);
  })
);

// ---------------------------------------------------------------------------
// Scheduled-in-production stages, triggerable on demand here
// ---------------------------------------------------------------------------

app.post('/api/admin/quest-selector', (req, res) => {
  const userIds = req.body?.userIds || Object.keys(store.get('/users') || {});
  const invitations = ssie.ssieAdaptiveQuestSelector(store, userIds);
  res.json({ invitations });
});

app.post(
  '/api/admin/decay',
  asyncRoute(async (req, res) => {
    const userIds = req.body?.userIds || Object.keys(store.get('/users') || {});
    const summary = await ssie.ssieDecayAndRecompute(store, ssie.recomputeSkillProfile, userIds);
    res.json({ summary });
  })
);

// ---------------------------------------------------------------------------
// Debug / inspection
// ---------------------------------------------------------------------------

app.get('/api/debug/raw', (req, res) => {
  res.json(store.data);
});

app.post('/api/debug/reset', (req, res) => {
  store.data = {};
  store._save();
  res.json({ reset: true });
});

// ---------------------------------------------------------------------------
// One-click sample walkthrough — same scripted sequence as scripts/runDemo.js,
// exposed so the UI has something to show on first load without hand-filling
// every form.
// ---------------------------------------------------------------------------

app.post(
  '/api/demo/seed',
  asyncRoute(async (req, res) => {
    const ts = (daysAgo) => new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000).toISOString();

    ssie.captureBaseline(store, 'demo_alice', {
      keystrokes: Array.from({ length: 200 }, (_, i) => ({ ts_ms: i * 300, char: 'x' })),
      textEdits: [{ insertions: 400, deletions: 40 }],
      responseTimes: [4000, 5200, 4800, 6000, 5100],
      selfRatedSkills: [
        { skillId: 'communication', rating: 80 },
        { skillId: 'critical_thinking', rating: 60 },
      ],
    });
    store.set('/users/demo_alice/consent', { dispute: true });

    const events = [
      {
        sourceChannel: 'workLog', userId: 'demo_alice', skillIds: ['communication'], engagementId: 'demo_eng_1',
        text: 'The client seemed confused about the timeline, so I checked in and clarified the deliverable dates before they escalated it.',
        observedAt: ts(30),
      },
      {
        sourceChannel: 'deliverableCycle', userId: 'demo_alice', skillIds: ['communication'], engagementId: 'demo_eng_2',
        deliverableId: 'demo_del_1', verdict: 'rejected', observedAtMs: Date.now() - 25 * 86400000, observedAt: ts(25),
      },
      {
        sourceChannel: 'deliverableCycle', userId: 'demo_alice', skillIds: ['communication'], engagementId: 'demo_eng_2',
        deliverableId: 'demo_del_1', verdict: 'resubmitted',
        resubmissionNotes: 'Reworked the summary based on your feedback and clarified the ambiguous section — retested against the original brief.',
        observedAtMs: Date.now() - 23 * 86400000, observedAt: ts(23),
      },
      {
        sourceChannel: 'dispute', userId: 'demo_alice', skillIds: ['communication'], engagementId: 'demo_eng_3',
        text: 'I understand the frustration — let me walk through what happened and how we can fix it going forward.', observedAt: ts(18),
      },
      {
        sourceChannel: 'endorsement', userId: 'demo_alice', skillIds: ['communication'], endorserTrustWeight: 0.78, observedAt: ts(10),
      },
      {
        sourceChannel: 'quest', userId: 'demo_alice', skillIds: ['communication'],
        text: 'I noticed the teammate was stuck, asked what they had tried already, and suggested checking the auth logs next — turned out to be a stale token.',
        observedAt: ts(5),
      },
      {
        sourceChannel: 'peerReview', userId: 'demo_alice', skillIds: ['communication'],
        reviewerRatings: { sense: 0.7, act: 0.75 }, observedAt: ts(2),
      },
    ];

    const results = [];
    for (const event of events) {
      results.push(await ssie.processEngagementEvent(store, event));
    }

    // demo_bob: deliberately thin evidence, to show the unreportable path
    ssie.captureBaseline(store, 'demo_bob', {
      keystrokes: Array.from({ length: 120 }, (_, i) => ({ ts_ms: i * 500, char: 'x' })),
      textEdits: [{ insertions: 300, deletions: 150 }],
      responseTimes: [9000, 11000, 8500],
      selfRatedSkills: [{ skillId: 'communication', rating: 85 }],
    });
    store.set('/users/demo_bob/consent', { dispute: false });
    await ssie.processEngagementEvent(store, {
      sourceChannel: 'workLog', userId: 'demo_bob', skillIds: ['communication'], engagementId: 'demo_eng_101',
      text: 'Replied to the client email.', observedAt: ts(3),
    });

    res.json({ seeded: true, users: ['demo_alice', 'demo_bob'], eventResults: results });
  })
);

// ---------------------------------------------------------------------------
// Employer side — Stages 1-4 + reconciliation
// ---------------------------------------------------------------------------

app.get('/api/employers', (req, res) => {
  const employers = store.get('/employers') || {};
  res.json(Object.keys(employers));
});

app.post(
  '/api/employers/:employerId/intake',
  asyncRoute((req, res) => {
    const { employerId } = req.params;
    const { autoProfile, roleTasks } = req.body || {};
    const result = employer.employerIntake(store, employerId, autoProfile || {}, roleTasks || []);
    res.json({ employerId, ...result });
  })
);

app.post(
  '/api/employers/:employerId/interview',
  asyncRoute((req, res) => {
    const { employerId } = req.params;
    const responses = employer.submitInterviewResponses(store, employerId, req.body || {});
    res.json({ employerId, responses });
  })
);

app.post(
  '/api/employers/:employerId/score',
  asyncRoute((req, res) => {
    const { employerId } = req.params;
    const result = employer.scoreAndBuildProfile(store, employerId);
    res.json({ employerId, ...result });
  })
);

app.get('/api/employers/:employerId', (req, res) => {
  const { employerId } = req.params;
  res.json({
    autoProfile: store.get(`/employers/${employerId}/autoProfile`),
    roleTasks: store.get(`/employers/${employerId}/roleTasks`) || [],
    pendingInterview: store.get(`/employers/${employerId}/pendingInterview`) || [],
    interviewResponses: store.get(`/employers/${employerId}/interviewResponses`),
    scoring: store.get(`/employers/${employerId}/scoring`),
    futureNeedProfile: store.get(`/employers/${employerId}/futureNeedProfile`),
  });
});

app.post(
  '/api/employers/:employerId/rank',
  asyncRoute((req, res) => {
    const { employerId } = req.params;
    const candidatePool = req.body?.candidateIds || Object.keys(store.get('/users') || {});
    const ranked = employer.rankCandidatesForEmployer(store, employerId, candidatePool);
    res.json({ employerId, ranked });
  })
);

app.post(
  '/api/employers/demo/load-fixtures',
  asyncRoute((req, res) => {
    const fs = require('fs');
    const path = require('path');
    const demoDir = path.join(__dirname, '..', '..', 'demo_data');
    const employersDemo = JSON.parse(fs.readFileSync(path.join(demoDir, 'employers_demo.json'), 'utf8'));
    const candidatesDemo = JSON.parse(fs.readFileSync(path.join(demoDir, 'candidates_demo.json'), 'utf8'));

    const loadedCandidateIds = [];
    for (const c of candidatesDemo.slice(0, 15)) {
      for (const [skillId, output] of Object.entries(c.skillProfile)) {
        store.set(`/users/${c.candidateId}/softSkillProfile/${skillId}`, output);
        const verified = output.score >= 70 && output.confidence >= 60;
        store.set(`/users/${c.candidateId}/skillClaims/${skillId}`, { skillId, skillType: 'soft', verificationState: verified ? 'verified' : 'unverified' });
      }
      loadedCandidateIds.push(c.candidateId);
    }

    const loadedEmployerIds = [];
    for (const e of employersDemo.slice(0, 5)) {
      employer.employerIntake(store, e.employerId, e.autoProfile, e.roleTasks);
      employer.submitInterviewResponses(store, e.employerId, e.interviewResponses);
      employer.scoreAndBuildProfile(store, e.employerId);
      loadedEmployerIds.push(e.employerId);
    }

    res.json({ loadedEmployerIds, loadedCandidateIds });
  })
);

app.get('/api/employers/debug/reconciliation-map', (req, res) => {
  const { RECONCILIATION_MAP } = require('../employer/reconciliation');
  res.json(RECONCILIATION_MAP);
});

// ---------------------------------------------------------------------------
// Admin config — live-editable tunable constants (Integration Contract §5/§6)
// ---------------------------------------------------------------------------

app.get('/api/config', (req, res) => {
  res.json({ tunables: adminConfig.listTunables(store), changeLog: adminConfig.getChangeLog(store) });
});

app.post(
  '/api/config/:key',
  asyncRoute((req, res) => {
    const { key } = req.params;
    const { value } = req.body || {};
    const result = adminConfig.setTunable(store, key, value);
    res.json(result);
  })
);

app.post(
  '/api/config/:key/reset',
  asyncRoute((req, res) => {
    const { key } = req.params;
    const result = adminConfig.resetTunable(store, key);
    res.json(result);
  })
);

// ---------------------------------------------------------------------------
// Outcome feedback loop (Tier 2 scaffold — logging only, see feedback.js)
// ---------------------------------------------------------------------------

app.post(
  '/api/employers/:employerId/feedback/skill-shift',
  asyncRoute((req, res) => {
    const { employerId } = req.params;
    const entry = employer.recordSkillShiftOutcome(store, employerId, req.body || {});
    res.json(entry);
  })
);

app.post(
  '/api/employers/:employerId/candidates/:candidateId/feedback/match',
  asyncRoute((req, res) => {
    const { employerId, candidateId } = req.params;
    const entry = employer.recordMatchOutcome(store, employerId, candidateId, req.body || {});
    res.json(entry);
  })
);

app.get('/api/employers/:employerId/feedback', (req, res) => {
  const { employerId } = req.params;
  res.json({
    skillShiftOutcomes: employer.getSkillShiftOutcomes(store, employerId),
    summary: employer.summarizeFeedback(store, employerId),
  });
});

app.get('/api/employers/debug/coverage-backlog', (req, res) => {
  res.json(employer.getCoverageBacklog(store));
});

app.get('/api/admin/weight-fitting-report', (req, res) => {
  res.json(employer.runWeightFittingDiagnostic(store));
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', dbPath: DB_PATH });
});

app.listen(PORT, () => {
  console.log(`MINAL SSIE API + UI running at http://localhost:${PORT}`);
  console.log(`DB file: ${DB_PATH}`);
});
