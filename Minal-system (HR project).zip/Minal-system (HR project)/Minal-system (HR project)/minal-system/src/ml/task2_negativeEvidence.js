// ML Task 2 — Negative Evidence Detection
// SSIE_ML_Engine_Build_Spec_v1.md §3. Tier 1: real LLM-as-classifier code.
//
// Precision > recall by design (§3.6): a false blame-shifting accusation
// damages a real person's Accountability score; a missed one just means
// slightly less signal. The mock fallback below is deliberately conservative
// for the same reason — it should under-flag, not over-flag.

const { scoreWithFallback } = require('./llmAdapter');

const RUBRIC_PROMPT = (text, sourceChannel) => `You are detecting negative-evidence patterns in workplace text. Return JSON only:
{"labels": {"blameShifting": <bool>, "feedbackIgnored": <bool>, "interruption": <bool>, "toneDegradation": <bool>},
 "modelConfidence": {"<label>": <0-1>, ...only for labels you set true}}

Definitions:
blameShifting: denies responsibility, attributes fault externally without owning any part of it.
feedbackIgnored: prior feedback/instruction is contradicted or dismissed rather than addressed.
interruption: cuts off or disregards another party's input mid-exchange.
toneDegradation: hostile, dismissive, or sharply escalating tone versus a neutral baseline.

Bias toward precision: only mark true when clearly evidenced. Ambiguous cases should be false.

TEXT: ${text}
CONTEXT: source=${sourceChannel}`;

const NEGATIVE_KEYWORDS = {
  blameShifting: ['not my fault', "wasn't my", 'because the client', 'because they', 'if they had', 'garbage spec', 'blame'],
  feedbackIgnored: ['already told', 'as i said before', 'ignored my', 'again, i said'],
  interruption: ['let me finish', 'cut me off', 'before i could'],
  toneDegradation: ['ridiculous', 'unacceptable', 'this is absurd', 'frankly', 'unbelievable'],
};

/**
 * Deterministic, precision-biased mock classifier — used only when no
 * provider key is configured. Requires an explicit keyword hit per label;
 * defaults to false (never guesses true), consistent with the precision
 * priority the real model is evaluated against.
 */
function mockNegativeEvidenceClassifier({ text = '' }) {
  const t = text.toLowerCase();
  const labels = {};
  const modelConfidence = {};
  for (const [label, keywords] of Object.entries(NEGATIVE_KEYWORDS)) {
    const hit = keywords.some((k) => t.includes(k));
    labels[label] = hit;
    if (hit) modelConfidence[label] = 0.6;
  }
  return { labels, modelConfidence };
}

/**
 * @param {{text: string, sourceChannel: string}} input
 * @returns {Promise<{labels: object, modelConfidence: object, modelVersion: string, providerUsed: string}>}
 */
async function detectNegativeEvidence(input) {
  const { text, sourceChannel } = input;
  const prompt = RUBRIC_PROMPT(text, sourceChannel);

  const result = await scoreWithFallback(prompt, {
    mockFn: () => mockNegativeEvidenceClassifier(input),
  });

  let parsed;
  try {
    parsed = JSON.parse(result.text);
  } catch {
    parsed = mockNegativeEvidenceClassifier(input);
  }

  return {
    labels: parsed.labels || { blameShifting: false, feedbackIgnored: false, interruption: false, toneDegradation: false },
    modelConfidence: parsed.modelConfidence || {},
    modelVersion: result.modelVersion,
    providerUsed: result.providerUsed,
  };
}

module.exports = { detectNegativeEvidence, RUBRIC_PROMPT, mockNegativeEvidenceClassifier };
