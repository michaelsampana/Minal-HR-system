// ML Task 3 — Constraint Level Inference
// SSIE_ML_Engine_Build_Spec_v1.md §4. Per §4.3 and §8.5: "Task 3 stays
// rule-based indefinitely unless evaluation says otherwise." This is Tier 1
// real code — it is deliberately NOT an ML model. Do not add an ML path here
// without an evaluation showing the rule-based baseline underperforms.

/**
 * @param {{sourceChannel: string, eventSequence?: string[], timeToDeadlineHours?: number, verdict?: string}} input
 * @returns {{constraintLevel: 0|1|2|3, confidence: number}}
 */
function inferConstraintLevel(input) {
  const { sourceChannel, eventSequence = [], timeToDeadlineHours, verdict } = input;

  // Structural defaults per Integration Contract §3 "Constraint tagging defaults":
  // workLog = 0-1, deliverableCycle = 1-2 (2 if rejected), dispute = 3, quest = per template.
  if (sourceChannel === 'dispute') {
    return { constraintLevel: 3, confidence: 0.95 }; // dispute is automatically level 3 (§4.3)
  }

  if (sourceChannel === 'deliverableCycle') {
    const rejectedTwice =
      eventSequence.filter((e) => e === 'rejected' || e === 'deliverable_rejected').length >= 2;
    if (rejectedTwice) return { constraintLevel: 3, confidence: 0.8 }; // second rejection escalates
    if (verdict === 'rejected') return { constraintLevel: 2, confidence: 0.85 };
    return { constraintLevel: 1, confidence: 0.7 };
  }

  if (sourceChannel === 'workLog') {
    if (typeof timeToDeadlineHours === 'number' && timeToDeadlineHours <= 24) {
      return { constraintLevel: 1, confidence: 0.75 }; // time pressure
    }
    return { constraintLevel: 0, confidence: 0.6 };
  }

  if (sourceChannel === 'quest') {
    return { constraintLevel: input.questConstraintLevel ?? 0, confidence: 0.5 }; // per-template, caller-supplied
  }

  // endorsement, peerReview, profileBuilder — no inherent constraint signal
  return { constraintLevel: 0, confidence: 0.5 };
}

module.exports = { inferConstraintLevel };
