// ssie_llm_adapter.js — per SSIE_ML_Engine_Build_Spec_v1.md Appendix A.
//
// This is the "single point of change if a provider changes/removes a model"
// adapter the spec requires be built from day one, not as a later refactor.
// It is REAL, working code — not a placeholder — per the handoff brief's
// Tier 1 classification of the LLM-as-scorer endpoints.
//
// Per the build-package Q&A: no provider API key is configured in this
// environment yet, so every real provider call will fail with NO_KEY and
// the adapter falls through to an explicit mock mode. The mock path is
// clearly labeled (providerUsed: 'mock', modelVersion: 'mock-v0') so it can
// never be confused with a real model result downstream — this satisfies
// the non-negotiable modelVersion/providerUsed audit requirement (ML spec §7.4)
// even in mock mode.
//
// To go live: set GEMINI_API_KEY and/or GROQ_API_KEY and/or OPENROUTER_API_KEY
// as environment variables. No other code changes needed.

const PROVIDERS = {
  gemini: {
    model: 'gemini-2.5-flash',
    keyEnv: 'GEMINI_API_KEY',
    endpoint: (model) =>
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
    buildRequest(prompt, key) {
      return {
        url: `${this.endpoint(this.model)}?key=${key}`,
        init: {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: { responseMimeType: 'application/json' },
          }),
        },
        extractText: (json) => json?.candidates?.[0]?.content?.parts?.[0]?.text,
      };
    },
  },
  groq: {
    model: 'llama-3.3-70b-versatile',
    keyEnv: 'GROQ_API_KEY',
    buildRequest(prompt, key) {
      return {
        url: 'https://api.groq.com/openai/v1/chat/completions',
        init: {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${key}`,
          },
          body: JSON.stringify({
            model: this.model,
            messages: [{ role: 'user', content: prompt }],
            response_format: { type: 'json_object' },
          }),
        },
        extractText: (json) => json?.choices?.[0]?.message?.content,
      };
    },
  },
  openrouter: {
    model: 'deepseek/deepseek-r1:free',
    keyEnv: 'OPENROUTER_API_KEY',
    buildRequest(prompt, key) {
      return {
        url: 'https://openrouter.ai/api/v1/chat/completions',
        init: {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${key}`,
          },
          body: JSON.stringify({
            model: this.model,
            messages: [{ role: 'user', content: prompt }],
          }),
        },
        extractText: (json) => json?.choices?.[0]?.message?.content,
      };
    },
  },
};

class NoKeyError extends Error {}
class ProviderCallError extends Error {}
class AllProvidersExhaustedError extends Error {}

async function callProvider(name, prompt) {
  const cfg = PROVIDERS[name];
  const key = process.env[cfg.keyEnv];
  if (!key) throw new NoKeyError(`No API key set for ${name} (${cfg.keyEnv})`);

  const { url, init, extractText } = cfg.buildRequest(prompt, key);
  let res;
  try {
    res = await fetch(url, init);
  } catch (err) {
    throw new ProviderCallError(`${name} network error: ${err.message}`);
  }
  if (!res.ok) {
    throw new ProviderCallError(`${name} returned HTTP ${res.status}`);
  }
  const json = await res.json();
  const text = extractText(json);
  if (!text) throw new ProviderCallError(`${name} returned no text content`);

  return { text, modelVersion: cfg.model, providerUsed: name };
}

/**
 * Try each provider in order; fall through to a deterministic mock generator
 * if every real provider is unavailable (no key configured, rate-limited, etc).
 *
 * @param {string} prompt
 * @param {object} opts
 * @param {string[]} [opts.providersOrder]
 * @param {() => object} [opts.mockFn] - returns a plain JS object matching the
 *   expected parsed output shape. Required in this environment since no keys
 *   are configured; callers must supply a rubric-appropriate mock.
 * @param {(name: string, err: Error) => void} [opts.onFailover] - logging hook
 */
async function scoreWithFallback(prompt, opts = {}) {
  const {
    providersOrder = ['gemini', 'groq', 'openrouter'],
    mockFn = null,
    onFailover = null,
  } = opts;

  for (const name of providersOrder) {
    try {
      return await callProvider(name, prompt);
    } catch (err) {
      if (onFailover) onFailover(name, err);
      continue;
    }
  }

  if (mockFn) {
    const mockObj = mockFn();
    return {
      text: JSON.stringify(mockObj),
      modelVersion: 'mock-v0',
      providerUsed: 'mock',
    };
  }

  throw new AllProvidersExhaustedError(
    'All providers exhausted and no mockFn supplied — see Appendix A of the ML build spec.'
  );
}

module.exports = {
  PROVIDERS,
  scoreWithFallback,
  NoKeyError,
  ProviderCallError,
  AllProvidersExhaustedError,
};
