// ML Task 4 — Confidence Calibration (learned)
// SSIE_ML_Engine_Build_Spec_v1.md §5. Explicitly Tier 2 per the handoff
// brief: "logs data only until longitudinal data exists." This module does
// NOT compute or return a calibrated confidence value — the deterministic
// heuristic formula in Stage 3 (computeConfidence) remains authoritative.
//
// This module's only job is to persist the feature snapshot (§5.3 schema) so
// that once two-point-in-time data exists for a user+skill, a real model can
// be trained without having thrown away the training signal in the meantime.
// Do not add a predictive path here without longitudinal ground truth.

/**
 * Log one calibration-training-data row. Call this whenever a skill score is
 * (re)computed — logging is free, training is not, per §5.3: "Log the raw
 * features now even if you don't train on them for 6+ months."
 *
 * @param {import('../db/store').JSONStore} store
 * @param {{userId: string, skillId: string, scoreAtT1: number, confidenceAtT1: number, observationCountAtT1: number}} snapshot
 */
function logCalibrationSnapshot(store, snapshot) {
  const path = `/_mlTrainingLogs/confidenceCalibration/${snapshot.userId}__${snapshot.skillId}`;
  store.appendToArrayField(path, 'entries', {
    ...snapshot,
    loggedAt: new Date().toISOString(),
    // groundTruthSignal / scoreAtT2 / monthsElapsed get filled in later,
    // out-of-band, once a second observation point exists (§5.3) — not here.
  });
}

module.exports = { logCalibrationSnapshot };
