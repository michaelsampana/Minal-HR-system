// ML Task 1 — Primitive Scoring from Text
// SSIE_ML_Engine_Build_Spec_v1.md §2. Tier 1 per handoff brief: real,
// working LLM-as-scorer code, not a placeholder — even though it currently
// runs in mock mode for lack of a configured provider key.

const { scoreWithFallback } = require('./llmAdapter');

// §2.7 bootstrap rubric prompt, verbatim structure from the spec.
const RUBRIC_PROMPT = (text, sourceChannel, priorEventInSequence) => `You are scoring workplace text for five behavioral primitives, each 0.0-1.0,
or null if not evidenced in this text:

SENSE: Did the person notice a relevant signal (a problem, a person's
reaction, a system state) before acting?
INTERPRET: Did they form a reasoned explanation/hypothesis, not just react?
DECIDE: Did they weigh options or prioritize under a tradeoff?
ACT: Quality of the execution or communication itself — clarity, care.
ADJUST: Did they change course based on new information or feedback?

Score conservatively. Absence of evidence = null, not 0. A text can score
high on some primitives and null on others. Return JSON only, matching:
{"primitiveVector": {"sense": <0-1 or null>, "interpret": <0-1 or null>, "decide": <0-1 or null>, "act": <0-1 or null>, "adjust": <0-1 or null>}}

TEXT: ${text}
CONTEXT: source=${sourceChannel}, prior_event=${priorEventInSequence ?? 'null'}`;

/**
 * Deterministic mock scorer — used ONLY when no LLM provider key is configured.
 * This is a crude keyword heuristic, explicitly NOT a trained model and NOT a
 * substitute for the rubric-following LLM call. It exists so the pipeline is
 * runnable end-to-end before any provider key is added, per the Tier-2 rule:
 * scaffold, don't fabricate calibration. Do not tune this to "look smarter" —
 * doing so would misrepresent it as more than a wiring placeholder.
 */
function mockPrimitiveScorer({ text = '', sourceChannel }) {
  const t = text.toLowerCase();
  const has = (words) => words.some((w) => t.includes(w));

  const sense = has(['noticed', 'checked', 'saw that', 'realized', 'flagged']) ? 0.6 : null;
  const interpret = has(['because', 'turned out', 'root cause', 'hypothesis', 'likely due to']) ? 0.6 : null;
  const decide = has(['decided', 'chose', 'prioritized', 'instead of', 'weighed']) ? 0.6 : null;
  const act = t.length > 40 ? 0.55 : null;
  const adjust = has(['retested', 'fixed', 'changed', 'updated', 'revised', 'resubmit']) ? 0.6 : null;

  return { primitiveVector: { sense, interpret, decide, act, adjust } };
}

/**
 * @param {{text: string, sourceChannel: string, engagementContext?: object, authorBaselineFluency?: number}} input
 * @returns {Promise<{primitiveVector: object, modelVersion: string, providerUsed: string}>}
 */
async function scorePrimitivesFromText(input) {
  const { text, sourceChannel, engagementContext = {} } = input;
  const prompt = RUBRIC_PROMPT(text, sourceChannel, engagementContext.priorEventInSequence);

  const result = await scoreWithFallback(prompt, {
    mockFn: () => mockPrimitiveScorer(input),
  });

  let parsed;
  try {
    parsed = JSON.parse(result.text);
  } catch {
    parsed = mockPrimitiveScorer(input); // malformed provider output — fail safe to mock shape
  }

  return {
    primitiveVector: parsed.primitiveVector || { sense: null, interpret: null, decide: null, act: null, adjust: null },
    modelVersion: result.modelVersion,
    providerUsed: result.providerUsed,
  };
}

module.exports = { scorePrimitivesFromText, RUBRIC_PROMPT, mockPrimitiveScorer };
