// STAGE 2 — Primitive Extraction & Signing
// SSIE_MINAL_Merged_Algorithm_v1.md, Stage 2.

/** Fatigue/state discount — dampens tired-session signal. Reasoned starting curve, not calibrated. */
function fatigueDiscount(sessionState = {}) {
  const { localHour = 12, sessionMinutes = 0 } = sessionState;
  let discount = 1.0;
  if (localHour < 6 || localHour >= 23) discount -= 0.15; // late-night / very-early sessions
  if (sessionMinutes > 120) discount -= 0.1; // long unbroken sessions
  return Math.max(0.5, discount);
}

/**
 * @param {object} obs - mutated in place and returned
 * @param {object} baseline - from Stage 0 (getBaseline)
 */
function normalizeAgainstBaseline(obs, baseline) {
  if (obs.rawLatency != null && baseline.medianResponseLatency != null) {
    const std = baseline.medianResponseLatencyStdDev || 1;
    obs.latencyZScore = (obs.rawLatency - baseline.medianResponseLatency) / std;
  }
  if (obs.rawLinguisticScore != null && baseline.fluencyIndex) {
    obs.fluencyAdjusted = obs.rawLinguisticScore / baseline.fluencyIndex;
  }
  obs.sessionDiscount = fatigueDiscount(obs.sessionState);
  return obs;
}

const BLAME_MARKERS = ['not my fault', "wasn't my", 'because they', 'because the client'];
const IGNORED_FEEDBACK_MARKERS = ['already told', 'as i said before', 'ignored my'];
const INTERRUPTION_MARKERS = ['let me finish', 'cut me off', 'before i could'];
const TONE_MARKERS = ['ridiculous', 'unacceptable', 'this is absurd', 'unbelievable'];

function detectBlameShifting(obs) {
  return (obs.tags || []).includes('blameShifting') || textHasAny(obs, BLAME_MARKERS);
}
function detectFeedbackIgnored(obs) {
  return (obs.tags || []).includes('feedbackIgnored') || textHasAny(obs, IGNORED_FEEDBACK_MARKERS);
}
function detectInterruption(obs) {
  return (obs.tags || []).includes('interruption') || textHasAny(obs, INTERRUPTION_MARKERS);
}
function detectToneDegradation(obs) {
  return (obs.tags || []).includes('toneDegradation') || textHasAny(obs, TONE_MARKERS);
}
function textHasAny(obs, markers) {
  const t = (obs._rawText || '').toLowerCase();
  return t && markers.some((m) => t.includes(m));
}

/**
 * Negative evidence detection — applies across ALL channels. In this build,
 * ML Task 2 already ran inside Stage 1's extractors and set obs.polarity/tags
 * where text was available; this function is the structural fallback pass
 * described in the pseudocode, re-checked here so signObservation is safe to
 * call standalone (e.g. from Stage 7 recompute) without re-running the LLM.
 */
function signObservation(obs) {
  if (detectBlameShifting(obs) || detectFeedbackIgnored(obs) || detectInterruption(obs) || detectToneDegradation(obs)) {
    obs.polarity = -1;
  } else if (obs.polarity == null) {
    obs.polarity = 1;
  }
  return obs;
}

module.exports = { normalizeAgainstBaseline, signObservation, fatigueDiscount };
