// STAGE 5 — Score Routing into MINAL Trust Engine
// SSIE_MINAL_Merged_Algorithm_v1.md, Stage 5.
//
// IMPORTANT SCOPE NOTE: legacyReliabilityComponent, legacyAccountabilityComponent,
// and existingCompositeFormula are MINAL's pre-existing hard-skill Trust
// Engine functions — they are referenced by this spec but defined nowhere in
// the SSIE/MINAL documents handed off for this build (they predate SSIE).
// This module stubs them with a neutral, clearly-flagged default (50/100)
// rather than fabricating a formula for a system this build package doesn't
// specify. See FLAGS.md item #2. Swap these stubs for real calls into
// MINAL's existing Trust Engine when integrating for real.

const CONSTANTS = require('../config/constants');
const { resolveSSIEConfig } = require('../config/adminConfig');
const { reconcileClaim } = require('./stage4_verification');
const { logCalibrationSnapshot } = require('../ml/task4_confidenceCalibration');

function legacyReliabilityComponent(_store, _userId) {
  return 50; // FLAGGED STUB — see module header
}
function legacyAccountabilityComponent(_store, _userId) {
  return 50; // FLAGGED STUB — see module header
}
function existingCompositeFormula(record) {
  // Reasoned placeholder composite: average of the three pillars, since the
  // real MINAL composite formula isn't part of this build package.
  const { credibilityScoreAvg = 50, reliabilityScore = 50, accountabilityScore = 50 } = record;
  return (credibilityScoreAvg + reliabilityScore + accountabilityScore) / 3; // FLAGGED STUB
}

/**
 * Blend ramp (score-shock control) — Constants reference: BLEND_RAMP_DAYS = 60.
 *
 * Integration Contract §7 is explicit this applies to EXISTING users being
 * backfilled onto SSIE ("Existing users' credibility transitions via blend
 * ramp β to prevent score shock"), not to users onboarding fresh — a brand
 * new user has no legacy soft-skill credibility to protect, so ramping them
 * from a synthetic zero baseline would just wrongly suppress their real
 * first score (caught by running the demo — see FLAGS.md item #5).
 *
 * A user is treated as "existing" only if explicitly marked via
 * markUserAsExistingBackfill() below (i.e. the migration/backfill job ran
 * for them). Everyone else gets their computed value immediately.
 *
 * The spec also doesn't give the blend formula itself, only the ramp
 * duration — the linear interpolation from a 0 legacy baseline is a
 * reasoned placeholder. TUNABLE / FLAGGED — see FLAGS.md item #3.
 */
function markUserAsExistingBackfill(store, userId, legacySoftSkillCredibility = 0) {
  store.set(`/users/${userId}/_ssieBackfill`, {
    isExistingUser: true,
    legacyValue: legacySoftSkillCredibility,
    backfillStartedAt: new Date().toISOString(),
  });
}

function applyBlendRamp(store, userId, rawValue) {
  const backfill = store.get(`/users/${userId}/_ssieBackfill`);
  if (!backfill || !backfill.isExistingUser) {
    return rawValue; // fresh onboard — no ramp, no shock to protect against
  }
  const cfg = resolveSSIEConfig(store);
  const daysSince = (Date.now() - new Date(backfill.backfillStartedAt).getTime()) / (1000 * 60 * 60 * 24);
  const beta = Math.min(1, daysSince / cfg.BLEND_RAMP_DAYS);
  return backfill.legacyValue * (1 - beta) + rawValue * beta;
}

function allClaimCredibilities(store, userId) {
  const claims = store.get(`/users/${userId}/skillClaims`) || {};
  return Object.values(claims)
    .map((c) => c.credibilityScore)
    .filter((v) => typeof v === 'number');
}

function average(nums) {
  if (!nums.length) return 0;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

function totalObservationsForSkill(store, userId, skillId) {
  const col = store.get(`/users/${userId}/ssieObservations`) || {};
  return Object.values(col).filter((o) => o.skillIds.includes(skillId)).length;
}

function mapGapToModifier(avgGap, calibrationBound) {
  // Small, bounded, monotonic mapping: larger |gap| -> more negative modifier.
  // avgGap is already |selfReportGap|; scale so a 0 gap -> +0.05 (small
  // calibration reward) and a 50+ point gap -> -0.05 (discount floor).
  const normalized = clamp(-1, 1, 0.05 - (avgGap / 50) * 0.1);
  return clamp(-calibrationBound, calibrationBound, normalized);
}

function clamp(min, max, v) {
  return Math.max(min, Math.min(max, v));
}

/**
 * @param {import('../db/store').JSONStore} store
 * @param {string} userId
 * @param {string} skillId
 * @param {object} output - SSIESkillOutput from Stage 3
 */
function routeToTrustScores(store, userId, skillId, output) {
  const cfg = resolveSSIEConfig(store);
  reconcileClaim(store, userId, skillId, output);
  const claim = store.get(`/users/${userId}/skillClaims/${skillId}`);

  // --- 5.1 Credibility ---
  const w = cfg.CREDIBILITY_WEIGHTS_SOFT;
  let credibility;
  if ((claim.skillType || 'soft') === 'soft') {
    const questScore = claim.questScore ?? 0; // no quest telemetry wired yet in this build
    const portfolioScore = claim.portfolioScore ?? 0;
    credibility =
      w.w_q * questScore + w.w_p * portfolioScore + w.w_s * ((output.score * output.confidence) / 100);
    // NOTE: endorsementScore deliberately EXCLUDED — SSIE's endorsement
    // channel already consumes EigenTrust-weighted endorsements as primitive
    // evidence. Including it here would double-count peer signals (Integration
    // Contract §4.1 dedupe rule — "highest-priority merge defect to guard").
  } else {
    // hard skill — legacy formula, untouched. Weights not specified in this
    // package (pre-existing MINAL constants) — flagged stub inputs.
    const w_a = 0.4,
      w_e = 0.3,
      w_p_hard = 0.3;
    credibility =
      w_a * (claim.assessmentScore ?? 50) + w_e * (claim.endorsementScore ?? 50) + w_p_hard * (claim.portfolioScore ?? 50);
  }

  claim.credibilityScore = applyBlendRamp(store, userId, credibility);
  store.set(`/users/${userId}/skillClaims/${skillId}`, claim);

  // --- 5.2 Reliability delta ---
  const { r_1, r_2 } = cfg.RELIABILITY_DELTAS;
  const normRecovery = output.stability.recoveryTime == null ? 0.5 : output.stability.recoveryTime;
  const reliabilityDelta = r_1 * output.stability.consistency + r_2 * (1 - normRecovery);

  // --- 5.3 Accountability delta ---
  const { a_1, a_2 } = cfg.ACCOUNTABILITY_DELTAS;
  const totalObs = totalObservationsForSkill(store, userId, skillId) || 1;
  const accountabilityDelta =
    a_1 * output.stability.initiativeRatio - a_2 * (output.negativeEvidenceCount / totalObs);

  // Log calibration training data (ML Task 4 — Tier 2, logging only).
  logCalibrationSnapshot(store, {
    userId,
    skillId,
    scoreAtT1: output.score,
    confidenceAtT1: output.confidence,
    observationCountAtT1: totalObs,
  });

  recomputeTrustRecord(store, userId, reliabilityDelta, accountabilityDelta);
  return claim;
}

function recomputeTrustRecord(store, userId, reliabilityDelta, accountabilityDelta) {
  const cfg = resolveSSIEConfig(store);
  const recordPath = `/trustRecords/${userId}`;
  const record = store.get(recordPath) || { scoreBreakdown: {}, eventLog: [] };

  record.credibilityScoreAvg = average(allClaimCredibilities(store, userId));
  record.reliabilityScore = legacyReliabilityComponent(store, userId) + (record._reliabilityDeltaSum = (record._reliabilityDeltaSum || 0) + reliabilityDelta);
  record.accountabilityScore =
    legacyAccountabilityComponent(store, userId) + (record._accountabilityDeltaSum = (record._accountabilityDeltaSum || 0) + accountabilityDelta);

  const allOutputs = getAllSkillOutputsForGapCalc(store, userId);
  const avgGap = average(allOutputs.map((o) => Math.abs(o.selfReportGap ?? 0)));
  const calibrationModifier = mapGapToModifier(avgGap, cfg.CALIBRATION_BOUND);

  record.reputationScore = existingCompositeFormula(record) * (1 + calibrationModifier);

  record.scoreBreakdown.softSkillCredibility = record.credibilityScoreAvg;
  record.scoreBreakdown.calibrationModifier = calibrationModifier;
  record.scoreBreakdown.ssieConsistency = average(allOutputs.map((o) => o.stability?.consistency ?? 0));
  record.scoreBreakdown.ssieNegativeCount = allOutputs.reduce((sum, o) => sum + (o.negativeEvidenceCount || 0), 0);
  record.lastComputedAt = new Date().toISOString();

  store.appendToArrayField(recordPath, 'eventLog', { type: 'ssie_recompute', at: record.lastComputedAt }, CONSTANTS.MAX_EVENT_LOG_ENTRIES);
  store.set(recordPath, record);
  return record;
}

function getAllSkillOutputsForGapCalc(store, userId) {
  const profiles = store.get(`/users/${userId}/softSkillProfile`) || {};
  return Object.values(profiles);
}

module.exports = { routeToTrustScores, recomputeTrustRecord, applyBlendRamp, markUserAsExistingBackfill };
