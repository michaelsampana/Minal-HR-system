// STAGE 7 — Recency Decay & Maintenance (scheduled, weekly)
// SSIE_MINAL_Merged_Algorithm_v1.md, Stage 7.

const CONSTANTS = require('../config/constants');
const { pruneExpired } = require('./observations');

/**
 * @param {import('../db/store').JSONStore} store
 * @param {(store, userId, skillIds) => Promise<void>} recomputeSkillProfileFn - Stage 3-5 orchestrator, injected to avoid a circular require
 * @param {string[]} userIds - "allUsersWithSoftSkillProfiles()" — caller supplies the set
 */
async function ssieDecayAndRecompute(store, recomputeSkillProfileFn, userIds) {
  const summary = [];
  for (const userId of userIds) {
    const pruned = pruneExpired(store, userId, CONSTANTS.MAX_OBSERVATION_AGE_DAYS);
    const claims = store.get(`/users/${userId}/skillClaims`) || {};
    const softSkillIds = Object.values(claims)
      .filter((c) => (c.skillType || 'soft') === 'soft')
      .map((c) => c.skillId);

    for (const skillId of softSkillIds) {
      await recomputeSkillProfileFn(store, userId, [skillId]);
    }
    summary.push({ userId, prunedObservations: pruned, recomputedSkills: softSkillIds.length });
  }
  return summary;
}

module.exports = { ssieDecayAndRecompute };
