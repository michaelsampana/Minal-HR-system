// STAGE 0 — Baseline Calibration (runs once, at onboarding)
// SSIE_MINAL_Merged_Algorithm_v1.md, Stage 0.

function median(nums) {
  if (!nums || nums.length === 0) return null;
  const sorted = [...nums].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function stdDev(nums) {
  if (!nums || nums.length < 2) return 1; // avoid divide-by-zero downstream; 1 = no normalization effect
  const m = nums.reduce((a, b) => a + b, 0) / nums.length;
  const variance = nums.reduce((a, b) => a + (b - m) ** 2, 0) / nums.length;
  return Math.sqrt(variance) || 1;
}

/** Words-per-minute from a simple keystroke timeline: [{ts_ms, char}]. */
function measureTypingSpeed(keystrokes = []) {
  if (keystrokes.length < 2) return 40; // neutral default WPM
  const durationMinutes = (keystrokes[keystrokes.length - 1].ts_ms - keystrokes[0].ts_ms) / 60000;
  const words = keystrokes.length / 5; // standard "5 chars = 1 word" approximation
  return durationMinutes > 0 ? Math.round(words / durationMinutes) : 40;
}

/** Fluency index from text-edit events: [{insertions, deletions}]. Lower churn = higher fluency. */
function measureFluencyIndex(textEdits = []) {
  if (textEdits.length === 0) return 1.0; // neutral baseline — no penalty/boost
  const totalChurn = textEdits.reduce((sum, e) => sum + (e.deletions || 0), 0);
  const totalWritten = textEdits.reduce((sum, e) => sum + (e.insertions || 0), 0) || 1;
  const churnRatio = totalChurn / totalWritten;
  return Math.max(0.3, 1 - churnRatio); // more deletion-churn -> lower fluency, floored
}

function inferActiveWindow(profileSession = {}) {
  return profileSession.activeHours || []; // caller-supplied or unknown; not fabricated
}

/**
 * @param {import('../db/store').JSONStore} store
 * @param {string} userId
 * @param {{keystrokes?: object[], textEdits?: object[], responseTimes?: number[], activeHours?: number[], selfRatedSkills?: {skillId: string, skillType?: string, rating: number}[]}} profileSession
 */
function captureBaseline(store, userId, profileSession = {}) {
  const baseline = {
    typingSpeedWpm: measureTypingSpeed(profileSession.keystrokes),
    fluencyIndex: measureFluencyIndex(profileSession.textEdits),
    medianResponseLatency: median(profileSession.responseTimes) ?? 5000,
    medianResponseLatencyStdDev: stdDev(profileSession.responseTimes),
    activeHours: inferActiveWindow(profileSession),
    capturedAt: new Date().toISOString(),
  };
  store.set(`/users/${userId}/ssieBaseline`, baseline);

  // Self-assessment capture — feeds calibration later, never feeds score directly.
  for (const claim of profileSession.selfRatedSkills || []) {
    store.update(`/users/${userId}/skillClaims/${claim.skillId}`, {
      skillId: claim.skillId,
      skillType: claim.skillType || 'soft',
      selfAssessedLevel: claim.rating,
    });
  }

  return baseline;
}

function getBaseline(store, userId) {
  return (
    store.get(`/users/${userId}/ssieBaseline`) || {
      typingSpeedWpm: 40,
      fluencyIndex: 1.0,
      medianResponseLatency: 5000,
      medianResponseLatencyStdDev: 1,
      activeHours: [],
      capturedAt: null,
    }
  );
}

module.exports = { captureBaseline, getBaseline, median, stdDev };
