// STAGE 1 — Evidence Intake (event-triggered, per MINAL lifecycle event)
// SSIE_MINAL_Merged_Algorithm_v1.md, Stage 1.
//
// In the real system these are Cloud Functions triggers (Integration
// Contract §5). Here they're plain functions called directly by the demo
// runner / a future API layer — the trigger wiring is infrastructure, not
// pipeline logic, and is explicitly out of scope for this local build.

const crypto = require('crypto');
const { scorePrimitivesFromText } = require('../ml/task1_primitiveScoring');
const { detectNegativeEvidence } = require('../ml/task2_negativeEvidence');
const { inferConstraintLevel } = require('../ml/task3_constraintLevel');

function newObsShell(event) {
  return {
    obsId: `obs_${crypto.randomUUID()}`,
    userId: event.userId,
    skillIds: event.skillIds || [],
    primitiveVector: { sense: null, interpret: null, decide: null, act: null, adjust: null },
    polarity: 1,
    modifiers: {
      constraintLevel: 0,
      target: event.target || 'self',
      contextTag: event.contextTag || event.sourceChannel,
    },
    sourceChannel: event.sourceChannel,
    engagementId: event.engagementId || null,
    evidenceRef: event.evidenceRef || `inline:${event.sourceChannel}:${event.userId}`,
    observedAt: event.observedAt || new Date().toISOString(),
    sessionState: null, // filled by normalizeAgainstBaseline caller
    stability: {}, // recoveryTime lands here for deliverableCycle observations
    tags: [],
    // Non-negotiable per ML spec §7.4: every ML-produced observation carries
    // modelVersion/providerUsed. Populated below wherever ML Tasks 1-2 ran.
    modelVersion: null,
    providerUsed: null,
  };
}

async function extractWorkLogObservation(event) {
  const obs = newObsShell(event);
  const ml = await scorePrimitivesFromText({
    text: event.text || '',
    sourceChannel: 'workLog',
    engagementContext: { engagementType: event.engagementType, priorEventInSequence: event.priorEventInSequence },
    authorBaselineFluency: event.authorBaselineFluency,
  });
  obs.primitiveVector = ml.primitiveVector;
  obs.modelVersion = ml.modelVersion;
  obs.providerUsed = ml.providerUsed;

  const neg = await detectNegativeEvidence({ text: event.text || '', sourceChannel: 'workLog' });
  if (Object.values(neg.labels).some(Boolean)) {
    obs.polarity = -1;
    obs.tags.push('negativeEvidence', ...Object.entries(neg.labels).filter(([, v]) => v).map(([k]) => k));
  }

  const constraint = inferConstraintLevel({
    sourceChannel: 'workLog',
    timeToDeadlineHours: event.timeToDeadlineHours,
  });
  obs.modifiers.constraintLevel = constraint.constraintLevel;
  return obs;
}

// Module-level recovery-clock store keyed by "engagementId::deliverableId".
// In production this would live in Firestore (per-doc timestamp); kept as an
// in-memory map here since it's short-lived (reject -> resubmit) bookkeeping,
// not evidence itself.
const _recoveryClocks = new Map();

function startRecoveryClock(engagementId, deliverableId, startedAt) {
  _recoveryClocks.set(`${engagementId}::${deliverableId}`, startedAt || Date.now());
}

function stopRecoveryClock(engagementId, deliverableId, endedAt) {
  const key = `${engagementId}::${deliverableId}`;
  const started = _recoveryClocks.get(key);
  _recoveryClocks.delete(key);
  if (!started) return null;
  return (endedAt || Date.now()) - started;
}

function containsBlameLanguageSync(text = '') {
  // Fast structural pre-check ahead of the full ML Task 2 call — mirrors the
  // pseudocode's containsBlameLanguage() stub, now filled per ML spec §7.3
  // ("this ML service is what fills those stubs").
  const t = text.toLowerCase();
  return ['not my fault', 'blame', "wasn't my", 'because they'].some((k) => t.includes(k));
}

async function extractDeliverableObservation(event) {
  const obs = newObsShell(event);

  if (event.verdict === 'rejected') {
    obs.primitiveVector.adjust = null; // pending — recovery clock starts
    startRecoveryClock(event.engagementId, event.deliverableId, event.observedAtMs);
  }

  if (event.verdict === 'resubmitted') {
    const elapsedMs = stopRecoveryClock(event.engagementId, event.deliverableId, event.observedAtMs);
    // normalize elapsed ms to 0-1 against a 7-day outer bound — reasoned
    // placeholder, not derived from real recovery-time distributions yet.
    const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;
    obs.stability.recoveryTime = elapsedMs == null ? null : Math.min(1, elapsedMs / SEVEN_DAYS_MS);

    const ml = await scorePrimitivesFromText({
      text: event.resubmissionNotes || '',
      sourceChannel: 'deliverableCycle',
      engagementContext: { priorEventInSequence: 'deliverable_rejected' },
    });
    obs.primitiveVector = { ...obs.primitiveVector, adjust: ml.primitiveVector.adjust };
    obs.modelVersion = ml.modelVersion;
    obs.providerUsed = ml.providerUsed;

    if (containsBlameLanguageSync(event.resubmissionNotes || '')) {
      obs.polarity = -1;
      obs.tags.push('negativeEvidence');
    } else {
      const neg = await detectNegativeEvidence({ text: event.resubmissionNotes || '', sourceChannel: 'deliverableCycle' });
      if (Object.values(neg.labels).some(Boolean)) {
        obs.polarity = -1;
        obs.tags.push('negativeEvidence');
      }
    }
  }

  const constraint = inferConstraintLevel({
    sourceChannel: 'deliverableCycle',
    verdict: event.verdict,
    eventSequence: event.eventSequence || [],
  });
  obs.modifiers.constraintLevel = event.verdict === 'rejected' ? 2 : constraint.constraintLevel;
  return obs;
}

async function extractDisputeObservation(event) {
  const obs = newObsShell(event);
  const ml = await scorePrimitivesFromText({
    text: event.text || '',
    sourceChannel: 'dispute',
    engagementContext: { priorEventInSequence: event.priorEventInSequence },
  });
  obs.primitiveVector = ml.primitiveVector;
  obs.modelVersion = ml.modelVersion;
  obs.providerUsed = ml.providerUsed;

  const neg = await detectNegativeEvidence({ text: event.text || '', sourceChannel: 'dispute' });
  if (Object.values(neg.labels).some(Boolean)) {
    obs.polarity = -1;
    obs.tags.push('negativeEvidence', ...Object.entries(neg.labels).filter(([, v]) => v).map(([k]) => k));
  }
  obs.modifiers.constraintLevel = 3; // dispute is automatically level 3
  obs.modifiers.target = event.target || 'person';
  return obs;
}

function extractEndorsementObservation(event) {
  // Reuses MINAL's existing EigenTrust-weighted endorsement mechanism
  // (Integration Contract §3: "existing mechanism reused"). That mechanism
  // lives in MINAL's core Trust Engine, outside SSIE's scope — this function
  // takes the already-computed trust weight as input rather than
  // re-implementing EigenTrust here. See FLAGS.md.
  const obs = newObsShell(event);
  const weight = typeof event.endorserTrustWeight === 'number' ? event.endorserTrustWeight : 0.5;
  obs.primitiveVector = {
    sense: null,
    interpret: null,
    decide: null,
    act: weight, // peer-observed execution quality, weighted by endorser credibility
    adjust: null,
  };
  obs.modifiers.target = 'person';
  obs.tags.push('endorsement');
  return obs;
}

async function extractQuestObservation(event) {
  const obs = newObsShell(event);
  if (event.text) {
    const ml = await scorePrimitivesFromText({
      text: event.text,
      sourceChannel: 'quest',
      engagementContext: { engagementType: event.questTemplateId },
    });
    obs.primitiveVector = ml.primitiveVector;
    obs.modelVersion = ml.modelVersion;
    obs.providerUsed = ml.providerUsed;
  } else if (event.templateScores) {
    // Non-text quest (e.g. a structured decision-tree quest) — template
    // supplies primitive scores directly.
    obs.primitiveVector = { ...obs.primitiveVector, ...event.templateScores };
  }
  const constraint = inferConstraintLevel({ sourceChannel: 'quest', questConstraintLevel: event.questConstraintLevel ?? 0 });
  obs.modifiers.constraintLevel = constraint.constraintLevel;
  obs.tags.push('quest');
  return obs;
}

function extractPeerReviewObservation(event) {
  const obs = newObsShell(event);
  obs.primitiveVector = {
    sense: event.reviewerRatings?.sense ?? null,
    interpret: null,
    decide: null,
    act: event.reviewerRatings?.act ?? null,
    adjust: null,
  };
  obs.modifiers.target = 'group';
  obs.tags.push('peerReview');
  return obs;
}

function userConsent(store, userId, channel) {
  const consent = store.get(`/users/${userId}/consent`) || {};
  // dispute channel strictly opt-in (Integration Contract §8) — default false
  // for dispute, default true for everything else (passive evidence channels
  // that don't carry the same linguistic-analysis sensitivity).
  if (channel === 'dispute') return consent.dispute === true;
  return consent[channel] !== false;
}

function getSessionState(event) {
  return event.sessionState || { localHour: new Date().getHours(), sessionMinutes: 0 };
}

/**
 * Derives a stable per-sub-event idempotency key. The Integration Contract
 * (§2.2) places `ssieProcessedAt` on the /engagements/{id} doc, but a single
 * engagement fires many distinct lifecycle sub-events over its life (a
 * workLog entry, then later a deliverable rejection, then its resubmission).
 * Guarding on engagementId alone would silently drop every sub-event after
 * the first one on the same engagement — including legitimate resubmit
 * events immediately after a reject on the SAME engagementId, which is a
 * real failure mode this build caught by running the demo (see FLAGS.md
 * item #4). This keys the guard on the specific trigger instead, while
 * keeping the field name/spirit ("ssieProcessedAt") the contract specifies.
 */
function deriveEventKey(event) {
  if (event.eventId) return event.eventId;
  return [event.engagementId || 'noeng', event.sourceChannel, event.verdict || '', event.deliverableId || '', event.observedAt || '']
    .join('::');
}

/**
 * Main Stage 1 entry point.
 * @param {import('../db/store').JSONStore} store
 * @param {object} event - see extractor functions above for shape per sourceChannel
 * @returns {Promise<{skipped: true, reason: string} | {obs: object, skillIds: string[]}>}
 */
async function onEngagementEvent(store, event) {
  const eventKey = deriveEventKey(event);
  const guardPath = `/engagementEvents/${eventKey}`;
  const guard = store.get(guardPath) || {};
  if (guard.ssieProcessedAt) return { skipped: true, reason: 'idempotency guard (ssieProcessedAt exists)' };

  let obs;
  switch (event.sourceChannel) {
    case 'workLog':
      obs = await extractWorkLogObservation(event);
      break;
    case 'deliverableCycle':
      obs = await extractDeliverableObservation(event);
      break;
    case 'dispute':
      if (!userConsent(store, event.userId, 'dispute')) {
        return { skipped: true, reason: 'no dispute-channel consent' };
      }
      obs = await extractDisputeObservation(event);
      break;
    case 'endorsement':
      obs = extractEndorsementObservation(event);
      break;
    case 'quest':
      obs = await extractQuestObservation(event);
      break;
    case 'peerReview':
      obs = extractPeerReviewObservation(event);
      break;
    default:
      throw new Error(`onEngagementEvent: unknown sourceChannel "${event.sourceChannel}"`);
  }

  obs.sessionState = getSessionState(event);

  store.update(guardPath, { ssieProcessedAt: new Date().toISOString() });
  if (event.engagementId) {
    // Also mirror onto the engagement doc as a coarse "has any SSIE activity"
    // marker, matching the contract's documented field location — but this
    // is informational only and is NOT what the guard above checks.
    store.update(`/engagements/${event.engagementId}`, { ssieLastProcessedAt: new Date().toISOString() });
  }

  return { obs, skillIds: obs.skillIds };
}

module.exports = {
  onEngagementEvent,
  userConsent,
  // exported for testing / Stage 2 reuse
  extractWorkLogObservation,
  extractDeliverableObservation,
  extractDisputeObservation,
  extractEndorsementObservation,
  extractQuestObservation,
  extractPeerReviewObservation,
};
