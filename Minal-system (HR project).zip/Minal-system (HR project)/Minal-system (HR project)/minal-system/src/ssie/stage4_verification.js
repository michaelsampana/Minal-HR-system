// STAGE 4 — Verification State & Claim Reconciliation
// SSIE_MINAL_Merged_Algorithm_v1.md, Stage 4.

const CONSTANTS = require('../config/constants');
const { resolveSSIEConfig } = require('../config/adminConfig');

/**
 * @param {import('../db/store').JSONStore} store
 * @param {string} userId
 * @param {string} skillId
 * @param {object} output - SSIESkillOutput from Stage 3
 */
function reconcileClaim(store, userId, skillId, output) {
  const cfg = resolveSSIEConfig(store);
  const claimPath = `/users/${userId}/skillClaims/${skillId}`;
  const claim = store.get(claimPath) || { skillId, skillType: 'soft' };

  if (output.score >= cfg.T_VERIFY && output.confidence >= cfg.T_CONF) {
    claim.verificationState = 'verified';
    claim.verifiedLevel = output.score;
    claim.publiclyDisplayed = true; // badge
  } else if (
    claim.selfAssessedLevel >= cfg.HIGH_CLAIM &&
    output.score < cfg.T_GAP &&
    output.confidence >= cfg.T_CONF
  ) {
    claim.verificationState = 'gapFlagged';
    claim.publiclyDisplayed = false; // PRIVATE nudge only — never visible to employers
    claim.gapFlagNotice = {
      notifiedAt: new Date().toISOString(),
      suggestedFocusPrimitive: weakestPrimitive(output.primitiveVector),
    };
  } else {
    claim.verificationState = 'unverified'; // default, zero-shame, matching-neutral
    claim.publiclyDisplayed = false;
  }

  store.set(claimPath, claim);
  return claim;
}

function weakestPrimitive(primitiveVector = {}) {
  let weakest = null;
  let weakestVal = Infinity;
  for (const [p, v] of Object.entries(primitiveVector)) {
    if (v == null) continue;
    if (v < weakestVal) {
      weakestVal = v;
      weakest = p;
    }
  }
  return weakest;
}

module.exports = { reconcileClaim, weakestPrimitive };
