// STAGE 6 — Adaptive Quest Selection (scheduled, weekly)
// SSIE_MINAL_Merged_Algorithm_v1.md, Stage 6.
//
// This is the deterministic heuristic ALREADY specified in the merged
// algorithm (argmin over primitiveVector) — distinct from ML Task 5
// (contextual bandit), which the ML build spec explicitly defers until
// Tasks 1-2 are live with real confidence scores as a reward signal. Do not
// conflate the two: this module is Tier 1 (build now); the bandit is
// out of scope for this build pass.

const CONSTANTS = require('../config/constants');
const { weakestPrimitive } = require('./stage4_verification');

/**
 * A minimal quest template selector — round-robin over a fixed pool, filtered
 * to templates targeting the weakest primitive, excluding recently-served
 * templates. Real template content/pool is a product/content decision
 * outside this build's scope; templates here are placeholders identified by
 * targetPrimitive only.
 */
function selectQuestTemplate({ targetPrimitive, excludeRecent = [] }) {
  const pool = ['sense', 'interpret', 'decide', 'act', 'adjust']
    .filter((p) => p === targetPrimitive)
    .map((p) => `quest_template_${p}_v1`)
    .filter((id) => !excludeRecent.includes(id));
  return pool[0] || `quest_template_${targetPrimitive}_v1`; // fall back even if "recently used"
}

/**
 * @param {import('../db/store').JSONStore} store
 * @param {string[]} userIds - "activeUsers()" in the spec; caller supplies the active set
 * @returns {{userId: string, skillId: string, quest: string}[]} enqueued invitations
 */
function ssieAdaptiveQuestSelector(store, userIds) {
  const invitations = [];
  for (const userId of userIds) {
    const claims = store.get(`/users/${userId}/skillClaims`) || {};
    const softSkillIds = Object.values(claims)
      .filter((c) => (c.skillType || 'soft') === 'soft')
      .map((c) => c.skillId);

    for (const skillId of softSkillIds) {
      const output = store.get(`/users/${userId}/softSkillProfile/${skillId}`);
      if (!output) continue;
      if (output.confidence >= CONSTANTS.T_CONF) continue;

      const target = weakestPrimitive(output.primitiveVector || {});
      if (!target) continue;

      const recent = store.get(`/users/${userId}/recentQuestIds`) || [];
      const quest = selectQuestTemplate({ targetPrimitive: target, excludeRecent: recent });

      invitations.push({ userId, skillId, quest, framing: 'badge_progress' });
      store.appendToArrayField(`/users/${userId}`, 'recentQuestIds', quest, 10);
    }
  }
  return invitations;
}

module.exports = { ssieAdaptiveQuestSelector, selectQuestTemplate };
