// STAGE 3 — Skill Scoring (per skill, triggered by recomputeSkillProfile)
// SSIE_MINAL_Merged_Algorithm_v1.md, Stage 3.

const CONSTANTS = require('../config/constants');
const { resolveSSIEConfig } = require('../config/adminConfig');
const { getObservations, ageDays } = require('./observations');

const PRIMITIVES = ['sense', 'interpret', 'decide', 'act', 'adjust'];

function decayWeight(obs) {
  return Math.exp(-Math.LN2 * ageDays(obs) / CONSTANTS.RECENCY_HALF_LIFE_DAYS);
}

function weightedAverage(values) {
  if (values.length === 0) return null;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

function clamp(min, max, v) {
  if (v == null || Number.isNaN(v)) return min;
  return Math.max(min, Math.min(max, v));
}

function channelDiversity(observations) {
  return new Set(observations.map((o) => o.sourceChannel)).size;
}

function distinctTags(observations) {
  const tags = new Set();
  for (const o of observations) {
    if (o.modifiers?.contextTag) tags.add(o.modifiers.contextTag);
    for (const t of o.tags || []) tags.add(t);
  }
  return [...tags];
}

function computeConfidence(observations) {
  const volume = Math.min(1.0, observations.length / 15);
  const channelDiv = channelDiversity(observations) / CONSTANTS.TOTAL_CHANNELS;
  const contextDiv = new Set(observations.map((o) => o.modifiers?.contextTag).filter(Boolean)).size / CONSTANTS.TOTAL_CONTEXTS;
  const recency = weightedAverage(observations.map((o) => decayWeight(o))) ?? 0;
  return clamp(0, 100, (0.3 * volume + 0.3 * channelDiv + 0.2 * contextDiv + 0.2 * recency) * 100);
}

function normalizedVariance(values) {
  if (values.length < 2) return 0;
  const m = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((a, b) => a + (b - m) ** 2, 0) / values.length;
  return Math.min(1, variance); // primitives are already 0-1, so raw variance is already bounded-ish
}

function computeStability(observations) {
  // consistency: 1 - normalized variance across all present primitive values
  const allPrimitiveValues = [];
  for (const o of observations) {
    for (const p of PRIMITIVES) {
      if (o.primitiveVector[p] != null) allPrimitiveValues.push(o.primitiveVector[p]);
    }
  }
  const consistency = 1 - normalizedVariance(allPrimitiveValues);

  // degradationSlope: crude linear regression of quality (mean primitive value)
  // against constraintLevel — quality change per constraint level.
  const points = observations
    .map((o) => {
      const vals = PRIMITIVES.map((p) => o.primitiveVector[p]).filter((v) => v != null);
      if (vals.length === 0) return null;
      return { x: o.modifiers.constraintLevel, y: vals.reduce((a, b) => a + b, 0) / vals.length };
    })
    .filter(Boolean);
  const degradationSlope = regressSlope(points);

  const recoveryTimes = observations.map((o) => o.stability?.recoveryTime).filter((v) => v != null);
  const recoveryTime = recoveryTimes.length ? weightedAverage(recoveryTimes) : null;

  const transferCount = new Set(observations.map((o) => o.modifiers?.contextTag).filter(Boolean)).size;

  const positives = observations.filter((o) => o.polarity === 1);
  const unpromptedPositives = positives.filter((o) => o.tags?.includes('unprompted') || o.modifiers?.contextTag !== 'quest');
  const initiativeRatio = positives.length ? unpromptedPositives.length / positives.length : 0;

  return { consistency, degradationSlope, recoveryTime, transferCount, initiativeRatio };
}

function regressSlope(points) {
  if (points.length < 2) return 0;
  const n = points.length;
  const sumX = points.reduce((a, p) => a + p.x, 0);
  const sumY = points.reduce((a, p) => a + p.y, 0);
  const sumXY = points.reduce((a, p) => a + p.x * p.y, 0);
  const sumXX = points.reduce((a, p) => a + p.x * p.x, 0);
  const denom = n * sumXX - sumX * sumX;
  if (denom === 0) return 0;
  return (n * sumXY - sumX * sumY) / denom;
}

/**
 * @param {import('../db/store').JSONStore} store
 * @param {string} userId
 * @param {string} skillId
 * @returns {{status: 'reportable', output: object} | {status: 'unreportable', reason: string}}
 */
function scoreSkill(store, userId, skillId) {
  const cfg = resolveSSIEConfig(store);
  const observations = getObservations(store, userId, skillId, { withinHalfLifeDays: CONSTANTS.RECENCY_HALF_LIFE_DAYS });

  if (observations.length < cfg.MIN_OBSERVATIONS || channelDiversity(observations) < cfg.MIN_CHANNEL_DIVERSITY) {
    return {
      status: 'unreportable',
      reason: `need >=${cfg.MIN_OBSERVATIONS} observations across >=${cfg.MIN_CHANNEL_DIVERSITY} channels; have ${observations.length} across ${channelDiversity(observations)}`,
    };
  }

  const skillWeights = CONSTANTS.SKILL_WEIGHTS_DEFAULT; // TUNABLE — equal-weighted default, see FLAGS.md
  const weightedPrimitives = {};
  for (const p of PRIMITIVES) {
    const values = [];
    for (const obs of observations) {
      if (obs.primitiveVector[p] == null) continue;
      const decayW = decayWeight(obs);
      const constraintM = CONSTANTS.CONSTRAINT_MULT[obs.modifiers.constraintLevel] ?? 1.0;
      const signedVal = obs.polarity * obs.primitiveVector[p] * (obs.sessionDiscount ?? 1.0);
      values.push(signedVal * decayW * constraintM);
    }
    weightedPrimitives[p] = weightedAverage(values);
  }

  const weightSum = PRIMITIVES.reduce((sum, p) => sum + (weightedPrimitives[p] != null ? skillWeights[p] : 0), 0);
  const numerator = PRIMITIVES.reduce(
    (sum, p) => sum + (weightedPrimitives[p] != null ? skillWeights[p] * weightedPrimitives[p] : 0),
    0
  );
  const score = weightSum > 0 ? clamp(0, 100, (numerator / weightSum) * 100) : 0;

  const confidence = computeConfidence(observations);
  const stability = computeStability(observations);
  const negativeEvidenceCount = observations.filter((o) => o.polarity === -1).length;

  const selfAssessed = store.get(`/users/${userId}/skillClaims/${skillId}`)?.selfAssessedLevel;

  const output = {
    skillName: skillId,
    score,
    confidence,
    contextTags: distinctTags(observations),
    evidenceTrail: observations.map((o) => o.obsId),
    selfReportGap: selfAssessed != null ? selfAssessed - score : null,
    stability,
    negativeEvidenceCount,
    lastComputedAt: new Date().toISOString(),
    // Intentional, contract-compliant EXTENSION of SSIESkillOutput (Integration
    // Contract §1: "these shapes may only be extended, never broken"). The
    // Merged Algorithm's Stage 6 (adaptive quest selection) reads
    // output.primitiveVector to find the weakest-confidence primitive, but
    // §1.2's frozen SSIESkillOutput shape doesn't include it — a genuine gap
    // between the two spec documents. See FLAGS.md item #1.
    primitiveVector: weightedPrimitives,
  };

  return { status: 'reportable', output };
}

module.exports = { scoreSkill, computeConfidence, computeStability, PRIMITIVES };
