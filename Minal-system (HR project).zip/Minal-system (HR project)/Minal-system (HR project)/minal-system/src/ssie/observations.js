// Shared observation storage helpers. Integration Contract §2.1: observations
// live at /users/{userId}/ssieObservations/{obsId} as "aggregated observation
// rollups (NOT raw telemetry)". §8: cap like the existing 50-event eventLog[]
// pattern, with monthly archival rollups.

const CONSTANTS = require('../config/constants');

function appendObservation(store, userId, obs) {
  const path = `/users/${userId}/ssieObservations`;
  const col = store.get(path) || {};
  col[obs.obsId] = obs;

  const ids = Object.keys(col);
  if (ids.length > CONSTANTS.MAX_OBSERVATIONS_PER_USER) {
    // archive-then-drop oldest beyond cap, by observedAt
    const sorted = ids
      .map((id) => ({ id, observedAt: col[id].observedAt }))
      .sort((a, b) => new Date(a.observedAt) - new Date(b.observedAt));
    const overflow = sorted.slice(0, ids.length - CONSTANTS.MAX_OBSERVATIONS_PER_USER);
    for (const { id } of overflow) {
      // "monthly archival rollups" — full archival pipeline is out of scope
      // for this local build; we drop from the live rollup and note it was
      // archived rather than silently losing count.
      delete col[id];
    }
  }

  store.set(path, col);
  return obs;
}

function ageDays(obs, now = Date.now()) {
  return (now - new Date(obs.observedAt).getTime()) / (1000 * 60 * 60 * 24);
}

/**
 * @param {import('../db/store').JSONStore} store
 * @param {string} userId
 * @param {string} skillId
 * @param {{withinHalfLifeDays?: number}} opts
 */
function getObservations(store, userId, skillId, opts = {}) {
  const withinDays = opts.withinHalfLifeDays ?? CONSTANTS.RECENCY_HALF_LIFE_DAYS;
  const col = store.get(`/users/${userId}/ssieObservations`) || {};
  return Object.values(col).filter(
    (o) => o.skillIds.includes(skillId) && ageDays(o) <= withinDays
  );
}

function getAllObservationsForUser(store, userId) {
  return Object.values(store.get(`/users/${userId}/ssieObservations`) || {});
}

function pruneExpired(store, userId, maxAgeDays = CONSTANTS.MAX_OBSERVATION_AGE_DAYS) {
  const path = `/users/${userId}/ssieObservations`;
  const col = store.get(path) || {};
  let prunedCount = 0;
  for (const [id, obs] of Object.entries(col)) {
    if (ageDays(obs) > maxAgeDays) {
      delete col[id];
      prunedCount++;
    }
  }
  store.set(path, col);
  return prunedCount;
}

module.exports = { appendObservation, getObservations, getAllObservationsForUser, pruneExpired, ageDays };
