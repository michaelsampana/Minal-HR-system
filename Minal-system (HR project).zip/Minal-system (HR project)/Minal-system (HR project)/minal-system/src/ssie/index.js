// SSIE pipeline orchestrator. Wires Stages 0-7 in the call order specified
// in SSIE_MINAL_Merged_Algorithm_v1.md's "End-to-end call order" section.
//
// In production these seams are Cloud Functions triggers (Integration
// Contract §5); here they're plain async function calls. Whoever adds the
// API/trigger layer next should call these functions, not reimplement stage
// logic at the trigger boundary.

const { captureBaseline, getBaseline } = require('./stage0_baseline');
const { onEngagementEvent } = require('./stage1_intake');
const { normalizeAgainstBaseline, signObservation } = require('./stage2_normalize');
const { appendObservation, getAllObservationsForUser } = require('./observations');
const { scoreSkill } = require('./stage3_skillScoring');
const { routeToTrustScores } = require('./stage5_routing');
const { ssieAdaptiveQuestSelector } = require('./stage6_questSelector');
const { ssieDecayAndRecompute } = require('./stage7_decay');

/**
 * Stage 3-5: recompute and route one or more skills for a user.
 * @param {import('../db/store').JSONStore} store
 * @param {string} userId
 * @param {string[]} skillIds
 */
async function recomputeSkillProfile(store, userId, skillIds) {
  const results = [];
  for (const skillId of skillIds) {
    const result = scoreSkill(store, userId, skillId);
    if (result.status === 'unreportable') {
      store.update(`/users/${userId}/skillClaims/${skillId}`, {
        skillId,
        verificationState: store.get(`/users/${userId}/skillClaims/${skillId}`)?.verificationState || 'unverified',
        _unreportableReason: result.reason,
      });
      results.push({ skillId, status: 'unreportable', reason: result.reason });
      continue;
    }
    store.set(`/users/${userId}/softSkillProfile/${skillId}`, result.output);
    routeToTrustScores(store, userId, skillId, result.output);
    // Clear any stale unreportable-reason left over from before this skill
    // had enough evidence — otherwise a since-resolved gating message
    // lingers on the claim forever (caught by running the demo server).
    const claim = store.get(`/users/${userId}/skillClaims/${skillId}`) || {};
    if ('_unreportableReason' in claim) {
      delete claim._unreportableReason;
      store.set(`/users/${userId}/skillClaims/${skillId}`, claim);
    }
    results.push({ skillId, status: 'reportable', output: result.output });
  }
  return results;
}

/**
 * Full Stage 1 -> 2 -> append -> Stage 3-5 flow for one engagement event.
 * Mirrors the worked example in the Merged Algorithm's end-to-end call order.
 */
async function processEngagementEvent(store, event) {
  const intake = await onEngagementEvent(store, event);
  if (intake.skipped) return intake;

  const baseline = getBaseline(store, event.userId);
  normalizeAgainstBaseline(intake.obs, baseline);
  intake.obs._rawText = event.text || event.resubmissionNotes || null; // for Stage 2's structural signing pass
  signObservation(intake.obs);
  delete intake.obs._rawText; // not part of the SSIEObservation contract shape — scratch field only

  appendObservation(store, event.userId, intake.obs);

  const recompute = await recomputeSkillProfile(store, event.userId, intake.skillIds);
  return { obs: intake.obs, recompute };
}

module.exports = {
  captureBaseline,
  getBaseline,
  processEngagementEvent,
  recomputeSkillProfile,
  ssieAdaptiveQuestSelector,
  ssieDecayAndRecompute,
  getAllObservationsForUser,
};
