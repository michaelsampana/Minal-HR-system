// JSONStore — a minimal, path-addressed document store that mimics Firestore's
// collection/document addressing (e.g. "/users/{userId}/softSkillProfile/{skillId}")
// closely enough that swapping in a real Firestore client later should mean
// rewriting this module's internals, not the calling code in src/ssie/*.js.
//
// This is the Tier-1 decision made explicit in the handoff brief: build the
// real pipeline logic now; the storage backend is the thing designed to be
// swappable, not a placeholder for the logic itself.
//
// Persists to a single JSON file for inspectability between demo runs.

const fs = require('fs');
const path = require('path');

class JSONStore {
  constructor(filePath) {
    this.filePath = filePath;
    this._load();
  }

  _load() {
    if (fs.existsSync(this.filePath)) {
      try {
        this.data = JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
      } catch {
        this.data = {};
      }
    } else {
      this.data = {};
    }
  }

  _save() {
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    fs.writeFileSync(this.filePath, JSON.stringify(this.data, null, 2));
  }

  _parts(pathStr) {
    return pathStr.split('/').filter(Boolean);
  }

  /** Read a single doc/value at a Firestore-style path. Returns null if absent. */
  get(pathStr) {
    const parts = this._parts(pathStr);
    let node = this.data;
    for (const p of parts) {
      if (node == null || typeof node !== 'object') return null;
      node = node[p];
    }
    return node === undefined ? null : node;
  }

  /** Overwrite the doc at path with value (Firestore `set`). */
  set(pathStr, value) {
    const parts = this._parts(pathStr);
    let node = this.data;
    for (let i = 0; i < parts.length - 1; i++) {
      const p = parts[i];
      if (node[p] == null || typeof node[p] !== 'object') node[p] = {};
      node = node[p];
    }
    node[parts[parts.length - 1]] = value;
    this._save();
    return value;
  }

  /** Shallow-merge patch into the doc at path (Firestore `update`). */
  update(pathStr, patch) {
    const existing = this.get(pathStr);
    const merged = { ...(existing && typeof existing === 'object' ? existing : {}), ...patch };
    this.set(pathStr, merged);
    return merged;
  }

  delete(pathStr) {
    const parts = this._parts(pathStr);
    let node = this.data;
    for (let i = 0; i < parts.length - 1; i++) {
      const p = parts[i];
      if (node[p] == null) return;
      node = node[p];
    }
    delete node[parts[parts.length - 1]];
    this._save();
  }

  /** Returns the whole "collection" object at path: { docId: docValue, ... }. */
  listCollection(pathStr) {
    const node = this.get(pathStr);
    return node && typeof node === 'object' ? node : {};
  }

  /** Push a value into an array field on a doc, without needing get+set boilerplate at call sites. */
  appendToArrayField(pathStr, field, value, capLast = null) {
    const doc = this.get(pathStr) || {};
    const arr = Array.isArray(doc[field]) ? doc[field].slice() : [];
    arr.push(value);
    const capped = capLast ? arr.slice(-capLast) : arr;
    this.update(pathStr, { [field]: capped });
    return capped;
  }
}

module.exports = { JSONStore };
