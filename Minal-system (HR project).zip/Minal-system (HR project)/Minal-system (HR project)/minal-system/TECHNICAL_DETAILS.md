# MINAL — Technical Details

This is the deep-dive companion to the main `README.md`. If you just want
to understand what MINAL is and try it, the main README is enough — this
file is for anyone (technical reviewers, future contributors) who wants
the full architecture, algorithms, and build history.

## Project structure

```
minal-system/
├── README.md              — short, judge-facing overview
├── TECHNICAL_DETAILS.md    — this file
├── src/                    — all source code
├── public/                 — the browser UI (HTML/CSS/vanilla JS, no build step)
├── test/                   — 45 automated tests
├── scripts/                — CLI demo runners
├── demo/                   — how to see it run (no video yet — see demo/README.md)
├── demo_data/              — sample/dummy data (employers_demo.json, candidates_demo.json + generator)
├── assets/                 — screenshot + architecture/pipeline diagrams
├── data/                   — runtime database file, generated when you run the app
├── requirements.txt        — placeholder; this is a Node.js project, see package.json instead
├── package.json            — the real dependency manifest
├── FLAGS.md / FLAGS_EMPLOYER.md  — every known limitation and placeholder, documented honestly
└── *.docx                  — user-facing field guides (concepts + form-by-form, both sides)
```

## Pipeline diagrams

**SSIE pipeline (candidate side), Stages 0–7:**

![SSIE pipeline](assets/ssie_pipeline_diagram.png)

**Employer pipeline, Stages 1–4** — Stage 4 is where the two engines meet,
via the reconciliation map bridging SSIE's broad competencies into the
employer side's narrow, task-specific skill vocabulary:

![Employer pipeline](assets/employer_pipeline_diagram.png)

## Quick start

```bash
cd minal-system
npm install                 # installs express (the only dependency)
npm start                   # API + UI at http://localhost:3000
```

Open http://localhost:3000. Three tabs:
- **candidates (SSIE)** — click **"load sample walkthrough"** to seed a realistic candidate.
- **employers** — click **"load sample employers + candidates"** to seed 5 real employer records (from `employers_demo.json`) and 15 candidates (from `candidates_demo.json`, already in SSIE's real output shape) all the way through Stages 1-4, then pick an employer and click **"run ranking"** to see candidates ranked by fit. Each need row and ranking row has a **"record outcome"** button — the feedback-loop scaffold.
- **config** — every tunable, live-editable, grouped by system and purpose, with a change log at the bottom.

Or, without the UI:

```bash
node scripts/runDemo.js             # SSIE Stages 0-7, synthetic evidence, human-readable trace
node scripts/runEmployerDemo.js     # Employer Stages 1-4, real demo fixtures, ranked output + a sanity check against the debug labels
node --test test/*.test.js          # 39 unit tests across all three build passes
```

No API keys needed to run any of this — ML Tasks 1-2 fall through to an
explicit, clearly-labeled mock mode when no provider key is set.

## The UI

A single-page console (`public/`) served as static files by the same Express
server that exposes the API — no separate frontend build step, no framework.
Layout:

- **Left column** — forms mapped directly onto the pipeline's real inputs:
  onboard a user (Stage 0), set dispute-channel consent, submit one evidence
  event at a time (Stages 1-5, with the exact fields each channel needs), and
  trigger the two scheduled stages (quest selector, decay) on demand.
- **Right column** — live readouts: the trust record (reputation,
  credibility, reliability, accountability, calibration modifier), one card
  per skill showing score/confidence/verification badge, and a **five-bar
  gauge cluster per skill** — a direct instrument reading of the
  Sense/Interpret/Decide/Act/Adjust primitive vector that's the actual
  mechanic underneath every score. Hatched bars mean "no evidence yet for
  that primitive," not zero.
- An activity log at the bottom shows the raw request/response for every
  action, for anyone who wants to see exactly what the API is doing.

## API reference

| Method | Path | What it does |
|---|---|---|
| `GET`  | `/api/users` | list known user IDs |
| `GET`  | `/api/users/:userId` | baseline, skillClaims, softSkillProfile, trustRecord, consent |
| `POST` | `/api/users/:userId/baseline` | Stage 0 — capture baseline |
| `POST` | `/api/users/:userId/consent` | set per-channel consent (e.g. `{"dispute": true}`) |
| `POST` | `/api/users/:userId/backfill` | mark as an existing user for blend-ramp purposes (see FLAGS.md #5) |
| `POST` | `/api/events` | Stages 1-5 — submit one lifecycle event |
| `POST` | `/api/admin/quest-selector` | Stage 6, run on demand |
| `POST` | `/api/admin/decay` | Stage 7, run on demand |
| `POST` | `/api/demo/seed` | scripted sample walkthrough (what the UI button calls) |
| `POST` | `/api/debug/reset` | wipe all local data |
| `GET`  | `/api/debug/raw` | dump the entire local store as JSON |
| `GET`  | `/api/health` | liveness check |

See `src/api/server.js` for exact request/response shapes — every route is a
thin wrapper around `src/ssie/index.js`, no logic lives in the route handlers.

## What's real vs. stubbed (Tier 1 / Tier 2 / Tier 3 mapping)

### Tier 1 — real, working code
- Stage 0 baseline calibration
- Stage 1 evidence intake, all six channel extractors (workLog,
  deliverableCycle reject/resubmit pairs, dispute with consent gating,
  endorsement, quest, peerReview)
- Stage 2 baseline normalization + negative-evidence signing
- Stage 3 weighted primitive scoring, confidence, stability, evidence gating
- Stage 4 verification-state reconciliation (verified / unverified /
  gapFlagged)
- Stage 5 score routing (credibility with the endorsement-dedupe rule
  correctly applied, reliability/accountability deltas, calibration modifier,
  trust record recompute)
- Stage 6 adaptive quest selection (the deterministic heuristic specified in
  the Merged Algorithm — NOT the ML bandit, see Tier 2)
- Stage 7 recency decay & pruning
- ML Task 1 (primitive scoring) and Task 2 (negative evidence detection) as
  LLM-as-scorer/classifier endpoints, with the full provider-fallback adapter
  from ML spec Appendix A (Gemini → Groq → OpenRouter → mock)
- ML Task 3 (constraint level inference) — rule-based, per spec ("stays
  rule-based indefinitely unless evaluation says otherwise")

### Tier 2 — scaffolded, not calibrated
- ML Task 4 (confidence calibration) — logs feature snapshots
  (`_mlTrainingLogs/confidenceCalibration/...`) on every skill recompute;
  does NOT compute or return a learned confidence value. The deterministic
  heuristic formula remains authoritative until longitudinal data exists.
- ML Task 5 (adaptive quest bandit) — **not built**, per spec. Stage 6 uses
  the already-specified heuristic instead; the bandit needs live confidence
  data as a reward signal that doesn't exist yet.
- LLM adapter mock mode — the real Gemini/Groq/OpenRouter fallback chain is
  fully implemented and will activate automatically the moment
  `GEMINI_API_KEY` / `GROQ_API_KEY` / `OPENROUTER_API_KEY` is set in the
  environment. Until then, every call falls through to a deliberately crude,
  clearly-labeled (`providerUsed: 'mock'`, `modelVersion: 'mock-v0'`)
  keyword heuristic — not a real scorer, and not tuned to look like one.

### Tier 3 — flagged, not silently decided
See `FLAGS.md` for the full list with reasoning. Headline items:
1. `SSIESkillOutput.primitiveVector` isn't in the frozen §1.2 contract shape
   but Stage 6 needs it — resolved via the contract's own extension
   allowance, flagged for confirmation.
2. MINAL's pre-existing legacy Trust Engine formulas aren't in this build
   package — stubbed with neutral defaults, not fabricated.
3. The blend-ramp formula itself isn't specified, only its duration.
4. Idempotency guard had to be keyed more precisely than the contract's
   literal field placement implies, or reject→resubmit pairs silently break.
5. Blend ramp must not apply to fresh onboards, only backfilled existing
   users — an early version of this build got that wrong; fixed and tested.

## Employer side (Build Pass 2)

### Tier 1 — real, working code
- Stage 1 intake (auto-profile accepted as input, NOT scraped — see
  FLAGS_EMPLOYER.md #1), adaptive micro-interview question selection
- Stage 2 rule-based text coding (changeReadinessScore) and automationPressure
- Stage 3 SKILL_SHIFT_MAP lookup, future-need profile builder, confidence gating
- Stage 4 matching — **using the reconciliation lookup, not a direct
  skillId match** — ranking, and match-confidence derivation
- API routes and UI tab wrapping all four stages

### Tier 2 — scaffolded, not calibrated
- O\*NET task ratings (`src/employer/onetLookup.js`) are a placeholder table,
  not the real dataset — see FLAGS_EMPLOYER.md #2
- `calcAdoptionVelocity` / `estimateSwitchingFriction` are reasoned
  heuristics, not specified formulas — FLAGS_EMPLOYER.md #3
- `extractCurrentSkillsFromJobPosting` is a stand-in for real job-posting
  NLP — and running the demo caught a real distortion this causes in
  `futureAdvantage` for multi-domain employers. **Read FLAGS_EMPLOYER.md #4
  before trusting any `futureAdvantage` number this build produces.**

### Tier 3 — flagged, not silently decided
See `FLAGS_EMPLOYER.md` for the full list. Headline items: `CW_current`/
`CW_emerging` weighting is a product decision carried from the spec, not
resolved here; `decliningFitInfo` is informational only by design; `T_CONF`
is now genuinely shared with the SSIE side (imported, not duplicated) —
resolving a flag from Build Pass 1.

## Build Pass 3 — config panel, feedback loop, cross-domain boost

Three cross-cutting additions, all logging/infrastructure rather than new
scoring logic — none of them change any default score, only what's visible
and adjustable.

**Admin config panel** (`src/config/adminConfig.js`, "config" tab) — 23
tunables spanning both systems, each with a registry default, min/max, and
group label. `getTunable`/`setTunable`/`resetTunable` read/write through the
store; every SSIE and employer stage that used to read a hardcoded constant
for one of these 23 values now resolves it via `resolveSSIEConfig`/
`resolveEmployerConfig` instead — confirmed by test that editing a value
actually changes pipeline behavior, not just a stored number. Every change
is logged (`getChangeLog`) and reversible.

**Outcome feedback-loop scaffold** (`src/employer/feedback.js`) — the Tier 2
item from the original handoff brief: log whether a predicted skill shift
happened, and whether a matched candidate got hired and worked out. Exposed
in the UI as a "record outcome" button on each need row and each ranking
row. Deliberately computes no accuracy/calibration score from this data yet
— see FLAGS_EMPLOYER.md #10 for why that restraint matters.

**`CROSS_DOMAIN_SKILLS` boost** — previously flagged as named-but-not-built
because the spec doesn't specify a boost magnitude. Now implemented with
the magnitude as a live config value (`employer.CROSS_DOMAIN_BOOST`) instead
of a silently invented constant, and each boosted skill is tagged
`crossDomainBoosted: true` on the profile so it's visible, not just applied
invisibly. See FLAGS_EMPLOYER.md #7.

## Project layout

```
src/
  config/
    constants.js              — SSIE structural + default tunable values
    adminConfig.js             — live-editable tunable registry (Build Pass 3)
  db/store.js                — Firestore-path-shaped local JSON store
  ml/                         — SSIE ML Tasks 1-4 (see above)
  ssie/                       — SSIE Stages 0-7 (reads tunables via adminConfig)
  employer/
    constants.js               — SKILL_SHIFT_MAP, text-coding patterns, structural defaults
    reconciliation.js          — the SSIE↔employer skill mapping fix (Stage 4 dependency)
    onetLookup.js              — placeholder O*NET-style task ratings (Tier 2)
    feedback.js                — outcome feedback-loop scaffold (Build Pass 3)
    stage1_intake.js
    stage2_scoring.js
    stage3_profile.js           — now includes the CROSS_DOMAIN_SKILLS boost
    stage4_matching.js          — reads tunables via adminConfig
    index.js                   — orchestrator
  api/server.js               — Express API + static UI host (SSIE, employer, config, feedback routes)
public/                        — single-page console, three tabs (HTML/CSS/vanilla JS, no build step)
scripts/
  runDemo.js                   — SSIE synthetic end-to-end run
  runEmployerDemo.js           — employer end-to-end run against real demo fixtures + debug-label sanity check
demo_data/                     — employers_demo.json, candidates_demo.json (from the original build package)
test/
  ssie_pipeline.test.js        — 11 tests
  employer_pipeline.test.js    — 11 tests, including one proving Stage 4's math is correct in isolation
  config_and_feedback.test.js  — 17 tests covering config, the cross-domain boost, and the feedback loop
data/                           — JSON store output (gitignore-worthy, inspectable)
FLAGS.md                        — SSIE-side flags — read this
FLAGS_EMPLOYER.md               — employer-side flags — read this one too, especially #4, #9, #10, #11
```

## Going to real infrastructure later

- **Storage:** swap `src/db/store.js`'s internals for a Firestore client with
  the same `get/set/update/listCollection` surface; calling code in
  `src/ssie/*.js` and `src/employer/*.js` shouldn't need to change.
- **LLM provider:** set an env var, nothing else. See `src/ml/llmAdapter.js`.
- **Cloud Functions triggers:** wire `src/ssie/index.js`'s
  `processEngagementEvent`, `ssieAdaptiveQuestSelector`, and
  `ssieDecayAndRecompute` to the Firestore triggers listed in Integration
  Contract §5 — the trigger wiring is infrastructure, not pipeline logic, and
  is intentionally not built here.

## Next build pass

Everything in `llm_handoff_brief.md`'s Tier 1/2 scope is now built. Remaining
open items are all in the FLAGS files: real O*NET data, real job-posting NLP
for current-skill extraction, a legal/ToS decision on auto-profile data
sourcing, and — once real employer/candidate outcome data exists — actually
calibrating any of the weights currently marked TUNABLE.

## Build Pass 4 — audit pass: coverage backlog + weight-fitting scaffold

A full audit against the original `llm_handoff_brief.md` Tier 1/2/3 lists
and definition-of-done, rather than building on request. Found two real gaps:

- **Coverage backlog** (`src/employer/coverageBacklog.js`) — unmapped task
  categories and unmapped employer-skill IDs were being *counted* in memory
  but never actually *persisted* anywhere, despite both specs documenting a
  "skip + log" behavior. Now a real, deduplicated, timestamped backlog,
  exposed via the config tab.
- **Weight-fitting pipeline scaffold** (`src/employer/weightFitting.js`) —
  the one Tier 2 item explicitly named in the original brief that hadn't
  been built yet. Gated on volume; below the gate, returns nothing but a
  status message; above it, returns a labeled descriptive diagnostic —
  never an automatic weight change. See `FLAGS_EMPLOYER.md` #12–13.

45 tests passing (up from 39), all verified against a live server, not just
re-reading source.
