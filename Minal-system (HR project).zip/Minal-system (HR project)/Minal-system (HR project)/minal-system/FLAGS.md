# Flags for the Product Owner

Per `llm_handoff_brief.md`: "If anything in either spec is ambiguous or
produces nonsensical output on the demo data, flag it back rather than
patching around it." This is that list, for the SSIE candidate-side build
(Stages 0-7). Each item below was either an explicit Tier 3 item from the
brief, or a real gap/bug discovered by actually running the pipeline rather
than just reading the spec.

---

## 1. `SSIESkillOutput.primitiveVector` — spec inconsistency, resolved via extension

Stage 6 of the Merged Algorithm (`ssieAdaptiveQuestSelector`) reads
`output.primitiveVector` to find the weakest-confidence primitive to target
with a quest. But `SSIESkillOutput` in the Integration Contract §1.2 — the
frozen output shape — does **not** include a `primitiveVector` field. Only
the aggregate `score`, `confidence`, and `stability{}` are specified there.

**What I did:** added `primitiveVector` (the weighted-primitives object
already computed inside Stage 3) as an extra field on the written
`softSkillProfile` doc. The contract explicitly permits this: "internal SSIE
logic may evolve, but these shapes may only be extended, never broken."
Stage 6 now reads it from there.

**Needs a decision:** is this the intended fix, or should Stage 6 instead
work from something else (e.g. a separate per-observation primitive query)?
The structural fix is minor either way, but someone who owns both documents
should confirm this was the intended reading, not a fill-in-the-gap guess.

---

## 2. Legacy MINAL Trust Engine formulas — stubbed, not fabricated

Stage 5's `legacyReliabilityComponent`, `legacyAccountabilityComponent`, and
`existingCompositeFormula` are referenced by the Merged Algorithm as
pre-existing MINAL functions, but MINAL's hard-skill Trust Engine formulas
are **not included** in this build package (the System & Investment Overview
describes them narratively; no pseudocode for them was handed off).

**What I did:** stubbed these with clearly-flagged neutral defaults (50/100
for the legacy components; a simple three-way average for the composite) so
the pipeline runs end-to-end, rather than inventing formulas for a system
this package doesn't specify.

**Needs:** the actual MINAL core Trust Engine pseudocode, or an explicit
decision that these neutral stubs are fine for continued SSIE-only
development until that integration happens.

---

## 3. Blend-ramp formula — not specified, only the ramp duration

`BLEND_RAMP_DAYS = 60` is given in the Constants reference, and Integration
Contract §7 names the control ("blend ramp β... to prevent score shock") but
never gives the actual blend formula.

**What I did:** implemented a straightforward linear interpolation from a
per-user legacy baseline (captured at backfill time) to the freshly computed
value, ramping over 60 days. See item #5 below for a related bug this caught.

**Needs:** confirm linear is the intended ramp shape (vs. e.g. an
ease-in curve), and confirm the legacy baseline should be a static
snapshot-at-backfill-time value (as implemented) rather than something
recomputed.

---

## 4. Idempotency guard — corrected from engagement-level to sub-event-level

The Integration Contract (§2.2) places `ssieProcessedAt` on the
`/engagements/{id}` document. Taken literally, that means ONE processed-flag
per engagement, forever — but a single engagement fires many distinct SSIE
sub-events over its life (a work log entry, then a deliverable rejection,
then its resubmission). Implementing the guard literally as specified caused
a real bug caught by running the demo: the resubmit half of a reject→resubmit
pair was silently skipped as a "duplicate" of the reject half, because both
share the same `engagementId`.

**What I did:** keyed the actual guard on a derived per-sub-event key
(engagement + channel + verdict + deliverable + timestamp), and kept a
separate `ssieLastProcessedAt` mirror on the engagement doc purely as an
informational "this engagement has seen SSIE activity" marker, matching the
contract's documented field location without using it as the real guard.

**Needs:** confirm this is the intended semantics — in a real Firestore
deployment, the actual Cloud Functions trigger would fire per underlying
document write (e.g. a specific deliverable's verdict field changing), which
naturally gives per-sub-event granularity; this local build had to make that
explicit since there's no real trigger infrastructure here.

---

## 5. Blend ramp was (and after the fix, is not) applied to fresh onboards — verify this was the intended scope

Caught the same way as #4: an early version of this build applied the blend
ramp to every user, including users onboarding for the first time with no
prior legacy score. That crushed a brand-new user's first real credibility
score toward zero, purely as an artifact of ramping "up" from a synthetic 0
baseline they never actually had.

**What I did:** blend ramp now only applies to users explicitly marked via
`markUserAsExistingBackfill()` — i.e., users who existed before SSIE and are
being migrated. Fresh onboards get their computed value immediately, with no
ramp, since there's no legacy score to protect.

**Needs:** confirm "existing user" should be an explicit backfill-job marker
(as implemented) rather than some other signal (e.g. account-age threshold).

---

## 6. Tier 3 items carried over verbatim from the handoff brief — status update

These were flagged in `llm_handoff_brief.md` as decisions for the product
owner. Restating them with their current status, since two are now resolved
by later build passes (see `FLAGS_EMPLOYER.md` #6 and #11 for the details):

- **`T_CONF` shared vs. duplicated — RESOLVED.** It's now one entry
  (`ssie.T_CONF`) in a shared, live-editable config registry
  (`src/config/adminConfig.js`), read by both systems via
  `resolveSSIEConfig`/`resolveEmployerConfig`. Editing it once changes both
  systems' behavior immediately.
- **`CW_current` / `CW_emerging` weighting — BUILT, still a product decision.**
  Implemented at the spec's suggested starting point (0.4/0.6) and now
  live-editable via the same config panel — but *what* the right value is
  remains an open product question, same as before. The panel makes it easy
  to change, not easy to know the right number.
- Whether `SSIE_CANONICAL_SKILLS` matches a real production skillClaims
  taxonomy — still unresolved, still just the reasoned starter list from the
  reconciliation doc. Not something a config panel can fix; needs a person
  who owns the real schema to confirm it.

---

## 7. ML Task 5 (adaptive quest selection bandit) — explicitly not built

Per the ML build spec §6 and the handoff brief's Tier 2 classification: the
contextual bandit needs live confidence-score data as its reward signal,
which doesn't exist yet. Stage 6 in this build uses the deterministic
heuristic already specified in the Merged Algorithm (argmin over weakest
primitive, round-robin template selection) — this is correct per spec, not a
placeholder for the bandit. Flagging only so it's clear the two are
intentionally different things, not that the bandit was forgotten.

---

## 8. Stale `_unreportableReason` — caught by building the UI, not the pipeline itself

Once a skill crosses the evidence threshold and becomes reportable, the
`_unreportableReason` note written during its earlier thin-evidence phase
was never cleared — so a skill that's now fully scored could still show a
leftover "not enough evidence yet" flag on its claim doc. This wasn't
visible from the command-line demo trace (which only prints the final
state), but showed up immediately once the console UI rendered
`demo_alice`'s claims side-by-side with her scored profile after the sample
walkthrough. Fixed in `src/ssie/index.js`'s `recomputeSkillProfile`, with a
regression test added.

Worth noting as a process point, not just a code point: building a UI on
top of a pipeline surfaces a different class of bug than either reading the
spec or running a scripted demo does, because a UI shows you *all* of a
record's fields at once, side by side, in a way a printed trace doesn't
naturally invite you to cross-check.
